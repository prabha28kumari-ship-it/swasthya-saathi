import { ArrowLeft, Building2, Info, Search, Shield, Heart, Baby, FileText, CheckCircle, Users, TrendingUp, MapPin, Phone, Clock, Navigation, X, Settings, Bell, Languages, HelpCircle } from 'lucide-react';
import { useState } from 'react';

interface GovernmentSchemesScreenProps {
  onBack: () => void;
}

type Tab = 'browse' | 'applications' | 'analytics' | 'eligibility';
type Category = 'all' | 'health-insurance' | 'maternal-health' | 'child-health' | 'medicines';

interface Scheme {
  id: string;
  name: string;
  nameHindi: string;
  category: string;
  description: string;
  benefits: string[];
  status: 'active' | 'inactive';
}

export function GovernmentSchemesScreen({ onBack }: GovernmentSchemesScreenProps) {
  const [activeTab, setActiveTab] = useState<Tab>('browse');
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showApplicationCenters, setShowApplicationCenters] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  
  // Eligibility checker states
  const [annualIncome, setAnnualIncome] = useState('');
  const [familyCategory, setFamilyCategory] = useState('');
  const [state, setState] = useState('');
  const [ageGroup, setAgeGroup] = useState('');

  const schemes: Scheme[] = [
    {
      id: '1',
      name: 'Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)',
      nameHindi: 'आयुष्मान भारत - प्रधान मंत्री जन आरोग्य योजना',
      category: 'Health Insurance',
      description: "World's largest health insurance scheme providing cashless treatment up to ₹5 lakh per family per year for secondary and tertiary care hospitalization",
      benefits: [
        'Cashless treatment up to ₹5 lakh per family annually',
        'Coverage for pre and post hospitalization expenses',
        'Coverage for 1,400+ medical and surgical packages',
        'No cap on family size and age',
        'Treatment available at 25,000+ empaneled hospitals'
      ],
      status: 'active'
    },
    {
      id: '2',
      name: 'Pradhan Mantri Surakshit Matritva Abhiyan',
      nameHindi: 'प्रधान मंत्री सुरक्षित मातृत्व अभियान',
      category: 'Maternal Health',
      description: 'Provides assured, comprehensive and quality antenatal care to all pregnant women on the 9th of every month',
      benefits: [
        'Free antenatal check-ups on 9th of every month',
        'Minimum package of ANC services',
        'Identification and management of high-risk pregnancies',
        'Free diet and nutrition counseling',
        'Laboratory tests and ultrasound'
      ],
      status: 'active'
    },
    {
      id: '3',
      name: 'Janani Suraksha Yojana (JSY)',
      nameHindi: 'जननी सुरक्षा योजना',
      category: 'Maternal Health',
      description: 'Cash assistance scheme for pregnant women to promote institutional delivery',
      benefits: [
        'Cash assistance for institutional delivery',
        'Free delivery care',
        'Post-delivery care for mother and child',
        'Transport assistance',
        'Assistance by community health workers'
      ],
      status: 'active'
    },
    {
      id: '4',
      name: 'Rashtriya Bal Swasthya Karyakram (RBSK)',
      nameHindi: 'राष्ट्रीय बाल स्वास्थ्य कार्यक्रम',
      category: 'Child Health',
      description: 'Comprehensive health screening and early intervention services for children from birth to 18 years',
      benefits: [
        'Free health screening for 0-18 years',
        'Early detection of birth defects',
        'Developmental delays screening',
        'Treatment and management support',
        'Referral services'
      ],
      status: 'active'
    },
    {
      id: '5',
      name: 'Pradhan Mantri Bhartiya Janaushadhi Pariyojana (PMBJP)',
      nameHindi: 'प्रधान मंत्री भारतीय जनऔषधि परियोजना',
      category: 'Medicines',
      description: 'Provides quality generic medicines at affordable prices through dedicated stores',
      benefits: [
        'Generic medicines at 50-90% lower prices',
        'Quality assured medicines',
        'Wide range of medicines available',
        '9,000+ Jan Aushadhi Kendras',
        'Surgical equipment and consumables'
      ],
      status: 'active'
    }
  ];

  // Filter schemes based on selected category
  const filteredSchemes = selectedCategory === 'all' 
    ? schemes 
    : schemes.filter(scheme => {
        const categoryMap: Record<Category, string[]> = {
          'all': [],
          'health-insurance': ['Health Insurance'],
          'maternal-health': ['Maternal Health'],
          'child-health': ['Child Health'],
          'medicines': ['Medicines']
        };
        return categoryMap[selectedCategory]?.includes(scheme.category);
      });

  const applications = [
    {
      id: '1',
      name: 'Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana',
      nameHindi: 'आयुष्मान भारत - प्रधान मंत्री जन आरोग्य योजना',
      appliedOn: 'October 10, 2024',
      applicationId: '100337',
      status: 'Applied',
      statusLabel: 'Processing'
    },
    {
      id: '2',
      name: 'Pradhan Mantri Surakshit Matritva Abhiyan',
      nameHindi: 'प्रधान मंत्री सुरक्षित मातृत्व अभियान',
      appliedOn: 'October 10, 2024',
      applicationId: '300947',
      status: 'Applied',
      statusLabel: 'Processing'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowApplicationCenters(true)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Building2 className="w-5 h-5 text-gray-700" />
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Settings className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3 mb-4">
          <div className="bg-purple-100 p-3 rounded-xl">
            <Building2 className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h1 className="text-2xl font-medium">Government Health Schemes</h1>
            <p className="text-sm text-gray-600">Explore and apply for government healthcare benefits</p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="bg-blue-50 border-2 border-blue-400 rounded-2xl p-4 mb-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-700 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-blue-900 mb-1">Government Health Schemes - Disclaimer</h3>
              <p className="text-sm text-blue-800">
                This app helps you discover government health schemes. Eligibility and approval depend on official government rules. Please verify documents and details at the hospital or authority.
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-4 gap-2">
          <button
            onClick={() => setActiveTab('browse')}
            className={`py-3 px-2 rounded-lg transition-colors text-sm ${
              activeTab === 'browse'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Browse Schemes
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`py-3 px-2 rounded-lg transition-colors text-sm ${
              activeTab === 'applications'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            My Applications
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-3 px-2 rounded-lg transition-colors text-sm ${
              activeTab === 'analytics'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Usage Analytics
          </button>
          <button
            onClick={() => setActiveTab('eligibility')}
            className={`py-3 px-2 rounded-lg transition-colors text-sm ${
              activeTab === 'eligibility'
                ? 'bg-white shadow-sm border border-gray-200'
                : 'bg-transparent text-gray-600 hover:bg-gray-100'
            }`}
          >
            Check Eligibility
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-4 pb-24">
        {/* Browse Schemes Tab */}
        {activeTab === 'browse' && (
          <div>
            <h2 className="text-xl mb-2">Search Health Schemes</h2>
            <p className="text-sm text-gray-600 mb-4">Find government schemes that suit your needs</p>

            {/* Search Bar */}
            <div className="flex gap-2 mb-6">
              <input
                type="text"
                placeholder="Search schemes by name or description..."
                className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button className="bg-gray-900 text-white px-6 py-3 rounded-xl hover:bg-gray-800 transition-colors">
                Search
              </button>
            </div>

            {/* Categories */}
            <div className="mb-6">
              <h3 className="font-medium mb-3">Categories</h3>
              <div className="flex gap-2 overflow-x-auto pb-2">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
                    selectedCategory === 'all'
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <Building2 className={`w-4 h-4 ${selectedCategory === 'all' ? 'text-purple-700' : 'text-gray-700'}`} />
                  <span>All</span>
                </button>
                <button
                  onClick={() => setSelectedCategory('health-insurance')}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
                    selectedCategory === 'health-insurance'
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <Shield className={`w-4 h-4 ${selectedCategory === 'health-insurance' ? 'text-purple-700' : 'text-gray-700'}`} />
                  <span>Health Insurance</span>
                </button>
                <button
                  onClick={() => setSelectedCategory('maternal-health')}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
                    selectedCategory === 'maternal-health'
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${selectedCategory === 'maternal-health' ? 'text-purple-700' : 'text-gray-700'}`} />
                  <span>Maternal Health</span>
                </button>
                <button
                  onClick={() => setSelectedCategory('child-health')}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
                    selectedCategory === 'child-health'
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <Baby className={`w-4 h-4 ${selectedCategory === 'child-health' ? 'text-purple-700' : 'text-gray-700'}`} />
                  <span>Child Health</span>
                </button>
                <button
                  onClick={() => setSelectedCategory('medicines')}
                  className={`px-4 py-2 rounded-lg border-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
                    selectedCategory === 'medicines'
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <FileText className={`w-4 h-4 ${selectedCategory === 'medicines' ? 'text-purple-700' : 'text-gray-700'}`} />
                  <span>Medicines</span>
                </button>
              </div>
            </div>

            {/* Schemes List */}
            <div className="space-y-4">
              {filteredSchemes.map((scheme) => (
                <div key={scheme.id} className="bg-white rounded-2xl p-5 shadow-sm border-l-4 border-l-purple-500">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="bg-purple-100 p-3 rounded-xl">
                        <Shield className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium mb-1">{scheme.name}</h3>
                        <p className="text-sm text-gray-600 mb-2">{scheme.nameHindi}</p>
                        <span className="inline-block bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                          {scheme.category}
                        </span>
                      </div>
                    </div>
                    <span className="bg-blue-600 text-white text-xs px-3 py-1 rounded-full uppercase">
                      {scheme.status}
                    </span>
                  </div>

                  <p className="text-gray-700 mb-4">{scheme.description}</p>

                  <div className="mb-4">
                    <h4 className="font-medium mb-2">Key Benefits:</h4>
                    <div className="space-y-2">
                      {scheme.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-gray-700">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* My Applications Tab */}
        {activeTab === 'applications' && (
          <div>
            <h2 className="text-xl mb-2">My Scheme Applications</h2>
            <p className="text-sm text-gray-600 mb-6">Track your government scheme applications</p>

            <div className="space-y-4">
              {applications.map((app) => (
                <div key={app.id} className="bg-white rounded-2xl p-5 shadow-sm border-l-4 border-l-green-500">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <h3 className="font-medium mb-1">{app.name}</h3>
                        <p className="text-sm text-gray-600">{app.nameHindi}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="inline-block bg-green-600 text-white text-xs px-3 py-1 rounded-full mb-1">
                        {app.status}
                      </span>
                      <p className="text-xs text-gray-600">{app.statusLabel}</p>
                    </div>
                  </div>

                  <div className="space-y-1 text-sm text-gray-700">
                    <p><span className="font-medium">Applied on:</span> {app.appliedOn}</p>
                    <p><span className="font-medium">Application ID:</span> {app.applicationId}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Usage Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-4">
            {/* Total Schemes */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-3 text-blue-600">
                <TrendingUp className="w-5 h-5" />
                <h3 className="font-medium">Total Schemes Available</h3>
              </div>
              <div className="text-5xl font-medium text-blue-600 mb-2">8</div>
              <p className="text-sm text-gray-600">Active government health schemes</p>
            </div>

            {/* Applications Submitted */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-3 text-green-600">
                <Users className="w-5 h-5" />
                <h3 className="font-medium">Applications Submitted</h3>
              </div>
              <div className="text-5xl font-medium text-green-600 mb-2">2</div>
              <p className="text-sm text-gray-600">By you this year</p>
            </div>

            {/* Coverage Amount */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-3 text-purple-600">
                <Shield className="w-5 h-5" />
                <h3 className="font-medium">Coverage Amount</h3>
              </div>
              <div className="text-5xl font-medium text-purple-600 mb-2">₹5.3L</div>
              <p className="text-sm text-gray-600">Total potential coverage</p>
            </div>

            {/* Scheme Usage by Category */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h3 className="font-medium mb-2">Scheme Usage by Category</h3>
              <p className="text-sm text-gray-600 mb-6">Distribution of government health schemes by category</p>

              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-gray-700" />
                      <span className="text-sm">Health Insurance</span>
                    </div>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-600 rounded-full" style={{ width: '25%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Heart className="w-4 h-4 text-gray-700" />
                      <span className="text-sm">Maternal Health</span>
                    </div>
                    <span className="text-sm font-medium">3</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-pink-600 rounded-full" style={{ width: '37.5%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Baby className="w-4 h-4 text-gray-700" />
                      <span className="text-sm">Child Health</span>
                    </div>
                    <span className="text-sm font-medium">2</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-600 rounded-full" style={{ width: '25%' }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-700" />
                      <span className="text-sm">Medicines</span>
                    </div>
                    <span className="text-sm font-medium">1</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-600 rounded-full" style={{ width: '12.5%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Check Eligibility Tab */}
        {activeTab === 'eligibility' && (
          <div>
            <h2 className="text-xl font-medium mb-2">Eligibility Checker</h2>
            <p className="text-sm text-gray-600 mb-6">Check which government schemes you're eligible for</p>

            {/* Annual Family Income */}
            <div className="mb-6">
              <label className="block mb-2 font-medium text-gray-900">Annual Family Income</label>
              <input
                type="text"
                placeholder="Enter annual income in ₹"
                className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900"
                value={annualIncome}
                onChange={(e) => setAnnualIncome(e.target.value)}
              />
            </div>

            {/* Family Category */}
            <div className="mb-6">
              <label className="block mb-2 font-medium text-gray-900">Family Category</label>
              <select
                className="w-full px-4 py-3 bg-white border-2 border-purple-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 appearance-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center'
                }}
                value={familyCategory}
                onChange={(e) => setFamilyCategory(e.target.value)}
              >
                <option value="">Select category</option>
                <option>General</option>
                <option>OBC (Other Backward Class)</option>
                <option>SC (Scheduled Caste)</option>
                <option>ST (Scheduled Tribe)</option>
                <option>EWS (Economically Weaker Section)</option>
              </select>
            </div>

            {/* State */}
            <div className="mb-6">
              <label className="block mb-2 font-medium text-gray-900">State</label>
              <input
                type="text"
                placeholder="Enter your state"
                className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900"
                value={state}
                onChange={(e) => setState(e.target.value)}
              />
            </div>

            {/* Age Group */}
            <div className="mb-6">
              <label className="block mb-2 font-medium text-gray-900">Age Group</label>
              <select
                className="w-full px-4 py-3 bg-white border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 text-gray-900 appearance-none"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'%3E%3Cpath d='M5 7.5L10 12.5L15 7.5' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center'
                }}
                value={ageGroup}
                onChange={(e) => setAgeGroup(e.target.value)}
              >
                <option value="">Select age group</option>
                <option>0-5 years (Infant/Child)</option>
                <option>6-17 years (Child/Adolescent)</option>
                <option>18-40 years (Adult)</option>
                <option>41-60 years (Middle Age)</option>
                <option>60+ years (Senior Citizen)</option>
              </select>
            </div>

            {/* Check Eligibility Button */}
            <button className="w-full bg-gray-900 text-white py-4 rounded-xl hover:bg-gray-800 transition-colors font-medium">
              Check Eligibility
            </button>
          </div>
        )}
      </main>

      {/* Help Button */}
      <button className="fixed bottom-6 right-6 bg-gray-900 text-white p-4 rounded-full shadow-lg hover:bg-gray-800 transition-colors">
        <HelpCircle className="w-6 h-6" />
      </button>

      {/* Application Centers Modal */}
      {showApplicationCenters && (
        <ApplicationCentersModal onClose={() => setShowApplicationCenters(false)} />
      )}

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal onClose={() => setShowSettings(false)} />
      )}
    </div>
  );
}

interface ApplicationCentersModalProps {
  onClose: () => void;
}

function ApplicationCentersModal({ onClose }: ApplicationCentersModalProps) {
  const centers = [
    {
      id: '1',
      name: 'District Health Office',
      nameHindi: 'जिला स्वास्थ्य कार्यालय',
      address: 'Main Road, Civil Lines, District Center',
      phone: '+91-XXXX-XXXXXX',
      hours: 'Mon-Fri: 9:00 AM - 5:00 PM',
      borderColor: 'border-purple-300',
      bgColor: 'bg-purple-50',
      iconBg: 'bg-purple-100',
      iconColor: 'text-purple-600',
      buttonBg: 'bg-purple-600',
      buttonHover: 'hover:bg-purple-700',
      tags: []
    },
    {
      id: '2',
      name: 'Government General Hospital',
      nameHindi: 'सरकारी सामान्य अस्पताल',
      address: 'Hospital Road, Medical College Area',
      phone: '+91-XXXX-XXXXXX',
      hours: '24/7 Emergency Services',
      borderColor: 'border-blue-300',
      bgColor: 'bg-blue-50',
      iconBg: 'bg-blue-100',
      iconColor: 'text-blue-600',
      buttonBg: 'bg-blue-600',
      buttonHover: 'hover:bg-blue-700',
      tags: ['Ayushman Bharat Empaneled']
    },
    {
      id: '3',
      name: 'Community Health Center',
      nameHindi: 'सामुदायिक स्वास्थ्य केंद्र',
      address: 'Block Area, Near Post Office',
      phone: '+91-XXXX-XXXXXX',
      hours: 'Mon-Sat: 8:00 AM - 2:00 PM',
      borderColor: 'border-green-300',
      bgColor: 'bg-green-50',
      iconBg: 'bg-green-100',
      iconColor: 'text-green-600',
      buttonBg: 'bg-green-600',
      buttonHover: 'hover:bg-green-700',
      tags: ['Maternity & Child Health Services']
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-purple-600 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <div className="flex items-center gap-3">
            <Building2 className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-medium">Application Centers</h2>
              <p className="text-sm text-purple-100">आवेदन केंद्र और अस्पताल</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-purple-700 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-4">
          {centers.map((center) => (
            <div key={center.id} className={`${center.bgColor} border-2 ${center.borderColor} rounded-2xl p-4`}>
              <div className="flex items-start gap-3 mb-3">
                <div className={`${center.iconBg} p-3 rounded-xl`}>
                  <Building2 className={`w-5 h-5 ${center.iconColor}`} />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium mb-1">{center.name}</h3>
                  <p className="text-sm text-gray-600">{center.nameHindi}</p>
                </div>
              </div>

              <div className="space-y-2 mb-3">
                <div className="flex items-start gap-2 text-sm text-gray-700">
                  <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>{center.address}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Phone className="w-4 h-4" />
                  <span>{center.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <Clock className="w-4 h-4" />
                  <span>{center.hours}</span>
                </div>
              </div>

              {center.tags.length > 0 && (
                <div className="mb-3">
                  {center.tags.map((tag, index) => (
                    <div key={index} className="bg-green-100 border border-green-300 rounded-lg px-3 py-2 text-sm text-green-800 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      <span>{tag}</span>
                    </div>
                  ))}
                </div>
              )}

              <button className={`w-full ${center.buttonBg} ${center.buttonHover} text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2`}>
                <Navigation className="w-4 h-4" />
                <span>Get Directions</span>
              </button>
            </div>
          ))}

          {/* Important Information */}
          <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4">
            <div className="flex items-start gap-2 mb-2">
              <Info className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <h3 className="font-medium text-purple-900">Important Information</h3>
            </div>
            <p className="text-sm text-purple-800 mb-2">
              Visit these centers to apply for government health schemes, get your Ayushman card, or verify your eligibility. Carry necessary documents (Aadhaar, income certificate, etc.).
            </p>
            <p className="text-sm text-purple-800">
              सरकारी स्वास्थ्य योजनाओं के लिए आवेदन करने, अपना आयुष्मान कार्ड प्राप्त करने या अपनी पात्रता सत्यापित करने के लिए इन केंद्रों पर जाएं। आवश्यक दस्तावेज (आधार, आय प्रमाण पत्र आदि) साथ लाएं।
            </p>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-xl transition-colors font-medium"
          >
            Close / बंद करें
          </button>
        </div>
      </div>
    </div>
  );
}

interface SettingsModalProps {
  onClose: () => void;
}

function SettingsModal({ onClose }: SettingsModalProps) {
  const [newSchemeUpdates, setNewSchemeUpdates] = useState(true);
  const [applicationAlerts, setApplicationAlerts] = useState(true);
  const [documentReminders, setDocumentReminders] = useState(true);
  const [language, setLanguage] = useState('both');

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Modal Header */}
        <div className="sticky top-0 bg-purple-600 text-white px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6" />
            <div>
              <h2 className="text-xl font-medium">Scheme Settings</h2>
              <p className="text-sm text-purple-100">योजना सेटिंग्स</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-purple-700 rounded-lg">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6">
          {/* Notifications Section */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 text-gray-900">
              <Bell className="w-5 h-5" />
              <h3 className="font-medium">Notifications / सूचनाएं</h3>
            </div>

            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-gray-900">योजना अपडेट</p>
                  <p className="text-sm text-gray-600">New scheme updates</p>
                </div>
                <button
                  onClick={() => setNewSchemeUpdates(!newSchemeUpdates)}
                  className={`relative w-12 h-7 rounded-full transition-colors ${
                    newSchemeUpdates ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                      newSchemeUpdates ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-gray-900">आवेदन अलर्ट</p>
                  <p className="text-sm text-gray-600">Application status alerts</p>
                </div>
                <button
                  onClick={() => setApplicationAlerts(!applicationAlerts)}
                  className={`relative w-12 h-7 rounded-full transition-colors ${
                    applicationAlerts ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                      applicationAlerts ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-gray-900">दस्तावेज अनुस्मारक</p>
                  <p className="text-sm text-gray-600">Document submission reminders</p>
                </div>
                <button
                  onClick={() => setDocumentReminders(!documentReminders)}
                  className={`relative w-12 h-7 rounded-full transition-colors ${
                    documentReminders ? 'bg-purple-600' : 'bg-gray-300'
                  }`}
                >
                  <div
                    className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                      documentReminders ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  ></div>
                </button>
              </div>
            </div>
          </div>

          {/* Language Preference */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4 text-gray-900">
              <Languages className="w-5 h-5" />
              <h3 className="font-medium">Language Preference / भाषा प्राथमिकता</h3>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setLanguage('english')}
                className={`py-3 rounded-xl transition-colors ${
                  language === 'english'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('hindi')}
                className={`py-3 rounded-xl transition-colors ${
                  language === 'hindi'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                हिंदी
              </button>
              <button
                onClick={() => setLanguage('both')}
                className={`py-3 rounded-xl transition-colors ${
                  language === 'both'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Both
              </button>
            </div>
          </div>

          {/* About Scheme Settings */}
          <div className="mb-6 bg-purple-50 border border-purple-200 rounded-2xl p-4">
            <div className="flex items-start gap-2 mb-2">
              <FileText className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
              <h3 className="font-medium text-purple-900">About Scheme Settings</h3>
            </div>
            <p className="text-sm text-purple-800 mb-2">
              Customize your notifications and language preferences for government health schemes. Get timely updates about new schemes, application statuses, and document requirements.
            </p>
            <p className="text-sm text-purple-800">
              सरकारी स्वास्थ्य योजनाओं के लिए अपनी सूचनाएं और भाषा प्राथमिकताएं अनुकूलित करें। नई योजनाओं, आवेदन स्थिति और दस्तावेज़ आवश्यकताओं के बारे में समयसमय पर अपडेट प्राप्त करें।
            </p>
          </div>

          {/* Done Button */}
          <button
            onClick={onClose}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-xl transition-colors font-medium"
          >
            Done / पूर्ण
          </button>
        </div>
      </div>
    </div>
  );
}