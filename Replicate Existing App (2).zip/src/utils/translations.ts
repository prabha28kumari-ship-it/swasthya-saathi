// Translation utility for Health Companion App

export const translations = {
  dashboard: {
    hello: {
      en: 'Hello',
      hi: 'नमस्ते'
    },
    verified: {
      en: 'Verified',
      hi: 'सत्यापित'
    },
    lastConsultation: {
      en: 'Last Consultation',
      hi: 'अंतिम परामर्श'
    },
    healthScore: {
      en: 'Health Score',
      hi: 'स्वास्थ्य स्कोर'
    },
    good: {
      en: 'Good',
      hi: 'अच्छा'
    },
    activeDays: {
      en: 'Active Days',
      hi: 'सक्रिय दिन'
    },
    quickActions: {
      en: 'Quick Actions',
      hi: 'त्वरित कार्य'
    },
    askHealthQuestion: {
      en: 'Ask Health Question',
      hi: 'स्वास्थ्य प्रश्न पूछें'
    },
    medicationReminders: {
      en: 'Medication Reminders',
      hi: 'दवा अनुस्मारक'
    },
    governmentSchemes: {
      en: 'Government Schemes',
      hi: 'सरकारी योजनाएं'
    },
    profile: {
      en: 'Profile',
      hi: 'प्रोफ़ाइल'
    },
    nearbyHospitals: {
      en: 'Nearby Hospitals',
      hi: 'निकटतम अस्पताल'
    },
    healthArticles: {
      en: 'Health Articles',
      hi: 'स्वास्थ्य लेख'
    },
    settings: {
      en: 'Settings',
      hi: 'सेटिंग्स'
    },
    preVisitPreparation: {
      en: 'Pre-Visit Preparation',
      hi: 'प्री-विजिट तैयारी'
    },
    getReadyBeforeVisiting: {
      en: 'Get ready before visiting doctor or hospital',
      hi: 'डॉक्टर या अस्पताल जाने से पहले तैयार हो जाएं'
    },
    recentTopics: {
      en: 'Recent Topics',
      hi: 'हाल के विषय'
    },
    todaysHealthTip: {
      en: "Today's Health Tip",
      hi: 'आज का स्वास्थ्य सुझाव'
    },
    emergencyHealthNumbers: {
      en: 'Emergency Health Numbers',
      hi: 'आपातकालीन स्वास्थ्य नंबर'
    },
    ambulance: {
      en: 'Ambulance',
      hi: 'एम्बुलेंस सेवा'
    },
    viewAll: {
      en: 'View All Emergency Numbers',
      hi: 'सभी आपातकालीन नंबर देखें'
    },
    menu: {
      en: 'Menu',
      hi: 'मेनू'
    },
    verifiedUser: {
      en: 'Verified User',
      hi: 'सत्यापित उपयोगकर्ता'
    },
    main: {
      en: 'MAIN',
      hi: 'मुख्य'
    },
    dashboard: {
      en: 'Dashboard',
      hi: 'डैशबोर्ड'
    },
    myProfile: {
      en: 'My Profile',
      hi: 'मेरी प्रोफ़ाइल'
    },
    viewEditProfile: {
      en: 'View & edit profile',
      hi: 'प्रोफ़ाइल देखें और संपादित करें'
    },
    healthServices: {
      en: 'HEALTH SERVICES',
      hi: 'स्वास्थ्य सेवाएं'
    },
    aiHealthAssistant: {
      en: 'AI health assistant',
      hi: 'एआई स्वास्थ्य सहायक'
    },
    neverMissADose: {
      en: 'Never miss a dose',
      hi: 'कभी भी खुराक न भूलें'
    },
    preVisitGuide: {
      en: 'Pre-Visit Guide',
      hi: 'प्री-विजिट गाइड'
    },
    prepareForDoctor: {
      en: 'Prepare for doctor visit',
      hi: 'डॉक्टर की यात्रा के लिए तैयार करें'
    },
    findHospitalsNearYou: {
      en: 'Find hospitals near you',
      hi: 'अपने पास अस्पताल खोजें'
    },
    resources: {
      en: 'RESOURCES',
      hi: 'संसाधन'
    },
    articlesAcrossTopics: {
      en: '22 articles across 7 topics',
      hi: '7 विषयों में 22 लेख'
    },
    healthBenefitsSchemes: {
      en: 'Health benefits & schemes',
      hi: 'स्वास्थ्य लाभ और योजनाएं'
    },
    emergency: {
      en: 'EMERGENCY',
      hi: 'आपातकालीन'
    },
    emergencyNumbers: {
      en: 'Emergency Numbers',
      hi: 'आपातकालीन नंबर'
    },
    viewAllEmergencyContacts: {
      en: 'View all emergency contacts',
      hi: 'सभी आपातकालीन संपर्क देखें'
    },
    settingsMore: {
      en: 'SETTINGS & MORE',
      hi: 'सेटिंग्स और अधिक'
    },
    helpSupport: {
      en: 'Help & Support',
      hi: 'सहायता और समर्थन'
    },
    logout: {
      en: 'Logout',
      hi: 'लॉगआउट'
    },
    healthCompanionApp: {
      en: 'Health Companion App',
      hi: 'स्वास्थ्य साथी ऐप'
    },
    version: {
      en: 'Version 1.0.0',
      hi: 'संस्करण 1.0.0'
    },
  },
  notifications: {
    title: {
      en: 'Notifications',
      hi: 'सूचनाएं'
    },
    back: {
      en: 'Back',
      hi: 'वापस'
    },
    markAllRead: {
      en: 'Mark all as read',
      hi: 'सभी को पढ़ा हुआ चिह्नित करें'
    },
    today: {
      en: 'Today',
      hi: 'आज'
    },
    yesterday: {
      en: 'Yesterday',
      hi: 'कल'
    },
    thisWeek: {
      en: 'This Week',
      hi: 'इस सप्ताह'
    }
  },
  common: {
    back: {
      en: 'Back',
      hi: 'वापस'
    },
    continue: {
      en: 'Continue',
      hi: 'जारी रखें'
    },
    submit: {
      en: 'Submit',
      hi: 'जमा करें'
    },
    cancel: {
      en: 'Cancel',
      hi: 'रद्द करें'
    },
    save: {
      en: 'Save',
      hi: 'सहेजें'
    },
    delete: {
      en: 'Delete',
      hi: 'हटाएं'
    },
    edit: {
      en: 'Edit',
      hi: 'संपादित करें'
    },
    close: {
      en: 'Close',
      hi: 'बंद करें'
    },
    search: {
      en: 'Search',
      hi: 'खोजें'
    },
    filter: {
      en: 'Filter',
      hi: 'फ़िल्टर'
    },
    all: {
      en: 'All',
      hi: 'सभी'
    },
    yes: {
      en: 'Yes',
      hi: 'हां'
    },
    no: {
      en: 'No',
      hi: 'नहीं'
    },
    ok: {
      en: 'OK',
      hi: 'ठीक है'
    },
    done: {
      en: 'Done',
      hi: 'पूर्ण'
    }
  }
};

// Helper function to get translated text
export function t(key: string, lang: string = 'en'): string {
  const isHindi = lang.toLowerCase() === 'hindi' || lang.toLowerCase() === 'हिंदी';
  const langCode = isHindi ? 'hi' : 'en';
  
  const keys = key.split('.');
  let value: any = translations;
  
  for (const k of keys) {
    if (value && typeof value === 'object') {
      value = value[k];
    } else {
      return key; // Return key if translation not found
    }
  }
  
  if (value && typeof value === 'object' && (langCode in value)) {
    return value[langCode];
  }
  
  return key; // Return key if translation not found
}

// Helper to show both languages (bilingual display)
export function bilingual(enText: string, hiText: string, lang: string = 'en', showBoth: boolean = false): string {
  const isHindi = lang.toLowerCase() === 'hindi' || lang.toLowerCase() === 'हिंदी';
  
  if (showBoth) {
    return isHindi ? `${hiText} / ${enText}` : `${enText} / ${hiText}`;
  }
  
  return isHindi ? hiText : enText;
}
