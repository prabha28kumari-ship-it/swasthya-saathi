import { X, Volume2, BookOpen } from 'lucide-react';

interface HealthArticle {
  id: number;
  title: string;
  titleHindi: string;
  category: string;
  categoryColor: string;
  description: string;
  descriptionHindi: string;
  icon: any;
  iconBg: string;
  hasAudio: boolean;
}

interface HealthArticleDetailModalProps {
  article: HealthArticle;
  onClose: () => void;
  textSize: 'small' | 'medium' | 'large';
}

// Comprehensive article content database
const articleContent: { [key: number]: { english: string; hindi: string } } = {
  1: { // Nutrition and Healthy Eating
    english: `**Introduction**

Good nutrition is essential for maintaining health, preventing diseases, and promoting overall well-being. A balanced diet provides the nutrients your body needs to function effectively.

**Key Nutritional Guidelines:**

**1. Balanced Diet**
• Include variety from all food groups
• Eat plenty of fruits and vegetables (5 servings daily)
• Choose whole grains over refined grains
• Include lean proteins (dal, legumes, fish, chicken)
• Consume dairy or fortified alternatives

**2. Portion Control**
• Use a smaller plate to control portions
• Fill half your plate with vegetables
• One quarter with protein
• One quarter with whole grains

**3. Essential Nutrients**
• **Carbohydrates:** Choose complex carbs (brown rice, whole wheat)
• **Proteins:** Include plant and animal sources
• **Fats:** Choose healthy fats (nuts, seeds, olive oil)
• **Vitamins & Minerals:** Eat colorful fruits and vegetables
• **Fiber:** Important for digestion (fruits, vegetables, whole grains)

**4. Hydration**
• Drink 8-10 glasses of water daily
• Increase intake during summer and physical activity
• Limit sugary drinks and sodas

**5. Foods to Limit**
• Reduce salt intake (less than 5g per day)
• Limit sugar consumption
• Avoid trans fats and processed foods
• Reduce red meat consumption

**6. Healthy Eating Habits**
• Eat regular meals - don't skip breakfast
• Chew food slowly
• Avoid eating while watching TV
• Plan meals ahead
• Cook at home more often

**Special Considerations:**
• **Pregnant women:** Need extra iron, folic acid, and calcium
• **Children:** Require nutrients for growth and development
• **Elderly:** May need vitamin D and B12 supplements
• **Diabetics:** Focus on low glycemic index foods

**Remember:** Consult a healthcare provider or nutritionist for personalized dietary advice.`,
    hindi: `**परिचय**

अच्छा पोषण स्वास्थ्य बनाए रखने, रोगों को रोकने और समग्र कल्याण को बढ़ावा देने के लिए आवश्यक है। संतुलित आहार शरीर को प्रभावी ढंग से कार्य करने के लिए आवश्यक पोषक तत्व प्रदान करता है।

**प्रमुख पोषण दिशानिर्देश:**

**1. संतुलित आहार**
• सभी खाद्य समूहों से विविधता शामिल करें
• भरपूर फल और सब्जियां खाएं (दैनिक 5 सर्विंग्स)
• परिष्कृत अनाज के बजाय साबुत अनाज चुनें
• लीन प्रोटीन शामिल करें (दाल, फलियां, मछली, चिकन)
• डेयरी या फोर्टिफाइड विकल्प का सेवन करें

**2. भाग नियंत्रण**
• भागों को नियंत्रित करने के लिए छोटी प्लेट का उपयोग करें
• अपनी प्लेट का आधा हिस्सा सब्जियों से भरें
• एक चौथाई प्रोटीन के साथ
• एक चौथाई साबुत अनाज के साथ

**3. आवश्यक पोषक तत्व**
• **कार्बोहाइड्रेट:** जटिल कार्ब्स चुनें (ब्राउन राइस, पूरे गेहूं)
• **प्रोटीन:** पौधे और पशु स्रोत शामिल करें
• **वसा:** स्वस्थ वसा चुनें (मेवे, बीज, जैतून का तेल)
• **विटामिन और खनिज:** रंगीन फल और सब्जियां खाएं
• **फाइबर:** पाचन के लिए महत्वपूर्ण (फल, सब्जियां, साबुत अनाज)

**4. जलयोजन**
• प्रतिदिन 8-10 गिलास पानी पिएं
• गर्मियों और शारीरिक गतिविधि के दौरान सेवन बढ़ाएं
• शुगर युक्त पेय और सोडा सीमित करें

**5. सीमित करने वाले खाद्य पदार्थ**
• नमक का सेवन कम करें (प्रति दिन 5 ग्राम से कम)
• चीनी की खपत सीमित करें
• ट्रांस फैट और प्रसंस्कृत खाद्य पदार्थों से बचें
• लाल मांस की खपत कम करें

**6. स्वस्थ खाने की आदतें**
• नियमित भोजन खाएं - नाश्ता न छोड़ें
• भोजन को धीरे-धीरे चबाएं
• टीवी देखते समय खाने से बचें
• भोजन की पहले से योजना बनाएं
• घर पर अधिक बार खाना बनाएं

**विशेष विचार:**
• **गर्भवती महिलाएं:** अतिरिक्त आयरन, फोलिक एसिड और कैल्शियम की आवश्यकता
• **बच्चे:** वृद्धि और विकास के लिए पोषक तत्वों की आवश्यकता
• **बुजुर्ग:** विटामिन डी और B12 सप्लीमेंट की आवश्यकता हो सकती है
• **मधुमेह रोगी:** कम ग्लाइसेमिक इंडेक्स वाले खाद्य पदार्थों पर ध्यान दें

**याद रखें:** व्यक्तिगत आहार सलाह के लिए स्वास्थ्य सेवा प्रदाता या पोषण विशेषज्ञ से परामर्श लें।`
  },
  2: { // Antenatal Care and Pregnancy
    english: `**Introduction**

Antenatal care (ANC) is the healthcare you receive during pregnancy. Regular check-ups help ensure a healthy pregnancy and safe delivery.

**Antenatal Care Schedule:**

**First Trimester (1-12 weeks)**
• First visit within 12 weeks
• Complete medical history
• Blood tests (hemoglobin, blood group, HIV, hepatitis)
• Ultrasound for dating
• Folic acid supplementation (400mcg daily)

**Second Trimester (13-26 weeks)**
• Monthly check-ups
• Anomaly scan at 18-20 weeks
• Iron and calcium supplements
• Monitor weight gain
• Check blood pressure

**Third Trimester (27-40 weeks)**
• Bi-weekly visits after 32 weeks
• Weekly visits after 36 weeks
• Monitor fetal movements
• Plan for delivery
• Check baby's position

**Essential Care During Pregnancy:**

**1. Nutrition**
• Eat balanced, nutritious meals
• Take prenatal vitamins
• Increase calorie intake (300-500 extra calories)
• Drink plenty of water
• Avoid raw/undercooked food

**2. Exercise**
• Walk daily (30 minutes)
• Practice prenatal yoga
• Avoid strenuous activities
• Pelvic floor exercises

**3. Rest & Sleep**
• Get 8-9 hours of sleep
• Rest during the day
• Sleep on left side (third trimester)
• Use pillows for support

**4. Warning Signs - Seek Immediate Help:**
• Severe abdominal pain
• Heavy bleeding
• Severe headache with vision changes
• High fever
• Reduced fetal movements
• Leaking fluid
• Severe swelling

**Things to Avoid:**
• Smoking and tobacco
• Alcohol
• Unprescribed medications
• Heavy lifting
• Hot baths/saunas
• Raw meat and unpasteurized dairy

**Birth Preparedness:**
• Attend childbirth classes
• Prepare hospital bag by 36 weeks
• Discuss birth plan with doctor
• Arrange transportation
• Plan for support after delivery

**Postpartum Care:**
• Rest and nutrition
• Breastfeeding support
• Emotional well-being
• Contraception planning
• Follow-up check-ups

**Remember:** Every pregnancy is unique. Regular ANC visits are crucial for mother and baby's health.`,
    hindi: `**परिचय**

प्रसवपूर्व देखभाल (ANC) गर्भावस्था के दौरान प्राप्त स्वास्थ्य सेवा है। नियमित जांच स्वस्थ गर्भावस्था और सुरक्षित प्रसव सुनिश्चित करने में मदद करती है।

**प्रसवपूर्व देखभाल अनुसूची:**

**प्रथम तिमाही (1-12 सप्ताह)**
• 12 सप्ताह के भीतर पहली यात्रा
• पूर्ण चिकित्सा इतिहास
• रक्त परीक्षण (हीमोग्लोबिन, रक्त समूह, HIV, हेपेटाइटिस)
• डेटिंग के लिए अल्ट्रासाउंड
• फोलिक एसिड सप्लीमेंटेशन (प्रतिदिन 400mcg)

**द्वितीय तिमाही (13-26 सप्ताह)**
• मासिक जांच
• 18-20 सप्ताह में एनोमली स्कैन
• आयरन और कैल्शियम सप्लीमेंट
• वजन वृद्धि की निगरानी
• रक्तचाप जांचें

**तृतीय तिमाही (27-40 सप्ताह)**
• 32 सप्ताह के बाद द्वि-साप्ताहिक यात्राएं
• 36 सप्ताह के बाद साप्ताहिक यात्राएं
• भ्रूण की गतिविधियों की निगरानी
• प्रसव की योजना
• बच्चे की स्थिति जांचें

**गर्भावस्था के दौरान आवश्यक देखभाल:**

**1. पोषण**
• संतुलित, पौष्टिक भोजन खाएं
• प्रसवपूर्व विटामिन लें
• कैलोरी सेवन बढ़ाएं (300-500 अतिरिक्त कैलोरी)
• भरपूर पानी पिएं
• कच्चे/अधपके भोजन से बचें

**2. व्यायाम**
• प्रतिदिन चलें (30 मिनट)
• प्रसवपूर्व योग का अभ्यास करें
• कठिन गतिविधियों से बचें
• पेल्विक फ्लोर व्यायाम

**3. आराम और नींद**
• 8-9 घंटे की नींद लें
• दिन में आराम करें
• बाईं ओर सोएं (तृतीय तिमाही)
• समर्थन के लिए तकिए का उपयोग करें

**4. चेतावनी संकेत - तुरंत सहायता लें:**
• गंभीर पेट दर्द
• भारी रक्तस्राव
• दृष्टि परिवर्तन के साथ गंभीर सिरदर्द
• तेज बुखार
• भ्रूण की गतिविधियों में कमी
• तरल का रिसाव
• गंभीर सूजन

**बचने योग्य चीजें:**
• धूम्रपान और तंबाकू
• शराब
• बिना प्रिस्क्रिप्शन की दवाएं
• भारी सामान उठाना
• गर्म स्नान/सौना
• कच्चा मांस और बिना पाश्चुरीकृत डेयरी

**प्रसव तैयारी:**
• प्रसव कक्षाओं में भाग लें
• 36 सप्ताह तक अस्पताल बैग तैयार करें
• डॉक्टर के साथ जन्म योजना पर चर्चा करें
• परिवहन की व्यवस्था करें
• प्रसव के बाद समर्थन की योजना बनाएं

**प्रसवोत्तर देखभाल:**
• आराम और पोषण
• स्तनपान समर्थन
• भावनात्मक कल्याण
• गर्भनिरोधक योजना
• अनुवर्ती जांच

**याद रखें:** हर गर्भावस्था अद्वितीय होती है। मां और बच्चे के स्वास्थ्य के लिए नियमित ANC यात्राएं महत्वपूर्ण हैं।`
  },
  3: { // Fever Management
    english: `**Introduction**

Fever is a temporary increase in body temperature, often due to illness. Normal body temperature is around 98.6°F (37°C). Fever is generally defined as 100.4°F (38°C) or higher.

**Causes of Fever:**
• Viral infections (flu, cold, COVID-19)
• Bacterial infections
• Heat exhaustion
• Inflammatory conditions
• Vaccinations
• Certain medications

**When to Measure Temperature:**
• If feeling unwell or hot
• During illness
• Before giving fever medication
• Regular monitoring during high fever

**Home Care for Fever:**

**1. Hydration**
• Drink plenty of fluids (water, ORS, soup)
• Avoid caffeinated drinks
• Offer fluids frequently
• Check urine color (should be light yellow)

**2. Rest**
• Get adequate sleep
• Avoid strenuous activity
• Stay in a comfortable environment

**3. Cooling Measures**
• Remove excess clothing
• Use light blankets
• Keep room temperature comfortable
• Apply cool compress to forehead

**4. Medications (consult doctor first)**
• **Paracetamol/Acetaminophen:**
  - Adults: 500-1000mg every 4-6 hours
  - Children: As per doctor's advice based on weight
• **Ibuprofen (if paracetamol ineffective):**
  - Adults: 200-400mg every 4-6 hours
  - Not for children under 6 months

**DO NOT:**
• Give aspirin to children under 18
• Use cold water baths
• Bundle up excessively
• Mix medications without doctor's advice

**When to Seek Medical Help:**

**Adults - Seek help if:**
• Fever above 103°F (39.4°C)
• Fever lasts more than 3 days
• Severe headache
• Stiff neck
• Confusion or difficulty staying awake
• Persistent vomiting
• Difficulty breathing
• Chest or abdominal pain
• Unusual skin rash

**Children - Seek immediate help if:**
• Infant under 3 months with fever above 100.4°F (38°C)
• Fever above 102°F (38.9°C) in children
• Fever with seizures
• Difficulty breathing
• Severe irritability or lethargy
• Refuses fluids
• Rash with fever
• Fever after travel to malaria/dengue zones

**Fever in Special Conditions:**

**Pregnant Women:**
• Fever can affect baby
• Consult doctor immediately
• Avoid self-medication

**Elderly:**
• May not show high fever despite serious infection
• Watch for confusion, falls
• Seek medical attention earlier

**People with Chronic Conditions:**
• Diabetes, heart disease, immune disorders
• Fever may indicate serious complication
• Contact doctor promptly

**Prevention:**
• Practice good hygiene
• Wash hands frequently
• Avoid close contact with sick people
• Get vaccinated
• Stay hydrated
• Maintain healthy immune system

**Remember:** Fever is a symptom, not a disease. The underlying cause needs to be identified and treated.`,
    hindi: `**परिचय**

बुखार शरीर के तापमान में अस्थायी वृद्धि है, अक्सर बीमारी के कारण। सामान्य शरीर का तापमान लगभग 98.6°F (37°C) है। बुखार को आमतौर पर 100.4°F (38°C) या उससे अधिक के रूप में परिभाषित किया जाता है।

**बुखार के कारण:**
• वायरल संक्रमण (फ्लू, सर्दी, COVID-19)
• बैक्टीरियल संक्रमण
• गर्मी से थकावट
• सूजन संबंधी स्थितियां
• टीकाकरण
• कुछ दवाएं

**तापमान कब मापें:**
• यदि अस्वस्थ या गर्म महसूस हो
• बीमारी के दौरान
• बुखार की दवा देने से पहले
• तेज बुखार के दौरान नियमित निगरानी

**बुखार के लिए घरेलू देखभाल:**

**1. जलयोजन**
• भरपूर तरल पदार्थ पिएं (पानी, ORS, सूप)
• कैफीनयुक्त पेय से बचें
• बार-बार तरल पदार्थ दें
• पेशाब का रंग जांचें (हल्का पीला होना चाहिए)

**2. आराम**
• पर्याप्त नींद लें
• कठिन गतिविधि से बचें
• आरामदायक वातावरण में रहें

**3. शीतलन उपाय**
• अतिरिक्त कपड़े हटाएं
• हल्के कंबल का उपयोग करें
• कमरे का तापमान आरामदायक रखें
• माथे पर ठंडा सेक लगाएं

**4. दवाएं (पहले डॉक्टर से परामर्श लें)**
• **पैरासिटामोल/एसिटामिनोफेन:**
  - वयस्क: हर 4-6 घंटे में 500-1000mg
  - बच्चे: वजन के आधार पर डॉक्टर की सलाह के अनुसार
• **इबुप्रोफेन (यदि पैरासिटामोल अप्रभावी):**
  - वयस्क: हर 4-6 घंटे में 200-400mg
  - 6 महीने से कम उम्र के बच्चों के लिए नहीं

**न करें:**
• 18 साल से कम उम्र के बच्चों को एस्पिरिन दें
• ठंडे पानी से नहाएं
• अत्यधिक कपड़े पहनें
• डॉक्टर की सलाह के बिना दवाएं मिलाएं

**चिकित्सा सहायता कब लें:**

**वयस्क - मदद लें यदि:**
• 103°F (39.4°C) से ऊपर बुखार
• बुखार 3 दिनों से अधिक रहे
• गंभीर सिरदर्द
• गर्दन में अकड़न
• भ्रम या जागृत रहने में कठिनाई
• लगातार उल्टी
• सांस लेने में कठिनाई
• छाती या पेट में दर्द
• असामान्य त्वचा दाने

**बच्चे - तुरंत मदद लें यदि:**
• 3 महीने से कम उम्र के शिशु में 100.4°F (38°C) से ऊपर बुखार
• बच्चों में 102°F (38.9°C) से ऊपर बुखार
• दौरे के साथ बुखार
• सांस लेने में कठिनाई
• गंभीर चिड़चिड़ापन या सुस्ती
• तरल पदार्थ से इनकार
• बुखार के साथ दाने
• मलेरिया/डेंगू क्षेत्र की यात्रा के बाद बुखार

**विशेष स्थितियों में बुखार:**

**गर्भवती महिलाएं:**
• बुखार बच्चे को प्रभावित कर सकता है
• तुरंत डॉक्टर से परामर्श लें
• स्व-दवा से बचें

**बुजुर्ग:**
• गंभीर संक्रमण के बावजूद तेज बुखार नहीं दिखा सकते
• भ्रम, गिरने पर ध्यान दें
• पहले चिकित्सा ध्यान लें

**पुरानी स्थितियों वाले लोग:**
• मधुमेह, हृदय रोग, प्रतिरक्षा विकार
• बुखार गंभीर जटिलता का संकेत हो सकता है
• तुरंत डॉक्टर से संपर्क करें

**रोकथाम:**
• अच्छी स्वच्छता का अभ्यास करें
• बार-बार हाथ धोएं
• बीमार लोगों के साथ निकट संपर्क से बचें
• टीका लगवाएं
• हाइड्रेटेड रहें
• स्वस्थ प्रतिरक्षा प्रणाली बनाए रखें

**याद रखें:** बुखार एक लक्षण है, बीमारी नहीं। अंतर्निहित कारण की पहचान और उपचार की आवश्यकता है।`
  },
  7: { // Personal Hygiene
    english: `**Introduction**

Personal hygiene practices are essential for disease prevention, maintaining health, and promoting well-being. Good hygiene protects you and others from infections.

**Hand Hygiene:**

**When to Wash Hands:**
• Before eating or preparing food
• After using the toilet
• After blowing nose, coughing, or sneezing
• After touching garbage
• After touching animals
• Before and after caring for sick person
• After coming from outside

**Proper Handwashing Technique:**
1. Wet hands with clean water
2. Apply soap
3. Rub palms together
4. Rub back of hands
5. Interlace fingers and rub
6. Clean under nails
7. Wash for at least 20 seconds
8. Rinse thoroughly
9. Dry with clean towel or air dry

**Body Hygiene:**

**Daily Bathing:**
• Bath daily with soap and water
• Pay attention to underarms, groin, feet
• Use clean towel
• Change clothes daily
• Wear clean, breathable clothing

**Oral Hygiene:**
• Brush teeth twice daily (morning and night)
• Use fluoride toothpaste
• Brush for 2 minutes
• Clean tongue
• Floss daily
• Rinse after meals
• Visit dentist every 6 months
• Avoid tobacco and excessive sugar

**Hair Care:**
• Wash hair regularly (2-3 times per week)
• Use appropriate shampoo
• Keep hair tied if long
• Check for lice regularly in children
• Comb hair daily

**Nail Care:**
• Keep nails short and clean
• Trim nails regularly
• Clean under nails
• Don't bite nails
• File nails to smooth edges

**Foot Hygiene:**
• Wash feet daily
• Dry between toes thoroughly
• Wear clean socks
• Change footwear regularly
• Allow shoes to air out
• Check for cuts or infections

**Menstrual Hygiene (for women):**
• Change sanitary pads/tampons every 4-6 hours
• Wash hands before and after changing
• Dispose of used products properly
• Bath daily during periods
• Wear comfortable, clean underwear
• Keep genital area clean and dry

**Respiratory Hygiene:**
• Cover mouth and nose when coughing/sneezing
• Use tissue or elbow, not hands
• Dispose of tissues immediately
• Wash hands after coughing/sneezing
• Wear mask when sick
• Maintain distance from others when ill

**Food Hygiene:**
• Wash hands before handling food
• Keep kitchen clean
• Wash fruits and vegetables
• Cook food thoroughly
• Store food properly
• Use clean utensils
• Keep cooked and raw food separate

**Home Hygiene:**
• Clean and disinfect surfaces regularly
• Keep toilets clean
• Proper garbage disposal
• Ensure good ventilation
• Keep surroundings clean
• Avoid stagnant water

**Personal Items:**
• Don't share towels, razors, toothbrushes
• Clean and store items properly
• Replace toothbrush every 3 months
• Wash towels weekly

**Hygiene for Children:**
• Teach handwashing early
• Supervise tooth brushing
• Check for lice regularly
• Keep nails trimmed
• Ensure daily bath
• Teach proper toilet use

**Benefits of Good Hygiene:**
• Prevents infections and diseases
• Reduces spread of germs
• Improves self-confidence
• Promotes social acceptance
• Enhances overall health
• Prevents dental problems
• Reduces skin infections

**Remember:** Good hygiene is a daily practice that protects your health and the health of those around you.`,
    hindi: `**परिचय**

व्यक्तिगत स्वच्छता प्रथाएं रोग रोकथाम, स्वास्थ्य बनाए रखने और कल्याण को बढ़ावा देने के लिए आवश्यक हैं। अच्छी स्वच्छता आपको और दूसरों को संक्रमण से बचाती है।

**हाथ की स्वच्छता:**

**हाथ कब धोएं:**
• खाने या भोजन तैयार करने से पहले
• शौचालय का उपयोग करने के बाद
• नाक साफ करने, खांसने या छींकने के बाद
• कचरा छूने के बाद
• जानवरों को छूने के बाद
• बीमार व्यक्ति की देखभाल से पहले और बाद में
• बाहर से आने के बाद

**उचित हाथ धोने की तकनीक:**
1. हाथों को साफ पानी से गीला करें
2. साबुन लगाएं
3. हथेलियों को एक साथ रगड़ें
4. हाथों की पीठ रगड़ें
5. उंगलियों को इंटरलेस करें और रगड़ें
6. नाखूनों के नीचे साफ करें
7. कम से कम 20 सेकंड तक धोएं
8. अच्छी तरह से धो लें
9. साफ तौलिये से सुखाएं या हवा में सुखाएं

**शरीर की स्वच्छता:**

**दैनिक स्नान:**
• प्रतिदिन साबुन और पानी से नहाएं
• बगल, कमर, पैरों पर ध्यान दें
• साफ तौलिया उपयोग करें
• प्रतिदिन कपड़े बदलें
• साफ, सांस लेने योग्य कपड़े पहनें

**मौखिक स्वच्छता:**
• दिन में दो बार ब्रश करें (सुबह और रात)
• फ्लोराइड टूथपेस्ट का उपयोग करें
• 2 मिनट के लिए ब्रश करें
• जीभ साफ करें
• रोजाना फ्लॉस करें
• भोजन के बाद कुल्ला करें
• हर 6 महीने में दंत चिकित्सक से मिलें
• तंबाकू और अत्यधिक चीनी से बचें

**बालों की देखभाल:**
• नियमित रूप से बाल धोएं (सप्ताह में 2-3 बार)
• उपयुक्त शैंपू का उपयोग करें
• लंबे होने पर बाल बांधे रखें
• बच्चों में नियमित रूप से जूं की जांच करें
• रोजाना बाल कंघी करें

**नाखून की देखभाल:**
• नाखूनों को छोटा और साफ रखें
• नियमित रूप से नाखून काटें
• नाखूनों के नीचे साफ करें
• नाखून न काटें
• नाखूनों को चिकना करने के लिए फाइल करें

**पैर की स्वच्छता:**
• प्रतिदिन पैर धोएं
• पैर की उंगलियों के बीच अच्छी तरह से सुखाएं
• साफ मोजे पहनें
• नियमित रूप से जूते बदलें
• जूतों को हवा में सूखने दें
• कट या संक्रमण की जांच करें

**मासिक धर्म स्वच्छता (महिलाओं के लिए):**
• हर 4-6 घंटे में सैनिटरी पैड/टैम्पॉन बदलें
• बदलने से पहले और बाद में हाथ धोएं
• उपयोग किए गए उत्पादों को ठीक से निपटाएं
• पीरियड्स के दौरान रोजाना नहाएं
• आरामदायक, साफ अंडरवियर पहनें
• जननांग क्षेत्र को साफ और सूखा रखें

**श्वसन स्वच्छता:**
• खांसने/छींकते समय मुंह और नाक को ढकें
• हाथ नहीं, टिश्यू या कोहनी का उपयोग करें
• टिश्यू तुरंत फेंक दें
• खांसने/छींकने के बाद हाथ धोएं
• बीमार होने पर मास्क पहनें
• बीमार होने पर दूसरों से दूरी बनाए रखें

**खाद्य स्वच्छता:**
• भोजन संभालने से पहले हाथ धोएं
• रसोई को साफ रखें
• फल और सब्जियां धोएं
• भोजन को अच्छी तरह से पकाएं
• भोजन को ठीक से स्टोर करें
• साफ बर्तनों का उपयोग करें
• पके और कच्चे भोजन को अलग रखें

**घर की स्वच्छता:**
• नियमित रूप से सतहों को साफ और कीटाणुरहित करें
• शौचालयों को साफ रखें
• उचित कचरा निपटान
• अच्छा वेंटिलेशन सुनिश्चित करें
• आसपास को साफ रखें
• स्थिर पानी से बचें

**व्यक्तिगत वस्तुएं:**
• तौलिए, रेजर, टूथब्रश साझा न करें
• वस्तुओं को ठीक से साफ और स्टोर करें
• हर 3 महीने में टूथब्रश बदलें
• सप्ताह में तौलिये धोएं

**बच्चों के लिए स्वच्छता:**
• जल्दी हाथ धोना सिखाएं
• दांत ब्रश करने की निगरानी करें
• नियमित रूप से जूं की जांच करें
• नाखून कटे रखें
• रोजाना नहाना सुनिश्चित करें
• उचित शौचालय उपयोग सिखाएं

**अच्छी स्वच्छता के लाभ:**
• संक्रमण और रोगों को रोकता है
• रोगाणुओं के प्रसार को कम करता है
• आत्मविश्वास में सुधार करता है
• सामाजिक स्वीकृति को बढ़ावा देता है
• समग्र स्वास्थ्य बढ़ाता है
• दंत समस्याओं को रोकता है
• त्वचा संक्रमण को कम करता है

**याद रखें:** अच्छी स्वच्छता एक दैनिक अभ्यास है जो आपके स्वास्थ्य और आपके आसपास के लोगों के स्वास्थ्य की रक्षा करता है।`
  },
  8: { // Exercise
    english: `**Introduction**

Regular physical activity is essential for maintaining good health, preventing diseases, and improving quality of life. Exercise benefits both physical and mental health.

**Benefits of Regular Exercise:**
• Strengthens heart and improves circulation
• Helps maintain healthy weight
• Reduces risk of chronic diseases
• Strengthens bones and muscles
• Improves mental health and mood
• Boosts energy levels
• Promotes better sleep
• Increases lifespan

**Recommended Physical Activity:**

**Adults (18-64 years):**
• At least 150 minutes of moderate-intensity aerobic activity per week
• OR 75 minutes of vigorous-intensity activity per week
• Muscle-strengthening activities 2+ days per week
• Break up prolonged sitting time

**Older Adults (65+ years):**
• Same as adults, but adjust intensity
• Balance and fall prevention exercises
• Flexibility exercises
• Start slowly and gradually increase

**Children & Adolescents:**
• At least 60 minutes of activity daily
• Mix of aerobic, muscle-strengthening, and bone-strengthening
• Reduce screen time
• Encourage outdoor play

**Types of Exercise:**

**1. Aerobic/Cardio Exercise:**
• Walking (easy and accessible)
• Jogging/Running
• Cycling
• Swimming
• Dancing
• Climbing stairs

**2. Strength Training:**
• Body-weight exercises (push-ups, squats)
• Lifting weights
• Resistance band exercises
• Yoga
• Functional movements

**3. Flexibility Exercises:**
• Stretching
• Yoga
• Pilates
• Tai Chi

**4. Balance Exercises:**
• Standing on one foot
• Heel-to-toe walk
• Yoga poses
• Tai Chi movements

**Starting an Exercise Program:**

**Week 1-2:**
• Start with 10-15 minutes daily
• Choose activities you enjoy
• Walk at comfortable pace
• Light stretching

**Week 3-4:**
• Increase to 20-30 minutes
• Add variety
• Slightly increase intensity
• Include warm-up and cool-down

**Month 2+:**
• Aim for 30-60 minutes most days
• Mix different types of exercise
• Set specific goals
• Track progress

**Exercise Guidelines:**

**Before Exercise:**
• Warm up for 5-10 minutes
• Wear comfortable clothing and shoes
• Stay hydrated
• Don't exercise on full stomach

**During Exercise:**
• Start slowly and progress gradually
• Listen to your body
• Maintain proper form
• Breathe normally
• Stay hydrated

**After Exercise:**
• Cool down for 5-10 minutes
• Stretch major muscle groups
• Rehydrate
• Note how you feel

**Safety Tips:**
• Consult doctor before starting if you have health conditions
• Stop if you experience chest pain, dizziness, or severe breathlessness
• Avoid extreme weather conditions
• Exercise in safe, well-lit areas
• Use proper equipment
• Don't overdo it

**Exercise for Special Conditions:**

**Diabetes:**
• Regular exercise helps control blood sugar
• Check blood sugar before and after exercise
• Carry quick-sugar snacks
• Exercise at same time daily

**Heart Disease:**
• Cardiac rehabilitation programs
• Gradual increase in activity
• Monitor heart rate
• Avoid heavy lifting initially

**Arthritis:**
• Low-impact exercises (swimming, cycling)
• Gentle stretching
• Avoid high-impact activities
• Exercise during times of less pain

**Pregnancy:**
• Moderate exercise is safe
• Walking, swimming, prenatal yoga
• Avoid contact sports
• Stop if uncomfortable

**Staying Motivated:**
• Set realistic goals
• Exercise with friend or family
• Mix up your routine
• Track progress
• Reward yourself
• Join a class or group
• Make it fun

**Common Barriers & Solutions:**

**"No Time"**
• Break into 10-minute sessions
• Exercise during lunch break
• Walk or cycle for errands
• Do exercises while watching TV

**"Too Tired"**
• Exercise actually boosts energy
• Start with light activity
• Exercise in morning

**"Too Expensive"**
• Walking is free
• Use body weight exercises
• Exercise at home
• Use free online videos

**Remember:** Any amount of physical activity is better than none. Start where you are, use what you have, and do what you can.`,
    hindi: `**परिचय**

नियमित शारीरिक गतिविधि अच्छे स्वास्थ्य को बनाए रखने, रोगों को रोकने और जीवन की गुणवत्ता में सुधार के लिए आवश्यक है। व्यायाम शारीरिक और मानसिक स्वास्थ्य दोनों को लाभ पहुंचाता है।

**नियमित व्यायाम के लाभ:**
• हृदय को मजबूत बनाता है और परिसंचरण में सुधार करता है
• स्वस्थ वजन बनाए रखने में मदद करता है
• पुरानी बीमारियों के जोखिम को कम करता है
• हड्डियों और मांसपेशियों को मजबूत बनाता है
• मानसिक स्वास्थ्य और मनोदशा में सुधार करता है
• ऊर्जा स्तर बढ़ाता है
• बेहतर नींद को बढ़ावा देता है
• जीवनकाल बढ़ाता है

**अनुशंसित शारीरिक गतिविधि:**

**वयस्क (18-64 वर्ष):**
• प्रति सप्ताह कम से कम 150 मिनट मध्यम-तीव्रता की एरोबिक गतिविधि
• या प्रति सप्ताह 75 मिनट की जोरदार-तीव्रता गतिविधि
• सप्ताह में 2+ दिन मांसपेशी-मजबूती गतिविधियां
• लंबे समय तक बैठने के समय को तोड़ें

**वृद्ध वयस्क (65+ वर्ष):**
• वयस्कों के समान, लेकिन तीव्रता समायोजित करें
• संतुलन और गिरने की रोकथाम व्यायाम
• लचीलापन व्यायाम
• धीरे-धीरे शुरू करें और धीरे-धीरे बढ़ाएं

**बच्चे और किशोर:**
• प्रतिदिन कम से कम 60 मिनट की गतिविधि
• एरोबिक, मांसपेशी-मजबूती और हड्डी-मजबूती का मिश्रण
• स्क्रीन समय कम करें
• बाहरी खेल को प्रोत्साहित करें

**व्यायाम के प्रकार:**

**1. एरोबिक/कार्डियो व्यायाम:**
• चलना (आसान और सुलभ)
• जॉगिंग/दौड़ना
• साइकिल चलाना
• तैराकी
• नृत्य
• सीढ़ियां चढ़ना

**2. शक्ति प्रशिक्षण:**
• शरीर-वजन व्यायाम (पुश-अप्स, स्क्वाट्स)
• वजन उठाना
• प्रतिरोध बैंड व्यायाम
• योग
• कार्यात्मक गतिविधियां

**3. लचीलापन व्यायाम:**
• स्ट्रेचिंग
• योग
• पाइलेट्स
• ताई ची

**4. संतुलन व्यायाम:**
• एक पैर पर खड़े होना
• एड़ी-से-पैर की उंगलियों तक चलना
• योग मुद्राएं
• ताई ची गतिविधियां

**व्यायाम कार्यक्रम शुरू करना:**

**सप्ताह 1-2:**
• प्रतिदिन 10-15 मिनट से शुरू करें
• ऐसी गतिविधियां चुनें जिनका आप आनंद लेते हैं
• आरामदायक गति से चलें
• हल्की स्ट्रेचिंग

**सप्ताह 3-4:**
• 20-30 मिनट तक बढ़ाएं
• विविधता जोड़ें
• तीव्रता थोड़ी बढ़ाएं
• वार्म-अप और कूल-डाउन शामिल करें

**महीना 2+:**
• अधिकांश दिनों में 30-60 मिनट का लक्ष्य रखें
• विभिन्न प्रकार के व्यायाम मिलाएं
• विशिष्ट लक्ष्य निर्धारित करें
• प्रगति ट्रैक करें

**व्यायाम दिशानिर्देश:**

**व्यायाम से पहले:**
• 5-10 मिनट के लिए वार्म अप करें
• आरामदायक कपड़े और जूते पहनें
• हाइड्रेटेड रहें
• पेट भरने पर व्यायाम न करें

**व्यायाम के दौरान:**
• धीरे-धीरे शुरू करें और धीरे-धीरे आगे बढ़ें
• अपने शरीर को सुनें
• उचित फॉर्म बनाए रखें
• सामान्य रूप से सांस लें
• हाइड्रेटेड रहें

**व्यायाम के बाद:**
• 5-10 मिनट के लिए कूल डाउन करें
• प्रमुख मांसपेशी समूहों को स्ट्रेच करें
• फिर से हाइड्रेट करें
• नोट करें कि आप कैसा महसूस करते हैं

**सुरक्षा युक्तियाँ:**
• यदि आपके स्वास्थ्य स्थितियां हैं तो शुरू करने से पहले डॉक्टर से परामर्श लें
• छाती में दर्द, चक्कर या गंभीर सांस फूलने पर रुकें
• अत्यधिक मौसम की स्थिति से बचें
• सुरक्षित, अच्छी तरह से प्रकाशित क्षेत्रों में व्यायाम करें
• उचित उपकरण का उपयोग करें
• ज्यादा न करें

**विशेष स्थितियों के लिए व्यायाम:**

**मधुमेह:**
• नियमित व्यायाम रक्त शर्करा को नियंत्रित करने में मदद करता है
• व्यायाम से पहले और बाद में रक्त शर्करा जांचें
• त्वरित-चीनी स्नैक्स ले जाएं
• प्रतिदिन एक ही समय पर व्यायाम करें

**हृदय रोग:**
• कार्डियक पुनर्वास कार्यक्रम
• गतिविधि में धीरे-धीरे वृद्धि
• हृदय गति की निगरानी करें
• शुरुआत में भारी भार उठाने से बचें

**गठिया:**
• कम-प्रभाव व्यायाम (तैराकी, साइकिल चलाना)
• कोमल स्ट्रेचिंग
• उच्च-प्रभाव गतिविधियों से बचें
• कम दर्द के समय व्यायाम करें

**गर्भावस्था:**
• मध्यम व्यायाम सुरक्षित है
• चलना, तैराकी, प्रसवपूर्व योग
• संपर्क खेलों से बचें
• असहज होने पर रुकें

**प्रेरित रहना:**
• यथार्थवादी लक्ष्य निर्धारित करें
• दोस्त या परिवार के साथ व्यायाम करें
• अपनी दिनचर्या मिलाएं
• प्रगति ट्रैक करें
• खुद को पुरस्कृत करें
• एक कक्षा या समूह में शामिल हों
• इसे मजेदार बनाएं

**सामान्य बाधाएं और समाधान:**

**"समय नहीं"**
• 10-मिनट के सत्रों में तोड़ें
• लंच ब्रेक के दौरान व्यायाम करें
• कामों के लिए चलें या साइकिल चलाएं
• टीवी देखते समय व्यायाम करें

**"बहुत थका हुआ"**
• व्यायाम वास्तव में ऊर्जा बढ़ाता है
• हल्की गतिविधि से शुरू करें
• सुबह व्यायाम करें

**"बहुत महंगा"**
• चलना मुफ्त है
• शरीर वजन व्यायाम उपयोग करें
• घर पर व्यायाम करें
• मुफ्त ऑनलाइन वीडियो उपयोग करें

**याद रखें:** किसी भी मात्रा में शारीरिक गतिविधि कुछ न होने से बेहतर है। जहां आप हैं वहां से शुरू करें, जो आपके पास है उसका उपयोग करें, और जो आप कर सकते हैं वह करें।`
  }
};

export function HealthArticleDetailModal({ article, onClose, textSize }: HealthArticleDetailModalProps) {
  const Icon = article.icon;
  const content = articleContent[article.id] || { english: 'Content coming soon...', hindi: 'सामग्री जल्द आ रही है...' };

  const getTextSizeClass = () => {
    switch (textSize) {
      case 'small': return 'text-xs';
      case 'large': return 'text-base';
      default: return 'text-sm';
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/70 z-50"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed inset-4 z-50 flex items-center justify-center">
        <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className={`sticky top-0 bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-5 rounded-t-3xl`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`${article.iconBg} rounded-2xl p-3`}>
                  <Icon className="w-7 h-7 text-gray-700" />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold">{article.title}</h2>
                  <p className="text-sm text-cyan-100">{article.titleHindi}</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <span className={`inline-block text-xs px-3 py-1 rounded-full bg-white/30`}>
              {article.category}
            </span>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Audio Button */}
            {article.hasAudio && (
              <div className="mb-6">
                <button className="w-full bg-cyan-500 text-white py-3 px-4 rounded-xl font-medium hover:bg-cyan-600 transition-colors flex items-center justify-center gap-2">
                  <Volume2 className="w-5 h-5" />
                  Listen to Article / लेख सुनें
                </button>
              </div>
            )}

            {/* English Content */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-gray-700" />
                <h3 className="font-bold text-gray-900 text-lg">English Content</h3>
              </div>
              <div className={`${getTextSizeClass()} text-gray-700 leading-relaxed whitespace-pre-line`}>
                {content.english}
              </div>
            </div>

            {/* Divider */}
            <div className="border-t-2 border-gray-200 my-6" />

            {/* Hindi Content */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <BookOpen className="w-5 h-5 text-gray-700" />
                <h3 className="font-bold text-gray-900 text-lg">हिंदी सामग्री</h3>
              </div>
              <div className={`${getTextSizeClass()} text-gray-700 leading-relaxed whitespace-pre-line`}>
                {content.hindi}
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="w-full bg-gray-900 text-white py-4 rounded-2xl font-bold mt-8 hover:bg-gray-800 transition-colors"
            >
              Close / बंद करें
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
