import {
  Menu,
  Bell,
  ShieldCheck,
  Clock,
  Heart,
  TrendingUp,
  MessageCircle,
  Pill,
  FileText,
  User,
  MapPin,
  BookOpen,
  Settings,
  HelpCircle,
  Globe,
  Phone,
  Ambulance,
  Building2,
  X,
  Home,
  ClipboardCheck,
  LogOut,
  ChevronUp,
  ChevronDown,
  Users,
  Gift,
  Info,
  AlertTriangle,
  AlertCircle,
  Shield,
  Activity,
  Baby,
  UserCheck,
  Droplets,
  Flame
} from 'lucide-react';
import { useState } from 'react';

interface DashboardScreenProps {
  userName: string;
  language?: string;
  onNavigateToHealthAssistant: () => void;
  onNavigateToNotifications: () => void;
  onNavigateToMedicationReminder: () => void;
  onNavigateToGovernmentSchemes: () => void;
  onNavigateToProfile?: () => void;
  onNavigateToMedicalMaps?: () => void;
  onNavigateToHealthInformation?: () => void;
  onNavigateToSettings?: () => void;
  onNavigateToPreVisit?: () => void;
  onNavigateToHelpSupport?: () => void;
}

export function DashboardScreen({ userName, language, onNavigateToHealthAssistant, onNavigateToNotifications, onNavigateToMedicationReminder, onNavigateToGovernmentSchemes, onNavigateToProfile, onNavigateToMedicalMaps, onNavigateToHealthInformation, onNavigateToSettings, onNavigateToPreVisit, onNavigateToHelpSupport }: DashboardScreenProps) {
  const [showEmergencyNumbers, setShowEmergencyNumbers] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [showOtherNumbers, setShowOtherNumbers] = useState(true);
  const [showLanguageSwitcher, setShowLanguageSwitcher] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <button className="p-2" onClick={() => setShowSidebar(true)}>
            <Menu className="w-6 h-6" />
          </button>
          <button className="p-2" onClick={onNavigateToNotifications}>
            <Bell className="w-6 h-6" />
          </button>
        </div>

        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-sm opacity-90">नमस्ते / Hello</p>
            <h1 className="text-3xl">{userName}</h1>
          </div>
          <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full">
            <ShieldCheck className="w-5 h-5" />
            <span className="text-sm">Verified</span>
          </div>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white/95 rounded-2xl p-4 text-center">
            <Clock className="w-6 h-6 text-cyan-500 mx-auto mb-2" />
            <p className="text-xs text-gray-600 mb-1">Last Consultation</p>
            <p className="text-sm text-gray-900">2 days ago</p>
          </div>
          <div className="bg-white/95 rounded-2xl p-4 text-center">
            <Heart className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <p className="text-xs text-gray-600 mb-1">Health Score</p>
            <p className="text-sm text-gray-900">Good</p>
          </div>
          <div className="bg-white/95 rounded-2xl p-4 text-center">
            <TrendingUp className="w-6 h-6 text-blue-500 mx-auto mb-2" />
            <p className="text-xs text-gray-600 mb-1">Active Days</p>
            <p className="text-sm text-gray-900">12 days</p>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="px-6 py-6 pb-24">
        {/* Quick Actions */}
        <section className="mb-8">
          <h2 className="text-xl mb-4">त्वरित कार्य / Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <ActionCard
              icon={<MessageCircle className="w-8 h-8 text-white" />}
              bgColor="bg-cyan-400"
              title="स्वास्थ्य प्रश्न पूछें"
              subtitle="Ask Health Question"
              onClick={onNavigateToHealthAssistant}
            />
            <ActionCard
              icon={<Pill className="w-8 h-8 text-white" />}
              bgColor="bg-green-500"
              title="दवा अनुस्मारक"
              subtitle="Medication Reminders"
              onClick={onNavigateToMedicationReminder}
            />
            <ActionCard
              icon={<Building2 className="w-8 h-8 text-white" />}
              bgColor="bg-purple-500"
              title="सरकारी योजनाएं"
              subtitle="Government Schemes"
              onClick={onNavigateToGovernmentSchemes}
            />
            <ActionCard
              icon={<User className="w-8 h-8 text-white" />}
              bgColor="bg-orange-500"
              title="प्रोफ़ाइल"
              subtitle="Profile"
              onClick={onNavigateToProfile}
            />
            <ActionCard
              icon={<MapPin className="w-8 h-8 text-white" />}
              bgColor="bg-red-500"
              title="निकटतम अस्पताल"
              subtitle="Nearby Hospitals"
              onClick={onNavigateToMedicalMaps}
            />
            <ActionCard
              icon={<BookOpen className="w-8 h-8 text-white" />}
              bgColor="bg-blue-600"
              title="स्वास्थ्य लेख"
              subtitle="Health Articles"
              onClick={onNavigateToHealthInformation}
            />
            <ActionCard
              icon={<Settings className="w-8 h-8 text-white" />}
              bgColor="bg-gray-600"
              title="सेटिंग्स"
              subtitle="Settings"
              onClick={onNavigateToSettings}
            />
          </div>
        </section>

        {/* Pre-Visit Preparation */}
        <section className="mb-8">
          <button 
            onClick={onNavigateToPreVisit}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-3xl p-6 text-white flex items-center gap-4 hover:shadow-lg transition-shadow"
          >
            <div className="bg-white/20 p-4 rounded-2xl">
              <FileText className="w-8 h-8" />
            </div>
            <div className="text-left flex-1">
              <h3 className="text-xl mb-1">Pre-Visit Preparation</h3>
              <p className="text-sm opacity-90">Get ready before visiting doctor or hospital</p>
            </div>
          </button>
        </section>

        {/* Recent Topics */}
        <section className="mb-8">
          <h2 className="text-xl mb-4">हाल के विषय / Recent Topics</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            <TopicTag text="बुखार और खांसी" />
            <TopicTag text="पेट दर्द" />
            <TopicTag text="सिरदर्द" />
          </div>
        </section>

        {/* Today's Health Tip */}
        <section className="mb-8">
          <div className="bg-cyan-50 border-2 border-cyan-100 rounded-3xl p-6">
            <div className="flex items-start gap-3 mb-4">
              <Heart className="w-6 h-6 text-red-500 fill-red-500 flex-shrink-0" />
              <h3 className="text-xl">Today's Health Tip</h3>
            </div>
            <p className="text-gray-700 mb-4">
              Stay hydrated! Drink at least 8 glasses of water daily to maintain good health and boost immunity.
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>Today</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>General Health</span>
              </div>
            </div>
          </div>
        </section>

        {/* Emergency Health Numbers */}
        <section>
          <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-6">
            <div className="flex items-start gap-4 mb-4">
              <div className="bg-red-500 p-3 rounded-full">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl mb-1">Emergency Health Numbers</h3>
                <p className="text-sm text-red-600">आपातकालीन स्वास्थ्य नंबर</p>
              </div>
            </div>

            <div className="bg-red-600 hover:bg-red-700 text-white rounded-2xl p-4 flex items-center gap-4 mb-4 cursor-pointer transition-colors">
              <div className="bg-white/20 p-3 rounded-xl">
                <Ambulance className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <p className="text-lg mb-1">108 - Ambulance</p>
                <p className="text-sm opacity-90">एम्बुलेंस सेवा (24/7)</p>
              </div>
              <Phone className="w-6 h-6" />
            </div>

            <button
              onClick={() => setShowEmergencyNumbers(!showEmergencyNumbers)}
              className="w-full bg-white border-2 border-red-200 hover:border-red-300 text-red-600 py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <span>View All Emergency Numbers (+7 अधिक)</span>
              {showEmergencyNumbers ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </button>

            {/* Expandable Emergency Numbers */}
            {showEmergencyNumbers && (
              <div className="mt-4 space-y-3 animate-in slide-in-from-top-2">
                {/* 102 - Health Helpline */}
                <a 
                  href="tel:102" 
                  className="block bg-pink-50 border-2 border-pink-200 rounded-2xl p-4 hover:bg-pink-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-pink-100 rounded-full p-2">
                        <Heart className="w-5 h-5 text-pink-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">102 - Health Helpline</p>
                        <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य हेल्पलाइन</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-pink-600" />
                  </div>
                </a>

                {/* 104 - National Health */}
                <a 
                  href="tel:104" 
                  className="block bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 hover:bg-blue-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 rounded-full p-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">104 - National Health</p>
                        <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य पोर्टल</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-blue-600" />
                  </div>
                </a>

                {/* 1075 - Mother & Child */}
                <a 
                  href="tel:1075" 
                  className="block bg-pink-50 border-2 border-pink-200 rounded-2xl p-4 hover:bg-pink-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-pink-100 rounded-full p-2">
                        <Baby className="w-5 h-5 text-pink-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">1075 - Mother & Child</p>
                        <p className="text-sm text-gray-600">गर्भावस्था व बाल देखभाल</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-pink-600" />
                  </div>
                </a>

                {/* 14410 - Ayushman Bharat */}
                <a 
                  href="tel:14410" 
                  className="block bg-orange-50 border-2 border-orange-200 rounded-2xl p-4 hover:bg-orange-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-orange-100 rounded-full p-2">
                        <Gift className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">14410 - Ayushman Bharat</p>
                        <p className="text-sm text-gray-600">आयुष्मान भारत योजना</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-orange-600" />
                  </div>
                </a>

                {/* 011-23978046 - Mental Health */}
                <a 
                  href="tel:01123978046" 
                  className="block bg-purple-50 border-2 border-purple-200 rounded-2xl p-4 hover:bg-purple-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 rounded-full p-2">
                        <Activity className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">011-23978046 - Mental Health</p>
                        <p className="text-sm text-gray-600">मानसिक स्वास्थ्य हेल्पलाइन</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-purple-600" />
                  </div>
                </a>

                {/* 1800-599-0019 - COVID-19 */}
                <a 
                  href="tel:18005990019" 
                  className="block bg-green-50 border-2 border-green-200 rounded-2xl p-4 hover:bg-green-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 rounded-full p-2">
                        <Info className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">1800-599-0019 - COVID-19</p>
                        <p className="text-sm text-gray-600">कोविड-19 हेल्पलाइन</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-green-600" />
                  </div>
                </a>

                {/* 1800-11-4995 - Poison Control */}
                <a 
                  href="tel:1800114995" 
                  className="block bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 hover:bg-yellow-100 transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-yellow-100 rounded-full p-2">
                        <AlertTriangle className="w-5 h-5 text-yellow-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">1800-11-4995 - Poison Control</p>
                        <p className="text-sm text-gray-600">विष नियंत्रण केंद्र</p>
                      </div>
                    </div>
                    <Phone className="w-5 h-5 text-yellow-600" />
                  </div>
                </a>

                {/* Important Note */}
                <div className="bg-red-100 border-2 border-red-200 rounded-2xl p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-red-900 font-medium mb-1">आपातकालीन नोट / Emergency Note</p>
                      <p className="text-xs text-red-800">
                        All numbers are toll-free and available 24/7. In critical emergency, call 108 immediately.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Footer text */}
        <div className="mt-8 flex items-start gap-2 text-sm text-gray-600">
          <Heart className="w-4 h-4 text-red-500 fill-red-500 flex-shrink-0 mt-0.5" />
          <p className="italic">Built with a safety-first approach for people and families.</p>
        </div>
      </main>

      {/* Floating action buttons - REMOVED (redundant, all features accessible via main UI) */}
      {/* <div className="fixed bottom-6 right-6 flex flex-col gap-3">
        <button className="bg-gray-900 text-white p-4 rounded-full shadow-lg hover:bg-gray-800 transition-colors">
          <HelpCircle className="w-6 h-6" />
        </button>
        <button className="bg-cyan-500 text-white p-4 rounded-full shadow-lg hover:bg-cyan-600 transition-colors">
          <Globe className="w-6 h-6" />
        </button>
      </div> */}

      {/* Sidebar Menu */}
      {showSidebar && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/50 z-40"
            onClick={() => setShowSidebar(false)}
          />
          
          {/* Sidebar */}
          <div className="fixed top-0 left-0 bottom-0 w-80 bg-white z-50 overflow-y-auto shadow-2xl">
            {/* Header */}
            <div className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white px-5 py-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Menu</h2>
                <button 
                  onClick={() => setShowSidebar(false)}
                  className="p-1 hover:bg-white/20 rounded-lg transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              {/* User Info */}
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-3">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-bold">{userName}</p>
                  <p className="text-sm text-cyan-100">Verified User</p>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="p-4">
              {/* MAIN Section */}
              <div className="mb-6">
                <p className="text-xs font-semibold text-gray-500 mb-3 px-3">MAIN</p>
                
                <button 
                  onClick={() => {
                    setShowSidebar(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-cyan-50 transition-colors"
                >
                  <div className="bg-cyan-100 rounded-xl p-2">
                    <Home className="w-5 h-5 text-cyan-600" />
                  </div>
                  <span className="font-medium text-gray-900">Dashboard</span>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToProfile?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-purple-50 transition-colors"
                >
                  <div className="bg-purple-100 rounded-xl p-2">
                    <User className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">My Profile</p>
                    <p className="text-xs text-gray-500">View & edit profile</p>
                  </div>
                </button>
              </div>

              {/* HEALTH SERVICES Section */}
              <div className="mb-6">
                <p className="text-xs font-semibold text-gray-500 mb-3 px-3">HEALTH SERVICES</p>
                
                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToHealthAssistant();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-cyan-50 transition-colors"
                >
                  <div className="bg-cyan-100 rounded-xl p-2">
                    <MessageCircle className="w-5 h-5 text-cyan-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Ask Health Question</p>
                    <p className="text-xs text-gray-500">AI health assistant</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToMedicationReminder();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-green-50 transition-colors"
                >
                  <div className="bg-green-100 rounded-xl p-2">
                    <Pill className="w-5 h-5 text-green-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Medication Reminders</p>
                    <p className="text-xs text-gray-500">Never miss a dose</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToPreVisit?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-blue-50 transition-colors"
                >
                  <div className="bg-blue-100 rounded-xl p-2">
                    <ClipboardCheck className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Pre-Visit Guide</p>
                    <p className="text-xs text-gray-500">Prepare for doctor visit</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToMedicalMaps?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 transition-colors"
                >
                  <div className="bg-red-100 rounded-xl p-2">
                    <MapPin className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Nearby Hospitals</p>
                    <p className="text-xs text-gray-500">Find hospitals near you</p>
                  </div>
                </button>
              </div>

              {/* RESOURCES Section */}
              <div className="mb-6">
                <p className="text-xs font-semibold text-gray-500 mb-3 px-3">RESOURCES</p>
                
                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToHealthInformation?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-blue-50 transition-colors"
                >
                  <div className="bg-blue-100 rounded-xl p-2">
                    <BookOpen className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Health Articles</p>
                    <p className="text-xs text-gray-500">22 articles across 7 topics</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToGovernmentSchemes();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-blue-50 transition-colors"
                >
                  <div className="bg-blue-100 rounded-xl p-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-medium text-gray-900">Government Schemes</p>
                    <p className="text-xs text-gray-500">Health benefits & schemes</p>
                  </div>
                </button>
              </div>

              {/* EMERGENCY Section */}
              <div className="mb-6">
                <p className="text-xs font-semibold text-gray-500 mb-3 px-3">EMERGENCY</p>
                
                <button 
                  onClick={() => {
                    setShowEmergencyModal(true);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 transition-colors"
                >
                  <div className="bg-red-100 rounded-xl p-2">
                    <Phone className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="text-left flex-1">
                    <p className="font-bold text-red-600">Emergency Numbers</p>
                    <p className="text-xs text-red-500">View all emergency contacts</p>
                  </div>
                </button>
              </div>

              {/* SETTINGS & MORE Section */}
              <div className="mb-6">
                <p className="text-xs font-semibold text-gray-500 mb-3 px-3">SETTINGS & MORE</p>
                
                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToSettings?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="bg-gray-100 rounded-xl p-2">
                    <Settings className="w-5 h-5 text-gray-600" />
                  </div>
                  <span className="font-medium text-gray-900">Settings</span>
                </button>

                <button 
                  onClick={() => {
                    setShowSidebar(false);
                    onNavigateToHelpSupport?.();
                  }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="bg-gray-100 rounded-xl p-2">
                    <HelpCircle className="w-5 h-5 text-gray-600" />
                  </div>
                  <span className="font-medium text-gray-900">Help & Support</span>
                </button>
              </div>

              {/* Logout */}
              <button 
                className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-red-50 transition-colors mb-6"
              >
                <div className="bg-red-100 rounded-xl p-2">
                  <LogOut className="w-5 h-5 text-red-600" />
                </div>
                <span className="font-medium text-red-600">Logout</span>
              </button>

              {/* Footer */}
              <div className="text-center pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">Health Companion App</p>
                <p className="text-xs text-gray-400">Version 1.0.0</p>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Emergency Numbers Modal */}
      {showEmergencyModal && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/60 z-50"
            onClick={() => setShowEmergencyModal(false)}
          />
          
          {/* Modal */}
          <div className="fixed inset-4 z-50 flex items-center justify-center">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="sticky top-0 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white px-6 py-4 rounded-t-3xl">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">Emergency Numbers</h2>
                  <button 
                    onClick={() => setShowEmergencyModal(false)}
                    className="p-1 hover:bg-white/20 rounded-lg transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                <p className="text-sm text-cyan-100 mt-1">आपातकालीन नंबर</p>
              </div>

              {/* Content */}
              <div className="p-5">
                {/* 108 - Ambulance - Always Visible */}
                <a href="tel:108" className="block bg-red-500 text-white rounded-2xl p-4 mb-4 hover:bg-red-600 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="bg-white/20 rounded-full p-3">
                        <Ambulance className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">108 - Ambulance</h3>
                        <p className="text-sm text-red-100">एम्बुलेंस सेवा (24/7)</p>
                      </div>
                    </div>
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                </a>

                {/* Toggle Other Numbers */}
                <button
                  onClick={() => setShowOtherNumbers(!showOtherNumbers)}
                  className="w-full bg-gray-100 text-gray-700 py-3 px-4 rounded-2xl flex items-center justify-center gap-2 font-medium hover:bg-gray-200 transition-colors mb-4"
                >
                  <span>{showOtherNumbers ? 'Hide' : 'Show'} Other Numbers अन्य नंबर {showOtherNumbers ? 'छुपाएं' : 'दिखाएं'}</span>
                  {showOtherNumbers ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>

                {/* Other Emergency Numbers */}
                {showOtherNumbers && (
                  <div className="space-y-3">
                    {/* 102 - Health Helpline */}
                    <a href="tel:102" className="block bg-pink-50 border-2 border-pink-200 rounded-2xl p-4 hover:bg-pink-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-pink-100 rounded-full p-2">
                            <Heart className="w-5 h-5 text-pink-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">102 - Health Helpline</h3>
                            <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य हेल्पलाइन</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-pink-600" />
                      </div>
                    </a>

                    {/* 104 - National Health */}
                    <a href="tel:104" className="block bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 hover:bg-blue-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-100 rounded-full p-2">
                            <Phone className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">104 - National Health</h3>
                            <p className="text-sm text-gray-600">राष्ट्रीय स्वास्थ्य पोर्टल</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-blue-600" />
                      </div>
                    </a>

                    {/* 1075 - Mother & Child */}
                    <a href="tel:1075" className="block bg-pink-50 border-2 border-pink-200 rounded-2xl p-4 hover:bg-pink-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-pink-100 rounded-full p-2">
                            <Users className="w-5 h-5 text-pink-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">1075 - Mother & Child</h3>
                            <p className="text-sm text-gray-600">गर्भावस्था व बाल देखभाल</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-pink-600" />
                      </div>
                    </a>

                    {/* 14410 - Ayushman Bharat */}
                    <a href="tel:14410" className="block bg-orange-50 border-2 border-orange-200 rounded-2xl p-4 hover:bg-orange-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-orange-100 rounded-full p-2">
                            <Gift className="w-5 h-5 text-orange-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">14410 - Ayushman Bharat</h3>
                            <p className="text-sm text-gray-600">आयुष्मान भारत योजना</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-orange-600" />
                      </div>
                    </a>

                    {/* 011-23978046 - Mental Health */}
                    <a href="tel:01123978046" className="block bg-purple-50 border-2 border-purple-200 rounded-2xl p-4 hover:bg-purple-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-purple-100 rounded-full p-2">
                            <Heart className="w-5 h-5 text-purple-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">011-23978046 - Mental Health</h3>
                            <p className="text-sm text-gray-600">मानसिक स्वास्थ्य हेल्पलाइन</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-purple-600" />
                      </div>
                    </a>

                    {/* 1800-599-0019 - COVID-19 */}
                    <a href="tel:18005990019" className="block bg-green-50 border-2 border-green-200 rounded-2xl p-4 hover:bg-green-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-green-100 rounded-full p-2">
                            <Info className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">1800-599-0019 - COVID-19</h3>
                            <p className="text-sm text-gray-600">कोविड-19 हेल्पलाइन</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-green-600" />
                      </div>
                    </a>

                    {/* 1800-11-4995 - Poison Control */}
                    <a href="tel:1800114995" className="block bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 hover:bg-yellow-100 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="bg-yellow-100 rounded-full p-2">
                            <AlertTriangle className="w-5 h-5 text-yellow-600" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">1800-11-4995 - Poison Control</h3>
                            <p className="text-sm text-gray-600">विष नियंत्रण केंद्र</p>
                          </div>
                        </div>
                        <Phone className="w-5 h-5 text-yellow-600" />
                      </div>
                    </a>
                  </div>
                )}

                {/* Emergency Note */}
                <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4 mt-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-red-900 mb-1">Emergency Note</h4>
                      <p className="text-sm text-red-800 mb-2">
                        In case of life-threatening emergency, call 108 immediately. All numbers are toll-free and available 24/7.
                      </p>
                      <p className="text-sm text-red-800">
                        आपातकालीन स्थिति में तुरंत 108 पर कॉल करें। सभी नंबर टोल-फ्री और 24/7 उपलब्ध हैं।
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

interface ActionCardProps {
  icon: React.ReactNode;
  bgColor: string;
  title: string;
  subtitle: string;
  onClick?: () => void;
}

function ActionCard({ icon, bgColor, title, subtitle, onClick }: ActionCardProps) {
  return (
    <div className="bg-white rounded-2xl p-6 text-center hover:shadow-lg transition-shadow cursor-pointer" onClick={onClick}>
      <div className={`${bgColor} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3`}>
        {icon}
      </div>
      <p className="text-sm mb-1">{title}</p>
      <p className="text-xs text-cyan-600">{subtitle}</p>
    </div>
  );
}

function TopicTag({ text }: { text: string }) {
  return (
    <div className="bg-cyan-100 text-cyan-700 px-4 py-2 rounded-full text-sm whitespace-nowrap">
      {text}
    </div>
  );
}