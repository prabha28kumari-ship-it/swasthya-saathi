import { useState } from 'react';
import { ArrowLeft, Settings, Search, Heart, Baby, Thermometer, Brain, Building2, AlertTriangle, Bell, Phone, Volume2, ChevronRight, Check, X, BookOpen, Eye } from 'lucide-react';
import { HealthArticleDetailModal } from '@/app/components/HealthArticleDetailModal';

interface HealthInformationScreenProps {
  onBack: () => void;
}

type TabType = 'healthTopics' | 'emergencyInfo' | 'localAlerts' | 'govtSchemes';
type CategoryType = 'all' | 'preventive' | 'maternal' | 'common' | 'mental' | 'govt' | 'emergency' | 'local';

interface HealthArticle {
  id: number;
  title: string;
  titleHindi: string;
  category: string;
  categoryColor: string;
  description: string;
  descriptionHindi: string;
  icon: any;
  iconBg: string;
  hasAudio: boolean;
  detailedContent?: string;
  detailedContentHindi?: string;
}

interface EmergencyContact {
  number: string;
  name: string;
  nameHindi: string;
  color: string;
}

interface EmergencySign {
  title: string;
  titleHindi: string;
  symptoms: string;
  symptomsHindi: string;
  color: string;
}

interface LocalAlert {
  id: number;
  title: string;
  description: string;
  descriptionHindi: string;
  status: 'Active' | 'Moderate' | 'Info';
  updated: string;
  color: string;
}

interface GovtScheme {
  id: number;
  name: string;
  nameHindi: string;
  description: string;
  descriptionHindi: string;
  status: 'Active';
  color: string;
}

export function HealthInformationScreen({ onBack }: HealthInformationScreenProps) {
  const [currentTab, setCurrentTab] = useState<TabType>('healthTopics');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [diseaseOutbreakAlerts, setDiseaseOutbreakAlerts] = useState(true);
  const [healthCampNotifications, setHealthCampNotifications] = useState(true);
  const [weatherHealthAdvisories, setWeatherHealthAdvisories] = useState(false);
  
  // Settings Modal States
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [textSize, setTextSize] = useState<'small' | 'medium' | 'large'>('medium');
  const [autoPlayArticles, setAutoPlayArticles] = useState(false);
  const [healthAlerts, setHealthAlerts] = useState(true);
  const [compactView, setCompactView] = useState(false);
  
  // Article Detail View State
  const [selectedArticle, setSelectedArticle] = useState<HealthArticle | null>(null);

  const healthArticles: HealthArticle[] = [
    {
      id: 1,
      title: 'Nutrition and Healthy Eating',
      titleHindi: 'पोषण और स्वस्थ भोजन',
      category: 'Preventive & Lifestyle',
      categoryColor: 'bg-green-100 text-green-700',
      description: 'Essential nutrition guidelines for maintaining good health',
      descriptionHindi: 'अच्छे स्वास्थ्य को बनाए रखने के लिए आवश्यक पोषण दिशानिर्देश',
      icon: Heart,
      iconBg: 'bg-green-100',
      hasAudio: true
    },
    {
      id: 2,
      title: 'Antenatal Care and Pregnancy',
      titleHindi: 'प्रसवपूर्व देखभाल और गर्भावस्था',
      category: 'Maternal & Child Health',
      categoryColor: 'bg-pink-100 text-pink-700',
      description: 'Complete guide for prenatal care and healthy pregnancy',
      descriptionHindi: 'प्रसवपूर्व देखभाल और स्वस्थ गर्भावस्था के लिए पूर्ण गाइड',
      icon: Baby,
      iconBg: 'bg-pink-100',
      hasAudio: true
    },
    {
      id: 3,
      title: 'Fever Management and Treatment',
      titleHindi: 'बुखार प्रबंधन और उपचार',
      category: 'Common Diseases',
      categoryColor: 'bg-orange-100 text-orange-700',
      description: 'How to manage fever safely at home and when to seek medical help',
      descriptionHindi: 'घर पर बुखार को सुरक्षित रूप से कैसे प्रबंधित करें और कब चिकित्सा सहायता लें',
      icon: Thermometer,
      iconBg: 'bg-orange-100',
      hasAudio: true
    },
    {
      id: 4,
      title: 'Stress Management and Mental Wellness',
      titleHindi: 'तनाव प्रबंधन और मानसिक स्वास्थ्य',
      category: 'Mental Health',
      categoryColor: 'bg-purple-100 text-purple-700',
      description: 'Techniques for managing stress and maintaining mental health',
      descriptionHindi: 'तनाव को प्रबंधित करने और मानसिक स्वास्थ्य बनाए रखने की तकनीकें',
      icon: Brain,
      iconBg: 'bg-purple-100',
      hasAudio: true
    },
    {
      id: 5,
      title: 'Ayushman Bharat Scheme',
      titleHindi: 'आयुष्मान भारत योजना',
      category: 'Govt. Health Schemes',
      categoryColor: 'bg-blue-100 text-blue-700',
      description: 'Complete information about India\'s largest health insurance scheme',
      descriptionHindi: 'भारत की सबसे बड़ी स्वास्थ्य बीमा योजना के बारे में पूरी जानकारी',
      icon: Building2,
      iconBg: 'bg-blue-100',
      hasAudio: true
    },
    {
      id: 6,
      title: 'Heart Attack Warning Signs',
      titleHindi: 'हृदय रोग चेतावनी संकेत',
      category: 'Emergency & Red Flags',
      categoryColor: 'bg-red-100 text-red-700',
      description: 'Recognizing symptoms of heart attack and emergency response',
      descriptionHindi: 'दिल के दौरे के लक्षणों को पहचानना और आपातकालीन प्रतिक्रिया',
      icon: AlertTriangle,
      iconBg: 'bg-red-100',
      hasAudio: true
    },
    {
      id: 7,
      title: 'Personal Hygiene and Sanitation',
      titleHindi: 'व्यक्तिगत स्वच्छता और स्वच्छता',
      category: 'Preventive & Lifestyle',
      categoryColor: 'bg-green-100 text-green-700',
      description: 'Essential hygiene practices for disease prevention',
      descriptionHindi: 'रोग रोकथाम के लिए आवश्यक स्वच्छता प्रथाएं',
      icon: Heart,
      iconBg: 'bg-green-100',
      hasAudio: true
    },
    {
      id: 8,
      title: 'Exercise and Physical Activity',
      titleHindi: 'व्यायाम और शारीरिक गतिविधि',
      category: 'Preventive & Lifestyle',
      categoryColor: 'bg-green-100 text-green-700',
      description: 'Guidelines for maintaining physical fitness and health',
      descriptionHindi: 'शारीरिक फिटनेस और स्वास्थ्य बनाए रखने के लिए दिशानिर्देश',
      icon: Heart,
      iconBg: 'bg-green-100',
      hasAudio: true
    }
  ];

  const emergencyContacts: EmergencyContact[] = [
    {
      number: '108',
      name: 'Ambulance',
      nameHindi: 'एम्बुलेंस सेवा',
      color: 'bg-red-500'
    },
    {
      number: '102',
      name: 'Health Helpline',
      nameHindi: 'स्वास्थ्य हेल्पलाइन',
      color: 'bg-blue-500'
    },
    {
      number: '104',
      name: 'National Health Portal',
      nameHindi: 'राष्ट्रीय स्वास्थ्य पोर्टल',
      color: 'bg-purple-500'
    }
  ];

  const emergencySigns: EmergencySign[] = [
    {
      title: 'Heart Attack Signs',
      titleHindi: 'दिल का दौरा संकेत',
      symptoms: 'Chest pain, shortness of breath, nausea, cold sweat',
      symptomsHindi: 'सीने में दर्द, सांस लेने में तकलीफ, मतली, ठंडा पसीना',
      color: 'border-red-500'
    },
    {
      title: 'Stroke Signs',
      titleHindi: 'स्ट्रोक संकेत',
      symptoms: 'Face drooping, arm weakness, speech difficulty',
      symptomsHindi: 'चेहरे का लटकना, हाथ में कमजोरी, बोलने में कठिनाई',
      color: 'border-orange-500'
    },
    {
      title: 'Severe Allergic Reaction',
      titleHindi: 'गंभीर एलर्जी प्रतिक्रिया',
      symptoms: 'Difficulty breathing, swelling, rapid pulse',
      symptomsHindi: 'सांस लेने में कठिनाई, सूजन, तेज नाड़ी',
      color: 'border-yellow-500'
    }
  ];

  const localAlerts: LocalAlert[] = [
    {
      id: 1,
      title: 'Dengue Alert',
      description: 'Increased dengue cases reported in the area. Use mosquito repellent and eliminate stagnant water.',
      descriptionHindi: 'क्षेत्र में डेंगू के बढ़ते मामले। मच्छर प्रतिरोधी का उपयोग करें और जमा पानी को खत्म करें।',
      status: 'Active',
      updated: '2 days ago',
      color: 'bg-orange-50 border-l-4 border-orange-500'
    },
    {
      id: 2,
      title: 'Air Quality Advisory',
      description: 'Air quality is moderate. Sensitive individuals should limit outdoor activities.',
      descriptionHindi: 'हवा की गुणवत्ता मध्यम है। संवेदनशील व्यक्तियों को बाहरी गतिविधियां सीमित करनी चाहिए।',
      status: 'Moderate',
      updated: '1 day ago',
      color: 'bg-blue-50 border-l-4 border-blue-500'
    },
    {
      id: 3,
      title: 'Vaccination Drive',
      description: 'Free vaccination camp at Community Health Center on Feb 15-17.',
      descriptionHindi: '15-17 फरवरी को सामुदायिक स्वास्थ्य केंद्र में मुफ्त टीकाकरण शिविर।',
      status: 'Info',
      updated: '5 hours ago',
      color: 'bg-green-50 border-l-4 border-green-500'
    }
  ];

  const govtSchemes: GovtScheme[] = [
    {
      id: 1,
      name: 'Ayushman Bharat',
      nameHindi: 'आयुष्मान भारत योजना',
      description: 'Free health coverage up to ₹5 lakhs per family per year for hospitalization',
      descriptionHindi: 'प्रति परिवार प्रति वर्ष ₹5 लाख तक का मुफ्त स्वास्थ्य कवरेज',
      status: 'Active',
      color: 'bg-blue-50 border-2 border-blue-200'
    },
    {
      id: 2,
      name: 'Janani Suraksha Yojana',
      nameHindi: 'जननी सुरक्षा योजना',
      description: 'Cash assistance to pregnant women for institutional delivery',
      descriptionHindi: 'संस्थागत प्रसव के लिए गर्भवती महिलाओं को नकद सहायता',
      status: 'Active',
      color: 'bg-pink-50 border-2 border-pink-200'
    },
    {
      id: 3,
      name: 'Pradhan Mantri Jan Aushadhi',
      nameHindi: 'प्रधान मंत्री जन औषधि योजना',
      description: 'Quality generic medicines at affordable prices',
      descriptionHindi: 'किफायती कीमतों पर गुणवत्ता वाली जेनेरिक दवाएं',
      status: 'Active',
      color: 'bg-green-50 border-2 border-green-200'
    },
    {
      id: 4,
      name: 'National Health Mission',
      nameHindi: 'राष्ट्रीय स्वास्थ्य मिशन',
      description: 'Universal access to equitable, affordable healthcare services',
      descriptionHindi: 'समान, किफायती स्वास्थ्य सेवाओं तक सार्वभौमिक पहुंच',
      status: 'Active',
      color: 'bg-orange-50 border-2 border-orange-200'
    }
  ];

  const categories = [
    { id: 'all', label: 'All', icon: null, color: 'bg-gray-900 text-white' },
    { id: 'preventive', label: 'Preventive & Lifestyle', icon: Heart, color: 'bg-green-100 text-green-700' },
    { id: 'maternal', label: 'Maternal & Child Health', icon: Baby, color: 'bg-pink-100 text-pink-700' },
    { id: 'common', label: 'Common Diseases', icon: Thermometer, color: 'bg-orange-100 text-orange-700' },
    { id: 'mental', label: 'Mental Health', icon: Brain, color: 'bg-purple-100 text-purple-700' },
    { id: 'govt', label: 'Govt. Health Schemes', icon: Building2, color: 'bg-blue-100 text-blue-700' },
    { id: 'emergency', label: 'Emergency & Red Flags', icon: AlertTriangle, color: 'bg-red-100 text-red-700' },
    { id: 'local', label: 'Local Health Alerts', icon: Bell, color: 'bg-blue-100 text-blue-700' }
  ];

  const filteredArticles = healthArticles.filter(article => {
    if (selectedCategory === 'all') return true;
    const categoryMap: { [key: string]: string } = {
      preventive: 'Preventive & Lifestyle',
      maternal: 'Maternal & Child Health',
      common: 'Common Diseases',
      mental: 'Mental Health',
      govt: 'Govt. Health Schemes',
      emergency: 'Emergency & Red Flags',
      local: 'Local Health Alerts'
    };
    return article.category === categoryMap[selectedCategory];
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white px-4 py-4 border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-2 text-gray-700">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <button 
            onClick={() => setShowSettingsModal(true)}
            className="p-2 bg-gray-100 rounded-full hover:bg-gray-200 transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <div className="flex items-center gap-3 mb-2">
          <Heart className="w-7 h-7 text-red-500" />
          <h1 className="text-2xl font-bold">Health Information Module</h1>
        </div>
        <p className="text-sm text-gray-600 mb-4">Comprehensive health education and awareness</p>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          <button
            onClick={() => setCurrentTab('healthTopics')}
            className={`px-4 py-2 rounded-xl whitespace-nowrap font-medium transition-colors ${
              currentTab === 'healthTopics'
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Health Topics
          </button>
          <button
            onClick={() => setCurrentTab('emergencyInfo')}
            className={`px-4 py-2 rounded-xl whitespace-nowrap font-medium transition-colors ${
              currentTab === 'emergencyInfo'
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Emergency Info
          </button>
          <button
            onClick={() => setCurrentTab('localAlerts')}
            className={`px-4 py-2 rounded-xl whitespace-nowrap font-medium transition-colors ${
              currentTab === 'localAlerts'
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Local Alerts
          </button>
          <button
            onClick={() => setCurrentTab('govtSchemes')}
            className={`px-4 py-2 rounded-xl whitespace-nowrap font-medium transition-colors ${
              currentTab === 'govtSchemes'
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Govt Schemes
          </button>
        </div>
      </header>

      {/* Content */}
      <div className="px-4 py-6 pb-24">
        {/* Health Topics Tab */}
        {currentTab === 'healthTopics' && (
          <>
            {/* Search Section */}
            <div className="bg-white rounded-2xl p-5 mb-6 shadow-sm">
              <h2 className="text-xl font-bold mb-2">Search Health Topics</h2>
              <p className="text-sm text-gray-600 mb-4">
                Find information on various health conditions and wellness topics
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Search health topics..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
                <button className="bg-gray-900 text-white px-6 py-3 rounded-xl font-medium hover:bg-gray-800 transition-colors">
                  Search
                </button>
              </div>
            </div>

            {/* Categories */}
            <div className="bg-white rounded-2xl p-5 mb-6 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Categories</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {categories.slice(1).map((category) => {
                  const Icon = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id as CategoryType)}
                      className={`flex items-center gap-3 p-4 rounded-2xl font-medium transition-all hover:shadow-md ${category.color}`}
                    >
                      {Icon && <Icon className="w-6 h-6" />}
                      <span>{category.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Articles List */}
            <div className="space-y-4">
              {filteredArticles.map((article) => {
                const Icon = article.icon;
                return (
                  <div key={article.id} className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`${article.iconBg} rounded-2xl p-4`}>
                        <Icon className="w-8 h-8 text-gray-700" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-bold mb-1">{article.title}</h3>
                        <span className={`inline-block text-xs px-3 py-1 rounded-full ${article.categoryColor} mb-2`}>
                          {article.category}
                        </span>
                        <p className="text-sm text-gray-600 mb-1">{article.description}</p>
                        <p className="text-sm text-gray-500">{article.descriptionHindi}</p>
                      </div>
                      {article.hasAudio && (
                        <button className="bg-cyan-500 rounded-full p-3 hover:bg-cyan-600 transition-colors">
                          <Volume2 className="w-5 h-5 text-white" />
                        </button>
                      )}
                    </div>
                    <button 
                      onClick={() => setSelectedArticle(article)}
                      className="w-full bg-gray-900 text-white py-3 rounded-xl font-medium hover:bg-gray-800 transition-colors"
                    >
                      Read More
                    </button>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* Emergency Info Tab */}
        {currentTab === 'emergencyInfo' && (
          <>
            {/* Emergency Numbers */}
            <div className="bg-white rounded-2xl p-5 mb-6 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Emergency Numbers</h2>
              <div className="space-y-3">
                {emergencyContacts.map((contact) => (
                  <div key={contact.number} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div>
                      <p className="font-bold text-lg">{contact.number} - {contact.name}</p>
                      <p className="text-sm text-gray-600">{contact.nameHindi}</p>
                    </div>
                    <button className={`${contact.color} text-white px-6 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity`}>
                      Call
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Common Emergencies */}
            <div className="bg-white rounded-2xl p-5 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Common Emergencies</h2>
              <div className="space-y-4">
                {emergencySigns.map((sign, index) => (
                  <div key={index} className={`border-l-4 ${sign.color} bg-gray-50 rounded-r-xl p-4`}>
                    <h3 className="font-bold mb-1">{sign.title}</h3>
                    <p className="text-sm text-gray-700 mb-1">{sign.symptoms}</p>
                    <p className="text-sm text-gray-600">{sign.symptomsHindi}</p>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Local Alerts Tab */}
        {currentTab === 'localAlerts' && (
          <>
            {/* Active Alerts */}
            <div className="bg-white rounded-2xl p-5 mb-6 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Active Alerts</h2>
              <div className="space-y-4">
                {localAlerts.map((alert) => (
                  <div key={alert.id} className={`${alert.color} rounded-xl p-4`}>
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-bold text-lg">{alert.title}</h3>
                      <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                        alert.status === 'Active' ? 'bg-red-500 text-white' :
                        alert.status === 'Moderate' ? 'bg-blue-500 text-white' :
                        'bg-green-500 text-white'
                      }`}>
                        {alert.status}
                      </span>
                    </div>
                    <p className="text-sm mb-1">{alert.description}</p>
                    <p className="text-sm text-gray-600 mb-2">{alert.descriptionHindi}</p>
                    <p className="text-xs text-gray-500">Updated: {alert.updated}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Notification Preferences */}
            <div className="bg-white rounded-2xl p-5 shadow-sm">
              <h2 className="text-xl font-bold mb-4">Notification Preferences</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3">
                  <span className="font-medium">Disease Outbreak Alerts</span>
                  <button
                    onClick={() => setDiseaseOutbreakAlerts(!diseaseOutbreakAlerts)}
                    className={`w-12 h-6 rounded-full relative transition-colors ${
                      diseaseOutbreakAlerts ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    {diseaseOutbreakAlerts && (
                      <Check className="w-4 h-4 text-white absolute right-1 top-1" />
                    )}
                  </button>
                </div>
                <div className="flex items-center justify-between py-3">
                  <span className="font-medium">Health Camp Notifications</span>
                  <button
                    onClick={() => setHealthCampNotifications(!healthCampNotifications)}
                    className={`w-12 h-6 rounded-full relative transition-colors ${
                      healthCampNotifications ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    {healthCampNotifications && (
                      <Check className="w-4 h-4 text-white absolute right-1 top-1" />
                    )}
                  </button>
                </div>
                <div className="flex items-center justify-between py-3">
                  <span className="font-medium">Weather Health Advisories</span>
                  <button
                    onClick={() => setWeatherHealthAdvisories(!weatherHealthAdvisories)}
                    className={`w-12 h-6 rounded-full relative transition-colors ${
                      weatherHealthAdvisories ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    {weatherHealthAdvisories && (
                      <Check className="w-4 h-4 text-white absolute right-1 top-1" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Govt Schemes Tab */}
        {currentTab === 'govtSchemes' && (
          <>
            {/* Header Info */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5 mb-6">
              <div className="flex items-start gap-4 mb-3">
                <div className="bg-blue-600 rounded-xl p-3">
                  <Building2 className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-blue-900 mb-1">Government Health Schemes</h2>
                  <p className="text-sm text-blue-700">सरकारी स्वास्थ्य योजनाएं</p>
                </div>
              </div>
              <p className="text-sm text-blue-800">
                Learn about government health schemes and benefits available to you. Click on any scheme to view details and eligibility.
              </p>
            </div>

            {/* Available Schemes */}
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-4">Available Schemes</h2>
              <div className="space-y-4">
                {govtSchemes.map((scheme) => (
                  <div key={scheme.id} className={`${scheme.color} rounded-2xl p-5`}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-bold mb-1">{scheme.name}</h3>
                        <p className="text-sm text-gray-600">{scheme.nameHindi}</p>
                      </div>
                      <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                        scheme.color.includes('blue') ? 'bg-blue-500 text-white' :
                        scheme.color.includes('pink') ? 'bg-pink-500 text-white' :
                        scheme.color.includes('green') ? 'bg-green-500 text-white' :
                        'bg-orange-500 text-white'
                      }`}>
                        {scheme.status}
                      </span>
                    </div>
                    <p className="text-sm mb-1">{scheme.description}</p>
                    <p className="text-sm text-gray-600 mb-4">{scheme.descriptionHindi}</p>
                    <button className={`w-full text-white py-3 rounded-xl font-medium hover:opacity-90 transition-opacity ${
                      scheme.color.includes('blue') ? 'bg-blue-600' :
                      scheme.color.includes('pink') ? 'bg-pink-600' :
                      scheme.color.includes('green') ? 'bg-green-600' :
                      'bg-orange-600'
                    }`}>
                      View Details
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* How to Apply */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <Building2 className="w-6 h-6 text-blue-600" />
                <h2 className="text-lg font-bold text-blue-900">How to Apply</h2>
              </div>
              <p className="text-sm text-blue-800 mb-2">
                Visit your nearest government hospital or health center with required documents. You can also apply online through respective scheme portals.
              </p>
              <p className="text-sm text-blue-700">
                आवश्यक दस्तावेजों के साथ अपने निकटतम सरकारी अस्पताल या स्वास्थ्य केंद्र पर जाएं। आप संबंधित योजना पोर्टल के माध्यम से ऑनलाइन भी आवेदन कर सकते हैं।
              </p>
            </div>
          </>
        )}
      </div>

      {/* Settings Modal */}
      {showSettingsModal && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/60 z-50"
            onClick={() => setShowSettingsModal(false)}
          />
          
          {/* Modal */}
          <div className="fixed inset-4 z-50 flex items-center justify-center">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="sticky top-0 bg-gradient-to-r from-gray-800 to-gray-900 text-white px-6 py-5 rounded-t-3xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-white/20 rounded-full p-2">
                      <Settings className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold">Health Module Settings</h2>
                      <p className="text-sm text-gray-300">स्वास्थ्य मॉड्यूल सेटिंग्स</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowSettingsModal(false)}
                    className="p-1 hover:bg-white/20 rounded-lg transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Reading Text Size */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <BookOpen className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">Reading Text Size / पढ़ने का टेक्स्ट आकार</h3>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      onClick={() => setTextSize('small')}
                      className={`py-4 px-4 rounded-2xl font-medium transition-all ${
                        textSize === 'small'
                          ? 'bg-gray-900 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-sm mb-1">A</div>
                        <div className="text-xs">Small</div>
                      </div>
                    </button>
                    <button
                      onClick={() => setTextSize('medium')}
                      className={`py-4 px-4 rounded-2xl font-medium transition-all ${
                        textSize === 'medium'
                          ? 'bg-gray-900 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-base mb-1">A</div>
                        <div className="text-xs">Medium</div>
                      </div>
                    </button>
                    <button
                      onClick={() => setTextSize('large')}
                      className={`py-4 px-4 rounded-2xl font-medium transition-all ${
                        textSize === 'large'
                          ? 'bg-gray-900 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-lg mb-1">A</div>
                        <div className="text-xs">Large</div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Audio / Playback */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Volume2 className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">Audio / Playback</h3>
                  </div>
                  <div className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">स्वचालित ऑडियो चलाएँ</p>
                        <p className="text-sm text-gray-600">Auto-play articles</p>
                      </div>
                      <button
                        onClick={() => setAutoPlayArticles(!autoPlayArticles)}
                        className={`w-14 h-7 rounded-full relative transition-colors ${
                          autoPlayArticles ? 'bg-gray-900' : 'bg-gray-300'
                        }`}
                      >
                        <div
                          className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                            autoPlayArticles ? 'right-1' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Health Alerts */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Bell className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">Health Alerts</h3>
                  </div>
                  <div className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">स्वास्थ्य अलर्ट सूचनाएं</p>
                        <p className="text-sm text-gray-600">Get local health alerts & warnings</p>
                      </div>
                      <button
                        onClick={() => setHealthAlerts(!healthAlerts)}
                        className={`w-14 h-7 rounded-full relative transition-colors ${
                          healthAlerts ? 'bg-gray-900' : 'bg-gray-300'
                        }`}
                      >
                        <div
                          className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                            healthAlerts ? 'right-1' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Display Preference */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Eye className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">Display Preference</h3>
                  </div>
                  <div className="bg-gray-50 rounded-2xl p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">सूची कॉम्पैक्ट दृश्य</p>
                        <p className="text-sm text-gray-600">Compact view for articles list</p>
                      </div>
                      <button
                        onClick={() => setCompactView(!compactView)}
                        className={`w-14 h-7 rounded-full relative transition-colors ${
                          compactView ? 'bg-gray-900' : 'bg-gray-300'
                        }`}
                      >
                        <div
                          className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                            compactView ? 'right-1' : 'left-1'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* About This Module */}
                <div className="bg-gray-50 border-2 border-gray-200 rounded-2xl p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <BookOpen className="w-5 h-5 text-gray-700" />
                    <h3 className="font-bold text-gray-900">About This Module</h3>
                  </div>
                  <p className="text-sm text-gray-700 mb-3">
                    The Health Information Module provides comprehensive, bilingual health education on various topics including diseases, prevention, maternal care, mental health, and government schemes.
                  </p>
                  <p className="text-sm text-gray-600">
                    स्वास्थ्य सूचना मॉड्यूल विभिन्न विषयों, रोकथाम, मातृ देखभाल, मानसिक स्वास्थ्य और सरकारी योजनाओं सहित विभिन्न विषयों पर व्यापक, द्विभाषी स्वास्थ्य शिक्षा प्रदान करता है।
                  </p>
                </div>

                {/* Done Button */}
                <button
                  onClick={() => setShowSettingsModal(false)}
                  className="w-full bg-gray-900 text-white py-4 rounded-2xl font-bold mt-6 hover:bg-gray-800 transition-colors"
                >
                  Done / पूर्ण
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}