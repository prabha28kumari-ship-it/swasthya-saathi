import { useState } from 'react';
import { ArrowLeft, MapPin, Navigation, Settings, Info, ChevronDown, ChevronRight, Search, Building2, Building, Pill, Heart, Hospital, Phone, Share2, Clock, Users, Calendar, X, Bookmark, History, ExternalLink, Map, Layers, Ruler, Eye, Route, Tent, Star, DollarSign, Ambulance, Users2, Lock, Target, FileText } from 'lucide-react';

interface MedicalMapsScreenProps {
  onBack: () => void;
}

type ViewType = 'main' | 'healthCamps' | 'quickNav' | 'mapSettings';
type CampTab = 'upcoming' | 'ongoing' | 'myReg' | 'map';
type MapStyle = 'standard' | 'satellite' | 'terrain';
type DistanceUnit = 'km' | 'mi';
type RoutePreference = 'fastest' | 'shortest';

export function MedicalMapsScreen({ onBack }: MedicalMapsScreenProps) {
  const [currentView, setCurrentView] = useState<ViewType>('main');
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [expandedDisclaimer, setExpandedDisclaimer] = useState<number | null>(null);
  const [campTab, setCampTab] = useState<CampTab>('upcoming');
  const [searchQuery, setSearchQuery] = useState('');
  const [mapStyle, setMapStyle] = useState<MapStyle>('standard');
  const [distanceUnit, setDistanceUnit] = useState<DistanceUnit>('km');
  const [routePreference, setRoutePreference] = useState<RoutePreference>('fastest');
  const [autoDetectLocation, setAutoDetectLocation] = useState(true);
  const [showEmergencyFacilities, setShowEmergencyFacilities] = useState(true);
  const [highlight24x7, setHighlight24x7] = useState(true);
  const [showGovtSchemeHospitals, setShowGovtSchemeHospitals] = useState(true);

  const filterButtons = [
    { id: 'all', label: 'All', icon: null },
    { id: 'hospital', label: 'अस्पताल', icon: Building2 },
    { id: 'clinic', label: 'क्लिनिक', icon: Building },
    { id: 'pharmacy', label: 'फार्मेसी', icon: Pill },
    { id: 'ngo', label: 'एनजीओ', icon: Heart },
    { id: 'govt', label: 'सरकारी योजना अस्पताल', icon: Hospital }
  ];

  const disclaimers = [
    {
      id: 1,
      icon: FileText,
      title: 'Hospital Listing Disclaimer',
      content: 'Hospitals listed are for informational purposes only. Swasthya Saathi does not endorse or guarantee the quality of services. Always verify credentials before seeking treatment.\n\nसूचीबद्ध अस्पताल केवल सूचना के उद्देश्यों के लिए हैं। स्वास्थ्य साथी सेवा की गुणवत्ता का समर्थन या गारंटी नहीं देता।'
    },
    {
      id: 2,
      icon: FileText,
      title: 'Government Scheme Disclaimer',
      content: 'Government scheme eligibility and participation is subject to hospital discretion and government regulations. Verify scheme acceptance before visiting.\n\nसरकारी योजना पात्रता अस्पताल के विवेक और सरकारी नियमों के अधीन है। यात्रा से पहले योजना स्वीकृति सत्यापित करें।'
    },
    {
      id: 3,
      icon: DollarSign,
      title: 'Cost Awareness Note',
      content: 'Treatment costs vary significantly between facilities. Always inquire about pricing before starting treatment. Government scheme hospitals may offer reduced costs.\n\nउपचार की लागत सुविधाओं के बीच काफी भिन्न होती है। उपचार शुरू करने से पहले हमेशा मूल्य निर्धारण के बारे में पूछें।'
    },
    {
      id: 4,
      icon: Star,
      title: 'High-Quality / Low-Cost Hospital Tag',
      content: 'Hospitals tagged as "High-Quality/Low-Cost" are based on community ratings and reported pricing. This is indicative only - always verify directly.\n\n"उच्च गुणवत्ता/कम लागत" टैग किए गए अस्पताल समुदाय रेटिंग और रिपोर्ट की गई कीमतों पर आधारित हैं।'
    },
    {
      id: 5,
      icon: Tent,
      title: 'Mobile Medical Care / Camp Location',
      content: 'Health camps provide free or low-cost services. Availability is time-limited. Register early as slots fill quickly. Bring your Aadhaar card.\n\nस्वास्थ्य शिविर मुफ्त या कम लागत वाली सेवाएं प्रदान करते हैं। जल्दी पंजीकरण करें क्योंकि स्लॉट तेजी से भरते हैं।'
    },
    {
      id: 6,
      icon: Users2,
      title: 'Caregiver Map View',
      content: 'Share your location with family members for safety. Your location is only shared with approved caregivers. You can disable sharing anytime.\n\nसुरक्षा के लिए अपना स्थान परिवार के सदस्यों के साथ साझा करें। आप कभी भी साझाकरण अक्षम कर सकते हैं।'
    },
    {
      id: 7,
      icon: Lock,
      title: 'Privacy & Data Note',
      content: 'Location data is used only for navigation and is not stored permanently. Your search history is stored locally on your device only.\n\nस्थान डेटा का उपयोग केवल नेविगेशन के लिए किया जाता है और स्थायी रूप से संग्रहीत नहीं किया जाता।'
    },
    {
      id: 8,
      icon: Target,
      title: 'Location Accuracy Note',
      content: 'Location accuracy depends on GPS signal strength. In urban areas with tall buildings, accuracy may be reduced. Keep location services enabled.\n\nस्थान की सटीकता GPS सिग्नल की शक्ति पर निर्भर करती है। ऊंची इमारतों वाले शहरी क्षेत्रों में सटीकता कम हो सकती है।'
    }
  ];

  const medicalFacilities = [
    {
      id: 1,
      name: 'City General Hospital',
      nameHindi: 'सिटी जनरल अस्पताल',
      type: 'hospital',
      address: '123 Main Street, Downtown',
      distance: 0.8,
      rating: 4.5,
      isOpen24x7: true,
      isOpen: true,
      govtScheme: false,
      highQualityLowCost: false
    },
    {
      id: 2,
      name: 'Government District Hospital',
      nameHindi: 'सरकारी जिला अस्पताल',
      type: 'govt',
      address: 'Sector 5, Government Complex',
      distance: 3.1,
      rating: 4.2,
      isOpen24x7: true,
      isOpen: true,
      govtScheme: true,
      highQualityLowCost: true
    },
    {
      id: 3,
      name: 'MedPlus Pharmacy',
      nameHindi: 'मेडप्लस फार्मेसी',
      type: 'pharmacy',
      address: '45 Market Road',
      distance: 0.5,
      rating: 4.7,
      isOpen24x7: true,
      isOpen: true,
      govtScheme: false,
      highQualityLowCost: false
    },
    {
      id: 4,
      name: 'Fortis Hospital',
      nameHindi: 'फोर्टिस अस्पताल',
      type: 'hospital',
      address: '789 Health Avenue',
      distance: 2.3,
      rating: 4.8,
      isOpen24x7: true,
      isOpen: true,
      govtScheme: true,
      highQualityLowCost: false
    },
    {
      id: 5,
      name: 'Apollo Clinic',
      nameHindi: 'अपोलो क्लिनिक',
      type: 'clinic',
      address: 'Nehru Nagar, Block B',
      distance: 1.2,
      rating: 4.4,
      isOpen24x7: false,
      isOpen: true,
      govtScheme: false,
      highQualityLowCost: false
    }
  ];

  const upcomingCamps = [
    {
      id: 1,
      name: 'Free Diabetes & BP Screening Camp',
      nameHindi: 'मुफ्त मधुमेह और बीपी जांच शिविर',
      organizer: 'Red Cross Society',
      date: 'Feb 15, 2026',
      time: '9:00 AM - 5:00 PM',
      location: 'Community Hall, Sector 12',
      distance: 1.2,
      registered: 156,
      capacity: 300,
      services: ['BP Check', 'Sugar Test', 'Free Medicines', 'Diet Consultation'],
      contact: '1800-123-4567',
      isFree: true
    },
    {
      id: 2,
      name: 'Women & Child Health Camp',
      nameHindi: 'महिला और बाल स्वास्थ्य शिविर',
      organizer: 'Government Health Department',
      date: 'Feb 20, 2026',
      time: '8:00 AM - 2:00 PM',
      location: 'Primary Health Center, Block A',
      distance: 0.8,
      registered: 89,
      capacity: 200,
      services: ['Prenatal Check', 'Vaccination', 'Health Screening', 'Nutrition Counseling'],
      contact: '1800-567-8901',
      isFree: true
    },
    {
      id: 3,
      name: 'Dental Care & Awareness Camp',
      nameHindi: 'दंत चिकित्सा और जागरूकता शिविर',
      organizer: 'Smile Foundation',
      date: 'Mar 1, 2026',
      time: '10:00 AM - 5:00 PM',
      location: 'Government School Compound',
      distance: 2.1,
      registered: 67,
      capacity: 150,
      services: ['Dental Check', 'Cleaning', 'Fluoride Treatment', 'Oral Hygiene Education'],
      contact: '1800-678-9012',
      isFree: true
    }
  ];

  // Main View
  if (currentView === 'main') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white sticky top-0 z-10">
          <div className="flex items-center justify-between mb-4">
            <button onClick={onBack} className="flex items-center gap-2">
              <ArrowLeft className="w-5 h-5" />
              <span>वापस</span>
            </button>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setCurrentView('healthCamps')}
                className="bg-green-500 rounded-full p-2 hover:bg-green-600 transition-colors"
              >
                <Tent className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setCurrentView('quickNav')}
                className="bg-blue-600 rounded-full p-2 hover:bg-blue-700 transition-colors"
              >
                <Navigation className="w-5 h-5" />
              </button>
              <button 
                onClick={() => setCurrentView('mapSettings')}
                className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              >
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
          <h1 className="text-2xl mb-1">मेडिकल मैप्स</h1>
          <p className="text-sm text-cyan-100">नजदीकी अस्पताल, क्लिनिक और फार्मेसी खोजें</p>
        </header>

        {/* Content */}
        <div className="px-4 py-6 pb-24">
          {/* Current Location */}
          <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2">
                <MapPin className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-600 mb-1">आपका स्थान / Your Location</p>
                <button className="flex items-center gap-2 text-blue-600 font-medium">
                  <Navigation className="w-4 h-4" />
                  <span>My Location</span>
                </button>
              </div>
            </div>
          </div>

          {/* Safety Notes */}
          <div className="bg-yellow-50 border-2 border-yellow-300 rounded-2xl p-4 mb-4">
            <div className="flex items-start gap-3 mb-2">
              <Info className="w-5 h-5 text-yellow-700 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-yellow-900 mb-1">Map - General Safety Note</p>
                <p className="text-sm text-yellow-800">
                  Map information is for navigation support only. Distances, availability, and services may change. Please confirm directly with the facility.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4 mb-4">
            <div className="flex items-start gap-3 mb-2">
              <Ambulance className="w-6 h-6 text-red-700 flex-shrink-0" />
              <div>
                <p className="font-bold text-red-900 mb-1 flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  EMERGENCY SAFETY NOTE
                </p>
                <p className="text-sm text-red-800 mb-2">
                  In case of a life-threatening emergency, do not rely on navigation.
                </p>
                <p className="font-bold text-red-900 text-lg">Call 108 immediately.</p>
              </div>
            </div>
          </div>

          {/* Important Information & Disclaimers */}
          <div className="bg-white rounded-2xl p-5 mb-6 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <Info className="w-6 h-6 text-blue-600" />
              <h2 className="font-semibold text-lg">Important Safety Information & Disclaimers</h2>
            </div>

            <div className="space-y-2">
              {disclaimers.map((disclaimer) => (
                <div key={disclaimer.id}>
                  <button
                    onClick={() => setExpandedDisclaimer(expandedDisclaimer === disclaimer.id ? null : disclaimer.id)}
                    className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <disclaimer.icon className="w-5 h-5 text-gray-600" />
                      <span className="font-medium text-sm text-left">{disclaimer.title}</span>
                    </div>
                    <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${expandedDisclaimer === disclaimer.id ? 'rotate-180' : ''}`} />
                  </button>
                  {expandedDisclaimer === disclaimer.id && (
                    <div className="mt-2 p-4 bg-blue-50 rounded-xl">
                      <p className="text-sm text-gray-700 whitespace-pre-line">{disclaimer.content}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Search Section */}
          <div className="bg-white rounded-2xl p-4 mb-4 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Search className="w-6 h-6 text-gray-600" />
              <h2 className="font-semibold text-lg">Search Medical Facilities</h2>
            </div>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search hospitals, clinics, or pharmacies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            {/* Filter Buttons */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {filterButtons.map((filter) => {
                const Icon = filter.icon;
                return (
                  <button
                    key={filter.id}
                    onClick={() => setSelectedFilter(filter.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
                      selectedFilter === filter.id
                        ? 'bg-gray-900 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {Icon && <Icon className="w-4 h-4" />}
                    <span className="text-sm">{filter.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Map View */}
          <div className="bg-white rounded-2xl p-4 mb-6 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Map className="w-6 h-6 text-gray-900" />
              <h2 className="font-semibold text-lg">Map View</h2>
            </div>
            <p className="text-sm text-gray-600 mb-4">Interactive map showing 12 medical facilities</p>

            {/* Map Placeholder with Legend */}
            <div className="relative bg-gray-200 rounded-xl h-80 mb-4 overflow-hidden">
              {/* Map Style Toggle */}
              <div className="absolute top-4 right-4 flex gap-2 z-10">
                <button className="bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium">
                  Standard
                </button>
                <button className="bg-white px-4 py-2 rounded-lg text-sm font-medium">
                  Satellite
                </button>
              </div>

              {/* Simulated Map with Icons */}
              <div className="w-full h-full relative">
                {/* Hospital markers */}
                <div className="absolute top-1/4 left-1/4 bg-red-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Building2 className="w-5 h-5 text-white" />
                </div>
                <div className="absolute top-1/3 right-1/3 bg-orange-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Hospital className="w-5 h-5 text-white" />
                </div>
                <div className="absolute top-2/3 right-1/4 bg-orange-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Hospital className="w-5 h-5 text-white" />
                </div>

                {/* Pharmacy markers */}
                <div className="absolute top-1/2 right-1/4 bg-green-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Pill className="w-5 h-5 text-white" />
                </div>
                <div className="absolute bottom-1/4 right-1/3 bg-green-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Pill className="w-5 h-5 text-white" />
                </div>

                {/* Clinic markers */}
                <div className="absolute top-1/3 right-1/4 bg-blue-400 rounded-full p-3 border-2 border-white shadow-lg">
                  <Building className="w-5 h-5 text-white" />
                </div>
                <div className="absolute bottom-1/3 left-1/3 bg-blue-400 rounded-full p-3 border-2 border-white shadow-lg">
                  <Building className="w-5 h-5 text-white" />
                </div>

                {/* NGO markers */}
                <div className="absolute top-1/4 left-1/3 bg-purple-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <div className="absolute bottom-1/3 right-1/4 bg-purple-500 rounded-full p-3 border-2 border-white shadow-lg">
                  <Heart className="w-5 h-5 text-white" />
                </div>

                {/* Your location marker */}
                <div className="absolute bottom-1/3 left-1/2 bg-blue-600 rounded-full p-3 border-2 border-white shadow-lg animate-pulse">
                  <Navigation className="w-5 h-5 text-white" />
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white rounded-xl p-4 shadow-lg">
                  <p className="font-semibold mb-3">Legend</p>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span>Hospitals</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span>Pharmacies</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                      <span>Govt Hospitals</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-400 rounded-full"></div>
                      <span>Clinics</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                      <span>NGOs</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                      <span>Your Location</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-600 rounded-full border-2 border-green-800"></div>
                      <span className="text-xs">✓ Govt Schemes</span>
                    </div>
                  </div>
                </div>

                {/* Zoom controls */}
                <div className="absolute bottom-4 right-4 flex flex-col gap-2">
                  <button className="bg-white rounded-lg p-2 shadow-lg hover:bg-gray-100">
                    <span className="text-xl font-bold">+</span>
                  </button>
                  <button className="bg-white rounded-lg p-2 shadow-lg hover:bg-gray-100">
                    <span className="text-xl font-bold">−</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Medical Facilities List */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h2 className="font-semibold text-lg mb-4">Medical Facilities (12)</h2>
            <div className="space-y-3">
              {medicalFacilities.map((facility) => (
                <div key={facility.id} className="border border-gray-200 rounded-2xl p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-3 mb-3">
                    <div className={`rounded-xl p-3 ${
                      facility.type === 'hospital' ? 'bg-red-100' :
                      facility.type === 'govt' ? 'bg-orange-100' :
                      facility.type === 'pharmacy' ? 'bg-green-100' :
                      'bg-blue-100'
                    }`}>
                      {facility.type === 'hospital' && <Building2 className="w-6 h-6 text-red-600" />}
                      {facility.type === 'govt' && <Hospital className="w-6 h-6 text-orange-600" />}
                      {facility.type === 'pharmacy' && <Pill className="w-6 h-6 text-green-600" />}
                      {facility.type === 'clinic' && <Building className="w-6 h-6 text-blue-600" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-1">
                        <div>
                          <h3 className="font-semibold">{facility.name}</h3>
                          <p className="text-sm text-gray-600">{facility.nameHindi}</p>
                        </div>
                        {facility.isOpen && (
                          <span className="bg-green-100 text-green-700 text-xs px-3 py-1 rounded-full font-medium">
                            Open
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{facility.address}</p>
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4 text-gray-500" />
                          <span>{facility.distance} km</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                          <span>{facility.rating}</span>
                        </div>
                        {facility.isOpen24x7 && (
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4 text-blue-600" />
                            <span className="text-blue-600">24/7</span>
                          </div>
                        )}
                      </div>
                      {facility.govtScheme && (
                        <div className="mt-2 bg-green-50 border border-green-200 rounded-lg px-2 py-1 inline-flex items-center gap-1">
                          <Hospital className="w-3 h-3 text-green-600" />
                          <span className="text-xs text-green-700">Govt Scheme Accepted</span>
                        </div>
                      )}
                      {facility.highQualityLowCost && (
                        <div className="mt-2 bg-purple-50 border border-purple-200 rounded-lg px-2 py-1 inline-flex items-center gap-1">
                          <Star className="w-3 h-3 text-purple-600" />
                          <span className="text-xs text-purple-700">High Quality / Low Cost</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="flex-1 bg-cyan-600 text-white py-2 rounded-xl font-medium hover:bg-cyan-700 transition-colors flex items-center justify-center gap-2">
                      <Navigation className="w-4 h-4" />
                      <span>Navigate</span>
                    </button>
                    <button className="bg-gray-100 p-2 rounded-xl hover:bg-gray-200 transition-colors">
                      <Phone className="w-5 h-5 text-gray-700" />
                    </button>
                    <button className="bg-gray-100 p-2 rounded-xl hover:bg-gray-200 transition-colors">
                      <Share2 className="w-5 h-5 text-gray-700" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Health Camps View
  if (currentView === 'healthCamps') {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center sm:justify-center">
        <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <Tent className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Health Camps</h2>
                  <p className="text-sm text-green-100">स्वास्थ्य शिविर</p>
                </div>
              </div>
              <button
                onClick={() => setCurrentView('main')}
                className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex gap-2">
              <button
                onClick={() => setCampTab('upcoming')}
                className={`flex-1 py-2 px-4 rounded-xl font-medium transition-colors ${
                  campTab === 'upcoming'
                    ? 'bg-white text-green-700'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <Calendar className="w-4 h-4 inline mr-1" />
                Upcoming
              </button>
              <button
                onClick={() => setCampTab('ongoing')}
                className={`flex-1 py-2 px-4 rounded-xl font-medium transition-colors ${
                  campTab === 'ongoing'
                    ? 'bg-white text-green-700'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <Clock className="w-4 h-4 inline mr-1" />
                Ongoing
              </button>
              <button
                onClick={() => setCampTab('myReg')}
                className={`flex-1 py-2 px-4 rounded-xl font-medium transition-colors ${
                  campTab === 'myReg'
                    ? 'bg-white text-green-700'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <Users className="w-4 h-4 inline mr-1" />
                My Reg
              </button>
              <button
                onClick={() => setCampTab('map')}
                className={`flex-1 py-2 px-4 rounded-xl font-medium transition-colors ${
                  campTab === 'map'
                    ? 'bg-white text-green-700'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <MapPin className="w-4 h-4 inline mr-1" />
                Map
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {campTab === 'upcoming' && (
              <>
                {/* Search */}
                <div className="relative mb-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search health camps..."
                    className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>

                {/* Camps List */}
                <div className="space-y-4 mb-4">
                  {upcomingCamps.map((camp) => (
                    <div key={camp.id} className="bg-white border-2 border-gray-200 rounded-2xl p-4 hover:shadow-lg transition-shadow">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold pr-2">{camp.name}</h3>
                        {camp.isFree && (
                          <span className="bg-green-500 text-white text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap">
                            FREE
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{camp.nameHindi}</p>
                      
                      <div className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                        <Building className="w-4 h-4 text-gray-500" />
                        <span>{camp.organizer}</span>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm mb-2">
                        <div className="flex items-center gap-2 text-gray-700">
                          <Calendar className="w-4 h-4 text-gray-500" />
                          <span>{camp.date}</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <Clock className="w-4 h-4 text-gray-500" />
                          <span>{camp.time}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>{camp.location}</span>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm mb-3">
                        <div className="flex items-center gap-2 text-gray-700">
                          <Target className="w-4 h-4 text-gray-500" />
                          <span>{camp.distance} km away</span>
                        </div>
                        <div className="flex items-center gap-2 text-gray-700">
                          <Users className="w-4 h-4 text-gray-500" />
                          <span>{camp.registered}/{camp.capacity}</span>
                        </div>
                      </div>
                      
                      <div className="mb-3">
                        <p className="text-xs text-gray-600 mb-2">Services / सेवाएं:</p>
                        <div className="flex flex-wrap gap-2">
                          {camp.services.map((service, idx) => (
                            <span key={idx} className="bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full">
                              {service}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <button className="flex-1 bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2">
                          <Users className="w-4 h-4" />
                          <span>Register Now</span>
                        </button>
                        <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                          <Phone className="w-5 h-5 text-gray-700" />
                        </button>
                        <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                          <Share2 className="w-5 h-5 text-gray-700" />
                        </button>
                      </div>
                      
                      <div className="mt-3 pt-3 border-t border-gray-200 flex items-center justify-between">
                        <p className="text-xs text-gray-600">Contact: {camp.contact}</p>
                        <button className="text-green-600 text-sm font-medium hover:underline">
                          View Details
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Info Box */}
                <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-green-900 mb-2">Health Camps Information</p>
                      <p className="text-sm text-green-800 mb-2">
                        Free health camps provide essential medical services to communities. Register early as spots are limited. Bring your Aadhaar card for registration.
                      </p>
                      <p className="text-sm text-green-800">
                        मुफ्त स्वास्थ्य शिविर समुदायों को आवश्यक चिकित्सा सेवाएं प्रदान करते हैं। स्थान सीमित होने के कारण जल्दी पंजीकरण करें। पंजीकरण के लिए आधार कार्ड लाएं।
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {campTab === 'ongoing' && (
              <>
                <div className="space-y-4 mb-4">
                  {/* Ongoing Camp 1 */}
                  <div className="bg-white border-2 border-green-500 rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold pr-2">General Health Check-up Camp</h3>
                      <div className="flex items-center gap-1 bg-green-500 text-white text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap">
                        <Clock className="w-3 h-3" />
                        <span>LIVE NOW</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">सामान्य स्वास्थ्य जांच शिविर</p>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                      <Building className="w-4 h-4 text-gray-500" />
                      <span>Municipal Corporation</span>
                    </div>
                    
                    <div className="bg-green-50 border border-green-200 rounded-xl p-3 mb-3">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-gray-700 font-medium">Running Until:</span>
                        <span className="text-green-700 font-semibold">6:00 PM Today</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>Community Health Center, Sector 12</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm mb-3">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Target className="w-4 h-4 text-gray-500" />
                        <span>1.2 km away</span>
                      </div>
                      <div className="flex items-center gap-2 text-green-700 font-medium">
                        <Users className="w-4 h-4" />
                        <span>58 people checked in</span>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-xs text-gray-600 mb-2">Available Services:</p>
                      <div className="flex flex-wrap gap-2">
                        <span className="bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full">Blood Pressure</span>
                        <span className="bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full">Sugar Test</span>
                        <span className="bg-green-50 text-green-700 text-xs px-3 py-1 rounded-full">BMI Check</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <button className="flex-1 bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2">
                        <Navigation className="w-4 h-4" />
                        <span>Navigate Now</span>
                      </button>
                      <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                        <Phone className="w-5 h-5 text-gray-700" />
                      </button>
                    </div>
                  </div>

                  {/* Ongoing Camp 2 */}
                  <div className="bg-white border-2 border-green-500 rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold pr-2">COVID-19 Vaccination Camp</h3>
                      <div className="flex items-center gap-1 bg-green-500 text-white text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap">
                        <Clock className="w-3 h-3" />
                        <span>LIVE NOW</span>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">कोविड-19 टीकाकरण शिविर</p>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                      <Building className="w-4 h-4 text-gray-500" />
                      <span>Health Department</span>
                    </div>
                    
                    <div className="bg-green-50 border border-green-200 rounded-xl p-3 mb-3">
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-gray-700 font-medium">Running Until:</span>
                        <span className="text-green-700 font-semibold">4:00 PM Today</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span>District Hospital, Main Road</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm mb-3">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Target className="w-4 h-4 text-gray-500" />
                        <span>2.5 km away</span>
                      </div>
                      <div className="flex items-center gap-2 text-green-700 font-medium">
                        <Users className="w-4 h-4" />
                        <span>124 people vaccinated</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <button className="flex-1 bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2">
                        <Navigation className="w-4 h-4" />
                        <span>Navigate Now</span>
                      </button>
                      <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                        <Phone className="w-5 h-5 text-gray-700" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Info */}
                <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-blue-900 mb-2">Ongoing Camps</p>
                      <p className="text-sm text-blue-800">
                        These camps are currently active. You can walk in without registration. Make sure to reach before the camp ends.
                      </p>
                      <p className="text-sm text-blue-800 mt-2">
                        ये शिविर वर्तमान में सक्रिय हैं। आप बिना पंजीकरण के जा सकते हैं। शिविर समाप्त होने से पहले पहुंचना सुनिश्चित करें।
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {campTab === 'myReg' && (
              <>
                <div className="space-y-4 mb-4">
                  {/* Registration 1 */}
                  <div className="bg-white border-2 border-cyan-200 rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold pr-2">Women & Child Health Camp</h3>
                      <span className="bg-cyan-500 text-white text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap">
                        CONFIRMED
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">महिला और बाल स्वास्थ्य शिविर</p>
                    
                    <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-3 mb-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-700">Registration ID:</span>
                        <span className="text-sm font-mono font-semibold text-cyan-700">CAMP-2026-001234</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-700">Token Number:</span>
                        <span className="text-lg font-bold text-cyan-700">A-42</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm mb-2">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>Feb 20, 2026</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-700">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span>8:00 AM - 2:00 PM</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-700 mb-3">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span>Primary Health Center, Sector 15</span>
                    </div>
                    
                    <div className="flex gap-2">
                      <button className="flex-1 bg-cyan-600 text-white py-3 rounded-xl font-medium hover:bg-cyan-700 transition-colors">
                        View Details
                      </button>
                      <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                        <Share2 className="w-5 h-5 text-gray-700" />
                      </button>
                      <button className="bg-red-50 p-3 rounded-xl hover:bg-red-100 transition-colors">
                        <X className="w-5 h-5 text-red-600" />
                      </button>
                    </div>
                  </div>

                  {/* Registration 2 */}
                  <div className="bg-white border-2 border-cyan-200 rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold pr-2">Diabetes Screening Camp</h3>
                      <span className="bg-cyan-500 text-white text-xs px-3 py-1 rounded-full font-medium whitespace-nowrap">
                        CONFIRMED
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">मधुमेह जांच शिविर</p>
                    
                    <div className="bg-cyan-50 border border-cyan-200 rounded-xl p-3 mb-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-700">Registration ID:</span>
                        <span className="text-sm font-mono font-semibold text-cyan-700">CAMP-2026-001567</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-700">Token Number:</span>
                        <span className="text-lg font-bold text-cyan-700">B-18</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm mb-2">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>Feb 25, 2026</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-700">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span>9:00 AM - 3:00 PM</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-700 mb-3">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span>Community Hall, Nehru Nagar</span>
                    </div>
                    
                    <div className="flex gap-2">
                      <button className="flex-1 bg-cyan-600 text-white py-3 rounded-xl font-medium hover:bg-cyan-700 transition-colors">
                        View Details
                      </button>
                      <button className="bg-gray-100 p-3 rounded-xl hover:bg-gray-200 transition-colors">
                        <Share2 className="w-5 h-5 text-gray-700" />
                      </button>
                      <button className="bg-red-50 p-3 rounded-xl hover:bg-red-100 transition-colors">
                        <X className="w-5 h-5 text-red-600" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Info */}
                <div className="bg-purple-50 border-2 border-purple-200 rounded-2xl p-4">
                  <div className="flex items-start gap-3">
                    <Info className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-purple-900 mb-2">My Registrations</p>
                      <p className="text-sm text-purple-800">
                        Your confirmed camp registrations are listed here. Save your token number and reach the venue on time. You can cancel up to 24 hours before the camp.
                      </p>
                      <p className="text-sm text-purple-800 mt-2">
                        आपके पुष्ट शिविर पंजीकरण यहां सूचीबद्ध हैं। अपना टोकन नंबर सहेजें और समय पर स्थल पर पहुंचें।
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {campTab === 'map' && (
              <>
                {/* Map Placeholder */}
                <div className="bg-gray-100 rounded-2xl h-80 mb-4 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-green-200"></div>
                  <div className="relative z-10 text-center">
                    <MapPin className="w-16 h-16 text-green-600 mx-auto mb-3" />
                    <p className="text-gray-700 font-medium mb-2">Interactive Map View</p>
                    <p className="text-sm text-gray-600">Showing all health camps near you</p>
                  </div>
                  
                  {/* Mock Map Markers */}
                  <div className="absolute top-1/4 left-1/3 z-20">
                    <div className="bg-green-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg animate-bounce">
                      <Tent className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="absolute top-1/2 right-1/4 z-20">
                    <div className="bg-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg">
                      <Tent className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="absolute bottom-1/3 left-1/2 z-20">
                    <div className="bg-purple-600 text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg">
                      <Tent className="w-5 h-5" />
                    </div>
                  </div>
                </div>

                {/* Map Legend */}
                <div className="bg-white border-2 border-gray-200 rounded-2xl p-4 mb-4">
                  <h3 className="font-semibold mb-3">Map Legend / मानचित्र लीजेंड</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <div className="bg-green-600 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0">
                        <Tent className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm text-gray-700">Ongoing Camps (Live)</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-600 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0">
                        <Tent className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm text-gray-700">Upcoming Camps</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-600 rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0">
                        <Tent className="w-4 h-4 text-white" />
                      </div>
                      <span className="text-sm text-gray-700">Your Registrations</span>
                    </div>
                  </div>
                </div>

                {/* Nearby Camps List */}
                <div className="bg-white border-2 border-gray-200 rounded-2xl p-4">
                  <h3 className="font-semibold mb-3">Camps Near You</h3>
                  <div className="space-y-3">
                    <button className="w-full text-left flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
                        <Tent className="w-4 h-4 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">General Health Check-up</p>
                        <p className="text-xs text-gray-600">1.2 km • Live Now</p>
                      </div>
                      <Navigation className="w-4 h-4 text-green-600 flex-shrink-0 mt-1" />
                    </button>
                    
                    <button className="w-full text-left flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                        <Tent className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">Women & Child Health</p>
                        <p className="text-xs text-gray-600">2.8 km • Feb 20</p>
                      </div>
                      <Navigation className="w-4 h-4 text-blue-600 flex-shrink-0 mt-1" />
                    </button>
                    
                    <button className="w-full text-left flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                      <div className="bg-purple-100 rounded-full p-2 flex-shrink-0">
                        <Tent className="w-4 h-4 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">Diabetes Screening</p>
                        <p className="text-xs text-gray-600">3.5 km • Feb 25 (Registered)</p>
                      </div>
                      <Navigation className="w-4 h-4 text-purple-600 flex-shrink-0 mt-1" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={() => setCurrentView('main')}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors"
            >
              Close / बंद करें
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Quick Navigation View
  if (currentView === 'quickNav') {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center sm:justify-center">
        <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <Navigation className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Quick Navigation</h2>
                  <p className="text-sm text-blue-100">त्वरित नेविगेशन</p>
                </div>
              </div>
              <button
                onClick={() => setCurrentView('main')}
                className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* Quick Access Cards */}
            <div className="space-y-4 mb-6">
              {/* Nearest Emergency Hospital */}
              <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-5">
                <div className="flex items-start gap-3 mb-3">
                  <div className="bg-red-100 rounded-xl p-3">
                    <Ambulance className="w-6 h-6 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-red-900 mb-1">Nearest Emergency Hospital</h3>
                    <p className="text-sm text-red-700 mb-2">निकटतम आपातकालीन अस्पताल</p>
                    <p className="text-sm text-red-800 font-medium">City General Hospital - 0.8 km away</p>
                  </div>
                </div>
                <button className="w-full bg-red-600 text-white py-3 rounded-xl font-medium hover:bg-red-700 transition-colors flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4" />
                  <span>Navigate Now</span>
                </button>
              </div>

              {/* Nearest 24/7 Hospital */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
                <div className="flex items-start gap-3 mb-3">
                  <div className="bg-blue-100 rounded-xl p-3">
                    <Hospital className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-blue-900 mb-1">Nearest 24/7 Hospital</h3>
                    <p className="text-sm text-blue-700 mb-2">निकटतम 24/7 अस्पताल</p>
                    <p className="text-sm text-blue-800 font-medium">Fortis Hospital - 2.3 km away</p>
                  </div>
                </div>
                <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4" />
                  <span>Navigate Now</span>
                </button>
              </div>

              {/* Nearest Pharmacy */}
              <div className="bg-green-50 border-2 border-green-200 rounded-2xl p-5">
                <div className="flex items-start gap-3 mb-3">
                  <div className="bg-green-100 rounded-xl p-3">
                    <Pill className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-green-900 mb-1">Nearest Pharmacy</h3>
                    <p className="text-sm text-green-700 mb-2">निकटतम फार्मेसी</p>
                    <p className="text-sm text-green-800 font-medium">MedPlus Pharmacy - 0.5 km away</p>
                  </div>
                </div>
                <button className="w-full bg-green-600 text-white py-3 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4" />
                  <span>Navigate Now</span>
                </button>
              </div>

              {/* Nearest Govt Scheme Hospital */}
              <div className="bg-orange-50 border-2 border-orange-200 rounded-2xl p-5">
                <div className="flex items-start gap-3 mb-3">
                  <div className="bg-orange-100 rounded-xl p-3">
                    <Building2 className="w-6 h-6 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-orange-900 mb-1">Nearest Govt Scheme Hospital</h3>
                    <p className="text-sm text-orange-700 mb-2">निकटतम सरकारी योजना अस्पताल</p>
                    <p className="text-sm text-orange-800 font-medium">Government District Hospital - 3.1 km away</p>
                  </div>
                </div>
                <button className="w-full bg-orange-600 text-white py-3 rounded-xl font-medium hover:bg-orange-700 transition-colors flex items-center justify-center gap-2">
                  <Navigation className="w-4 h-4" />
                  <span>Navigate Now</span>
                </button>
              </div>
            </div>

            {/* Saved Locations */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Bookmark className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Saved Locations / सहेजे गए स्थान</h3>
              </div>
              <div className="bg-gray-50 rounded-2xl p-4 text-center">
                <p className="text-sm text-gray-600">
                  No saved locations yet. Save your favorite hospitals for quick access.
                </p>
              </div>
            </div>

            {/* Recent Navigation */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <History className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Recent Navigation / हाल का नेविगेशन</h3>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Building2 className="w-5 h-5 text-gray-600" />
                    <span className="text-sm">City General Hospital</span>
                  </div>
                  <button className="text-blue-600 text-sm font-medium hover:underline">
                    Navigate
                  </button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <Pill className="w-5 h-5 text-gray-600" />
                    <span className="text-sm">MedPlus Pharmacy</span>
                  </div>
                  <button className="text-blue-600 text-sm font-medium hover:underline">
                    Navigate
                  </button>
                </div>
              </div>
            </div>

            {/* Share Location */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Share2 className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Share Location / स्थान साझा करें</h3>
              </div>
              <button className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                <Share2 className="w-4 h-4" />
                <span>Share My Location with Family</span>
              </button>
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-900 mb-2">Quick Navigation Info</p>
                  <p className="text-sm text-blue-800 mb-2">
                    Find the nearest medical facilities instantly. Save frequently visited hospitals and share your location with family members for safety.
                  </p>
                  <p className="text-sm text-blue-800">
                    निकटतम चिकित्सा सुविधाएं तुरंत खोजें। बार-बार जाने वाले अस्पतालों को सहेजें और सुरक्षा के लिए परिवार के सदस्यों के साथ अपना स्थान साझा करें।
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={() => setCurrentView('main')}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors"
            >
              Close / बंद करें
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Map Settings View
  if (currentView === 'mapSettings') {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center sm:justify-center">
        <div className="bg-white w-full max-w-2xl max-h-[90vh] rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 rounded-full p-2">
                  <Settings className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Map Settings</h2>
                  <p className="text-sm text-blue-100">मैप सेटिंग्स</p>
                </div>
              </div>
              <button
                onClick={() => setCurrentView('main')}
                className="bg-white/20 rounded-full p-2 hover:bg-white/30 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* Map Display Style */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Layers className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Map Display Style / मैप प्रदर्शन शैली</h3>
              </div>
              <div className="bg-gray-50 rounded-2xl p-2 flex gap-2">
                <button
                  onClick={() => setMapStyle('standard')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    mapStyle === 'standard'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Map className="w-4 h-4 inline mr-1" />
                  Standard
                </button>
                <button
                  onClick={() => setMapStyle('satellite')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    mapStyle === 'satellite'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Layers className="w-4 h-4 inline mr-1" />
                  Satellite
                </button>
                <button
                  onClick={() => setMapStyle('terrain')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    mapStyle === 'terrain'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <Target className="w-4 h-4 inline mr-1" />
                  Terrain
                </button>
              </div>
            </div>

            {/* Distance Unit */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Ruler className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Distance Unit / दूरी इकाई</h3>
              </div>
              <div className="bg-gray-50 rounded-2xl p-2 flex gap-2">
                <button
                  onClick={() => setDistanceUnit('km')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    distanceUnit === 'km'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  Kilometers (km)
                </button>
                <button
                  onClick={() => setDistanceUnit('mi')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    distanceUnit === 'mi'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  Miles (mi)
                </button>
              </div>
            </div>

            {/* Map Display Preferences */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Eye className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Map Display Preferences</h3>
              </div>
              <div className="space-y-3">
                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">स्वचालित स्थान</p>
                      <p className="text-sm text-gray-600">Auto-detect location on load</p>
                    </div>
                    <button
                      onClick={() => setAutoDetectLocation(!autoDetectLocation)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        autoDetectLocation ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                          autoDetectLocation ? 'translate-x-6' : ''
                        }`}
                      />
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">आपातकालीन दिखाएं</p>
                      <p className="text-sm text-gray-600">Show emergency facilities</p>
                    </div>
                    <button
                      onClick={() => setShowEmergencyFacilities(!showEmergencyFacilities)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        showEmergencyFacilities ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                          showEmergencyFacilities ? 'translate-x-6' : ''
                        }`}
                      />
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">24/7 सुविधाएं दिखाएं</p>
                      <p className="text-sm text-gray-600">Highlight 24/7 facilities</p>
                    </div>
                    <button
                      onClick={() => setHighlight24x7(!highlight24x7)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        highlight24x7 ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                          highlight24x7 ? 'translate-x-6' : ''
                        }`}
                      />
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">सरकारी योजना अस्पताल</p>
                      <p className="text-sm text-gray-600">Show govt scheme hospitals</p>
                    </div>
                    <button
                      onClick={() => setShowGovtSchemeHospitals(!showGovtSchemeHospitals)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${
                        showGovtSchemeHospitals ? 'bg-blue-600' : 'bg-gray-300'
                      }`}
                    >
                      <div
                        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                          showGovtSchemeHospitals ? 'translate-x-6' : ''
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Route Preference */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Route className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold">Route Preference / मार्ग प्राथमिकता</h3>
              </div>
              <div className="bg-gray-50 rounded-2xl p-2 flex gap-2">
                <button
                  onClick={() => setRoutePreference('fastest')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    routePreference === 'fastest'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div>Fastest Route</div>
                  <div className="text-xs opacity-75">तेज रास्ता</div>
                </button>
                <button
                  onClick={() => setRoutePreference('shortest')}
                  className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
                    routePreference === 'shortest'
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <div>Shortest Route</div>
                  <div className="text-xs opacity-75">छोटा रास्ता</div>
                </button>
              </div>
            </div>

            {/* Info Box */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-blue-900 mb-2">Map Settings Info</p>
                  <p className="text-sm text-blue-800 mb-2">
                    Customize how you view medical facilities on the map. Choose your preferred map style, distance units, and filter options to find the right healthcare facility quickly.
                  </p>
                  <p className="text-sm text-blue-800">
                    मैप पर चिकित्सा सुविधाओं को कैसे देखना है, इसे अनुकूलित करें। अपनी पसंदीदा मैप शैली, दूरी इकाइयों और फ़िल्टर विकल्प चुनें।
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={() => setCurrentView('main')}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors"
            >
              Done / पूर्ण
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
