import { Globe } from 'lucide-react';

interface LanguageIndicatorProps {
  language: string;
}

export function LanguageIndicator({ language }: LanguageIndicatorProps) {
  const isHindi = language?.toLowerCase() === 'hindi' || language?.toLowerCase() === 'हिंदी';
  
  return (
    <div className="flex items-center gap-2 bg-white/20 px-3 py-1.5 rounded-full text-sm">
      <Globe className="w-4 h-4" />
      <span>{isHindi ? 'हिंदी' : 'English'}</span>
    </div>
  );
}

// Helper function to determine if Hindi is selected
export function isHindiLanguage(language?: string): boolean {
  return language?.toLowerCase() === 'hindi' || language?.toLowerCase() === 'हिंदी';
}

// Text helper - returns Hindi or English based on language
export function getText(englishText: string, hindiText: string, language?: string): string {
  return isHindiLanguage(language) ? hindiText : englishText;
}
