import { CheckCircle, ArrowLeft } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

interface OTPScreenProps {
  mobile: string;
  onContinue: () => void;
  onGoBack: () => void;
}

export function OTPScreen({ mobile, onContinue, onGoBack }: OTPScreenProps) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [countdown, setCountdown] = useState(25);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.every(digit => digit !== '')) {
      onContinue();
    }
  };

  const maskedMobile = `+91 ${mobile.slice(0, 2)}***${mobile.slice(-2)}`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-cyan-500 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl mb-2">OTP सत्यापन</h1>
          <p className="text-cyan-600">OTP Verification</p>
        </div>

        {/* OTP form */}
        <div className="bg-white rounded-3xl shadow-lg p-8 mb-6">
          <form onSubmit={handleSubmit}>
            <div className="text-center mb-6">
              <p className="text-gray-600 mb-2">OTP भेजा गया / OTP sent to</p>
              <p className="text-2xl mb-6">{maskedMobile}</p>
              
              <p className="text-sm text-gray-600 mb-4">6 अंकों का OTP दर्ज करें / Enter 6-digit OTP</p>

              {/* OTP inputs */}
              <div className="flex justify-center gap-2 mb-6">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => (inputRefs.current[index] = el)}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleChange(index, e.target.value.replace(/\D/g, ''))}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    className="w-12 h-14 text-center text-xl bg-cyan-50 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-400 transition-colors"
                  />
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-cyan-400 hover:bg-cyan-500 text-white py-4 rounded-xl transition-colors mb-4 disabled:bg-gray-300 disabled:cursor-not-allowed"
              disabled={otp.some(digit => digit === '')}
            >
              सत्यापन करें / Verify
            </button>

            <p className="text-center text-cyan-600">
              {countdown > 0 ? (
                <>25 सेकंड में पुन: भेजें / Resend in {countdown}s</>
              ) : (
                <button type="button" className="text-cyan-600 hover:underline">
                  पुन: भेजें / Resend OTP
                </button>
              )}
            </p>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-center text-sm text-cyan-600">
              डेमो के लिए कोई भी 6 अंकों का OTP दर्ज करें
              <br />
              Enter any 6-digit OTP for demo
            </p>
          </div>
        </div>

        {/* Go back button */}
        <button
          onClick={onGoBack}
          className="flex items-center justify-center gap-2 mx-auto text-cyan-600 hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          वापस जाएं / Go Back
        </button>
      </div>
    </div>
  );
}
