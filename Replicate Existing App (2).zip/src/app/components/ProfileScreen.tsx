import { 
  ArrowLeft, 
  User, 
  Phone, 
  Calendar, 
  Globe, 
  Shield, 
  Settings, 
  LogOut, 
  ChevronRight, 
  CheckCircle, 
  Bell, 
  HelpCircle, 
  Mail, 
  MessageCircle, 
  Book, 
  FileText, 
  AlertCircle, 
  Info, 
  X, 
  Download, 
  Video, 
  ExternalLink, 
  Clock, 
  MapPin, 
  Send,
  Search,
  Lock,
  Eye,
  Database,
  Pill,
  ClipboardCheck,
  Stethoscope,
  Building2,
  BookOpen,
  Gift,
  AlertTriangle,
  Trash2,
  Smartphone,
  Moon,
  VolumeX,
  Vibrate,
  Palette,
  Type,
  Zap,
  Wifi,
  HardDrive,
  Share2,
  Copyright,
  Code
} from 'lucide-react';
import { useState } from 'react';

interface ProfileScreenProps {
  onBack: () => void;
}

type SettingsView = 'profile' | 'settings' | 'change-number' | 'notifications' | 'language' | 'help' | 'contact-us' | 'resources' | 'faq-detail';

export function ProfileScreen({ onBack }: ProfileScreenProps) {
  const [currentView, setCurrentView] = useState<SettingsView>('profile');
  const [name, setName] = useState('677889999');
  const [phoneNumber] = useState('+91 6677889999');
  const [selectedAgeRange, setSelectedAgeRange] = useState('18-30');
  const [selectedLanguage, setSelectedLanguage] = useState('hindi');
  const [newPhoneNumber, setNewPhoneNumber] = useState('');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  
  // Contact form states
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  
  // Settings states
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [medicationReminders, setMedicationReminders] = useState(true);
  const [appointmentReminders, setAppointmentReminders] = useState(true);
  const [healthTips, setHealthTips] = useState(true);
  
  // App Preferences
  const [darkMode, setDarkMode] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vibrateEnabled, setVibrateEnabled] = useState(true);
  const [autoDownloadMedia, setAutoDownloadMedia] = useState(false);
  const [largeText, setLargeText] = useState(false);
  
  // Privacy & Security
  const [biometricAuth, setBiometricAuth] = useState(false);
  const [showOnlineStatus, setShowOnlineStatus] = useState(true);
  const [shareLocationWithFamily, setShareLocationWithFamily] = useState(false);

  const ageRanges = [
    { value: '18-30', label: '18-30' },
    { value: '31-45', label: '31-45' },
    { value: '46-60', label: '46-60' },
    { value: '60+', label: '60+' }
  ];

  const languages = [
    { value: 'hindi', label: 'हिंदी / Hindi', flag: '🇮🇳', speakers: '52+ करोड़ बोलने वाले / 520M+ speakers' },
    { value: 'marathi', label: 'मराठी / Marathi', flag: '🇮🇳', speakers: '8+ करोड़ बोलने वाले / 80M+ speakers' },
    { value: 'bengali', label: 'बांग्ला / Bengali', flag: '🇮🇳', speakers: '23+ करोड़ बोलने वाले / 230M+ speakers' },
    { value: 'english', label: 'English', flag: '🇬🇧', speakers: '125M+ speakers' }
  ];

  const handleSaveProfile = () => {
    // Save profile logic
    alert('Profile updated successfully!');
  };

  const handleLogout = () => {
    if (confirm('Are you sure you want to logout? / क्या आप लॉग आउट करना चाहते हैं?')) {
      // Logout logic
      alert('Logged out successfully');
    }
  };

  // Profile View
  if (currentView === 'profile') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-500 to-purple-700">
        {/* Header */}
        <header className="px-4 py-4 text-white">
          <button onClick={onBack} className="flex items-center gap-2 mb-6">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">प्रोफाइल</h1>
          <p className="text-sm text-purple-100">Profile</p>
        </header>

        {/* Main Content */}
        <div className="px-4 pb-24">
          {/* Profile Card */}
          <div className="bg-white rounded-3xl p-6 mb-4">
            <div className="flex flex-col items-center mb-6">
              <div className="bg-purple-600 rounded-full p-8 mb-4">
                <User className="w-12 h-12 text-white" />
              </div>
              <h2 className="text-3xl font-medium mb-2">{name}</h2>
              <p className="text-cyan-500">{phoneNumber}</p>
            </div>
          </div>

          {/* Edit Profile Section */}
          <div className="bg-white rounded-3xl p-6 mb-4">
            <h3 className="font-medium mb-4">प्रोफाइल संपादित करें / Edit Profile</h3>

            {/* Name Input */}
            <div className="mb-4">
              <label className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                <User className="w-4 h-4" />
                नाम / Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border-2 border-cyan-400 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
              />
            </div>

            {/* Mobile Number (Read-only) */}
            <div className="mb-4">
              <label className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                <Phone className="w-4 h-4" />
                मोबाइल नंबर / Mobile Number
              </label>
              <div className="w-full px-4 py-3 border-2 border-cyan-400 rounded-2xl bg-cyan-50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-cyan-600" />
                  <span>{phoneNumber}</span>
                </div>
                <span className="text-sm text-cyan-600">(सत्यापित / Verified)</span>
              </div>
            </div>

            {/* Age Range */}
            <div className="mb-4">
              <label className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                <Calendar className="w-4 h-4" />
                आयु वर्ग / Age Range
              </label>
              <div className="grid grid-cols-2 gap-3">
                {ageRanges.map((range) => (
                  <button
                    key={range.value}
                    onClick={() => setSelectedAgeRange(range.value)}
                    className={`py-3 px-4 rounded-2xl border-2 transition-colors ${
                      selectedAgeRange === range.value
                        ? 'bg-purple-100 border-purple-500 text-purple-700'
                        : 'bg-white border-cyan-400 text-gray-700'
                    }`}
                  >
                    {range.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Language */}
            <div className="mb-6">
              <label className="flex items-center gap-2 text-sm text-gray-700 mb-2">
                <Globe className="w-4 h-4" />
                भाषा / Language
              </label>
              <button
                onClick={() => setCurrentView('language')}
                className="w-full py-3 px-4 rounded-2xl border-2 border-purple-500 bg-purple-50 text-purple-700 flex items-center justify-between"
              >
                <span>हिंदी / Hindi</span>
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Save Button */}
            <button
              onClick={handleSaveProfile}
              className="w-full bg-purple-600 text-white py-4 rounded-2xl hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5" />
              <span>सहेजें / Save</span>
            </button>
          </div>

          {/* Privacy Section */}
          <div className="bg-cyan-50 border-2 border-cyan-400 rounded-3xl p-5 mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-5 h-5 text-cyan-600" />
              <h3 className="font-medium">गोपनीयता / Privacy</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>आपका डेटा सुरक्षित है / Your data is secure</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>आधार नंबर संग्रहित नहीं किया गया / Aadhaar not stored</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>स्वास्थ्य जानकारी एन्क्रिप्टेड है / Health info encrypted</span>
              </li>
            </ul>
          </div>

          {/* Settings Button */}
          <button
            onClick={() => setCurrentView('settings')}
            className="w-full bg-white border-2 border-cyan-400 text-gray-900 py-4 rounded-2xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2 mb-4"
          >
            <Settings className="w-5 h-5" />
            <span>सेटिंग्स / Settings</span>
          </button>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full bg-white border-2 border-red-400 text-red-600 py-4 rounded-2xl hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            <span>लॉग आउट / Logout</span>
          </button>
        </div>
      </div>
    );
  }

  // Settings View
  if (currentView === 'settings') {
    return (
      <div className="min-h-screen bg-cyan-50 relative">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-6 text-white">
          <button onClick={() => setCurrentView('profile')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl font-bold mb-1">सेटिंग्स</h1>
          <p className="text-sm">Settings</p>
        </header>

        {/* Main Content */}
        <div className="px-5 py-6 pb-24">
          {/* Account Settings */}
          <h2 className="text-lg font-bold mb-4 text-cyan-600">खाता / Account</h2>

          {/* Change Mobile Number */}
          <button
            onClick={() => setCurrentView('change-number')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Phone className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">मोबाइल नंबर बदलें</h3>
              <p className="text-sm text-cyan-600 mb-1">Change Mobile Number</p>
              <p className="text-sm text-gray-600">+91 6677889999</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Notifications */}
          <button
            onClick={() => setCurrentView('notifications')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Bell className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">सूचनाएं</h3>
              <p className="text-sm text-cyan-600 mb-1">Notifications</p>
              <p className="text-sm text-gray-600">+91 चालू / Enabled</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Language */}
          <button
            onClick={() => setCurrentView('language')}
            className="w-full bg-white rounded-2xl p-5 mb-4 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <Globe className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">भाषा</h3>
              <p className="text-sm text-cyan-600 mb-1">Language</p>
              <p className="text-sm text-gray-600">+91 हिंदी / Hindi</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Help & Support */}
          <button
            onClick={() => setCurrentView('help')}
            className="w-full bg-white rounded-2xl p-5 mb-6 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="bg-cyan-100 rounded-full p-3">
              <HelpCircle className="w-6 h-6 text-cyan-600" />
            </div>
            <div className="flex-1 text-left">
              <h3 className="font-bold mb-1">सहायता और समर्थन</h3>
              <p className="text-sm text-cyan-600">Help & Support</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          {/* Security Information */}
          <div className="bg-cyan-50 border-2 border-cyan-400 rounded-2xl p-5 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-6 h-6 text-cyan-600" />
              <h3 className="font-bold text-gray-800">सुरक्षा जानकारी / Security Information</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>आपकी जानकारी सुरक्षित और एन्क्रिप्टेड है</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>Your information is secure and encrypted</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>हम आपका डेटा कभी साझा नहीं करते / We never share your data</span>
              </li>
            </ul>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full bg-white border-2 border-red-400 text-red-600 py-4 rounded-2xl hover:bg-red-50 transition-colors flex items-center justify-center gap-2 font-medium"
          >
            <LogOut className="w-5 h-5" />
            <span>लॉग आउट / Logout</span>
          </button>
        </div>

        {/* Floating Language Button */}
        <button 
          onClick={() => setCurrentView('language')}
          className="fixed bottom-6 right-6 bg-cyan-600 text-white p-4 rounded-full shadow-lg hover:bg-cyan-700 transition-colors z-50"
          aria-label="Change Language"
        >
          <Globe className="w-6 h-6" />
        </button>
      </div>
    );
  }

  // Change Mobile Number View
  if (currentView === 'change-number') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">मोबाइल नंबर बदलें</h1>
          <p className="text-sm text-cyan-100">Change Mobile Number</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6">
          <div className="bg-white rounded-3xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-medium">मोबाइल नंबर / Mobile Number</h2>
              <Shield className="w-5 h-5 text-cyan-600" />
            </div>

            {/* Current Number */}
            <div className="mb-6">
              <label className="block text-sm text-gray-700 mb-2">वर्तमान नंबर / Current Number</label>
              <div className="flex items-center gap-2 px-4 py-3 bg-cyan-50 border-2 border-cyan-400 rounded-2xl">
                <Phone className="w-4 h-4 text-cyan-600" />
                <span className="flex-1">{phoneNumber}</span>
                <span className="text-sm text-green-600 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" />
                  सत्यापित
                </span>
              </div>
            </div>

            {/* New Number */}
            <div className="mb-6">
              <label className="block text-sm text-gray-700 mb-2">नया मोबाइल नंबर / New Mobile Number</label>
              <div className="flex gap-2">
                <div className="px-4 py-3 bg-gray-100 border border-gray-300 rounded-2xl text-gray-700">
                  +91
                </div>
                <input
                  type="tel"
                  placeholder="10 अंकों का नंबर"
                  maxLength={10}
                  value={newPhoneNumber}
                  onChange={(e) => setNewPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  className="flex-1 px-4 py-3 border-2 border-cyan-400 rounded-2xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>

            {/* Warning */}
            <div className="bg-yellow-50 border-2 border-yellow-400 rounded-2xl p-4 mb-6">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="text-gray-700 mb-1">नए नंबर पर OTP भेजा जाएगा। कृपया सुनिश्चित करें कि नंबर सही है।</p>
                  <p className="text-gray-600">OTP will be sent to the new number. Please ensure the number is correct.</p>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => setCurrentView('settings')}
                className="flex-1 py-4 border-2 border-cyan-400 text-gray-700 rounded-2xl hover:bg-gray-50 transition-colors"
              >
                रद्द करें / Cancel
              </button>
              <button
                onClick={() => alert('OTP sent to new number')}
                className="flex-1 py-4 bg-cyan-500 text-white rounded-2xl hover:bg-cyan-600 transition-colors"
              >
                OTP भेजें / Send OTP
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Notifications Settings View
  if (currentView === 'notifications') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">सूचनाएं</h1>
          <p className="text-sm text-cyan-100">Notifications</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-cyan-600">नए सूचनाएं / Recent</h2>
            <button className="text-sm text-gray-600">सेटिंग्स / Settings</button>
          </div>

          {/* Recent Notifications */}
          <div className="bg-white rounded-3xl p-5 mb-6">
            <h3 className="font-medium mb-4">नए सूचनाएं / Recent Notifications</h3>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">रक्तचाप की दवा का समय</p>
                  <p className="text-xs text-gray-600">एलोरिडिपाइन 5mg लेने का समय</p>
                </div>
                <span className="text-xs text-gray-500">15 minutes ago</span>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-red-100 rounded-full p-2 flex-shrink-0">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">आज का स्वास्थ्य सुझाव</p>
                  <p className="text-xs text-gray-600">हाइड्रेटेड रहें! प्रतिदिन 8 गिलास पानी पिएं</p>
                </div>
                <span className="text-xs text-gray-500">2 hours ago</span>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                  <Calendar className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">अपॉइंटमेंट अनुस्मारक</p>
                  <p className="text-xs text-gray-600">कल सुबह 10:00 बजे डॉ. शर्मा से जांच</p>
                </div>
                <span className="text-xs text-gray-500">5 hours ago</span>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-green-100 rounded-full p-2 flex-shrink-0">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">दवा सफलतापूर्वक ली गई</p>
                  <p className="text-xs text-gray-600">मेटफॉर्मिन की सुबह की खुराक पूर्ण</p>
                </div>
                <span className="text-xs text-gray-500">Yesterday</span>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-full p-2 flex-shrink-0">
                  <MessageCircle className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">स्वास्थ्य लेख अपडेट</p>
                  <p className="text-xs text-gray-600">नया लेख: "मधुमेह को प्रभावी ढंग से प्रबंधित करना"</p>
                </div>
                <span className="text-xs text-gray-500">Yesterday</span>
              </div>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="bg-cyan-50 border-2 border-cyan-400 rounded-2xl p-5 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-5 h-5 text-cyan-600" />
              <h3 className="font-medium">सूचना जानकारी / Notification Info</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>दवा की याद दिलाने के लिए समय पर सूचनाएं प्राप्त करें</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>Get timely reminders for medications and appointments</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>आप किसी भी समय सूचनाएं बंद कर सकते हैं / Turn off anytime</span>
              </li>
            </ul>
          </div>

          <button
            onClick={() => setCurrentView('settings')}
            className="w-full bg-cyan-500 text-white py-4 rounded-2xl hover:bg-cyan-600 transition-colors"
          >
            सहेजें / Save Settings
          </button>
        </div>
      </div>
    );
  }

  // Language Selection View
  if (currentView === 'language') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-blue-500 to-blue-700 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">भाषा चुनें</h1>
          <p className="text-sm text-blue-100">Select Language</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6">
          {/* Current Language */}
          <div className="bg-white rounded-2xl p-5 mb-6">
            <div className="flex items-center gap-2 text-gray-700 mb-2">
              <Globe className="w-5 h-5" />
              <h3 className="font-medium">वर्तमान भाषा / Current Language</h3>
            </div>
            <p className="text-cyan-600">हिंदी / Hindi</p>
          </div>

          {/* Available Languages */}
          <div>
            <h3 className="font-medium mb-4">उपलब्ध भाषाएं / Available Languages</h3>
            <div className="space-y-3">
              {languages.map((lang) => (
                <button
                  key={lang.value}
                  onClick={() => setSelectedLanguage(lang.value)}
                  className={`w-full rounded-2xl p-4 transition-all ${
                    selectedLanguage === lang.value
                      ? 'bg-blue-50 border-2 border-blue-500'
                      : 'bg-white border-2 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{lang.flag}</span>
                    <div className="flex-1 text-left">
                      <p className="font-medium">{lang.label}</p>
                      <p className="text-xs text-gray-600">{lang.speakers}</p>
                    </div>
                    {selectedLanguage === lang.value && (
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Language Info */}
          <div className="bg-blue-50 border-2 border-blue-400 rounded-2xl p-5 my-6">
            <div className="flex items-center gap-2 mb-3">
              <Globe className="w-5 h-5 text-blue-600" />
              <h3 className="font-medium">भाषा जानकारी / Language Info</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <span>भाषा बदलने से सभी ऐप कंटेंट अपडेट हो जाएगा</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <span>Changing language will update all app content</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600">•</span>
                <span>आप किसी भी समय भाषा बदल सकते हैं / Change anytime</span>
              </li>
            </ul>
          </div>

          <button
            onClick={() => {
              alert('Language updated successfully!');
              setCurrentView('settings');
            }}
            className="w-full bg-blue-600 text-white py-4 rounded-2xl hover:bg-blue-700 transition-colors"
          >
            भाषा सहेजें / Save Language
          </button>
        </div>
      </div>
    );
  }

  // Help & Support View
  if (currentView === 'help') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">सहायता और समर्थन</h1>
          <p className="text-sm text-cyan-100">Help & Support</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6 pb-24">
          {/* Hero Section */}
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl p-6 mb-6 text-white">
            <div className="flex items-center gap-3">
              <HelpCircle className="w-12 h-12" />
              <div>
                <h2 className="text-xl mb-1">हम यहाँ मदद के लिए हैं</h2>
                <p className="text-sm text-cyan-100">We're here to help you</p>
              </div>
            </div>
          </div>

          {/* Contact Us */}
          <h3 className="font-medium mb-4">हमसे संपर्क करें / Contact Us</h3>

          <div className="space-y-3 mb-6">
            {/* Phone */}
            <button className="w-full bg-white rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="bg-green-100 rounded-full p-3">
                <Phone className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-medium mb-1">फोन / Phone</h4>
                <p className="text-sm text-gray-600 mb-1">सोमवार - शुक्रवार, 9 AM - 6 PM</p>
                <p className="text-sm text-gray-600 mb-1">Mon - Fri, 9 AM - 6 PM</p>
                <p className="text-sm text-cyan-600">1800-XXX-XXXX</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            {/* Email */}
            <button className="w-full bg-white rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="bg-blue-100 rounded-full p-3">
                <Mail className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-medium mb-1">ईमेल / Email</h4>
                <p className="text-sm text-gray-600 mb-1">24 घंटे के भीतर जवाब</p>
                <p className="text-sm text-gray-600 mb-1">Response within 24 hours</p>
                <p className="text-sm text-cyan-600">support@healthapp.in</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            {/* Live Chat */}
            <button className="w-full bg-white rounded-2xl p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-shadow">
              <div className="bg-purple-100 rounded-full p-3">
                <MessageCircle className="w-5 h-5 text-purple-600" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-medium mb-1">लाइव चैट / Live Chat</h4>
                <p className="text-sm text-gray-600 mb-1">तुरंत सहायता प्राप्त करें</p>
                <p className="text-sm text-gray-600 mb-1">Get instant assistance</p>
                <p className="text-sm text-cyan-600">Chat Now</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          {/* FAQ Section */}
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <Book className="w-5 h-5 text-cyan-600" />
            अक्सर पूछे जाने वाले प्रश्न / FAQ
          </h3>

          <div className="space-y-3 mb-6">
            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Phone className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं अपना मोबाइल नंबर कैसे बदलूं?</p>
                    <p className="text-xs text-gray-600">How do I change my mobile number?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Shield className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मेरा डेटा कितना सुरक्षित है?</p>
                    <p className="text-xs text-gray-600">How secure is my data?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Bell className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं दवा का रिमाइंडर कैसे सेट करूं?</p>
                    <p className="text-xs text-gray-600">How do I set medication reminders?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <MessageCircle className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं डॉक्टर से कैसे संपर्क करूं?</p>
                    <p className="text-xs text-gray-600">How do I contact a doctor?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Pill className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">दवा के अलग-अलग समय कैसे सेट करें?</p>
                    <p className="text-xs text-gray-600">How to set different medication times?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Building2 className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मेरे पास के अस्पताल कैसे खोजें?</p>
                    <p className="text-xs text-gray-600">How to find nearby hospitals?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <BookOpen className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">स्वास्थ्य लेख कैसे पढ़ें?</p>
                    <p className="text-xs text-gray-600">How to read health articles?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Gift className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">सरकारी योजना की पात्रता कैसे जांचें?</p>
                    <p className="text-xs text-gray-600">How to check scheme eligibility?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <ClipboardCheck className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">डॉक्टर विजिट की तैयारी कैसे करें?</p>
                    <p className="text-xs text-gray-600">How to prepare for doctor visit?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <AlertTriangle className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">आपातकालीन नंबर कैसे एक्सेस करें?</p>
                    <p className="text-xs text-gray-600">How to access emergency numbers?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button 
              onClick={() => setCurrentView('faq-detail')}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Globe className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">भाषा कैसे बदलें?</p>
                    <p className="text-xs text-gray-600">How to change language?</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>
          </div>

          {/* Resources with Documents */}
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-600" />
            संसाधन / Resources
          </h3>

          {/* Documents */}
          <div className="space-y-3 mb-6">
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-xl p-3">
                  <Book className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य साथी उपयोगकर्ता मैनुअल</h5>
                  <p className="text-sm text-gray-600 mb-1">Health Companion User Manual</p>
                  <p className="text-xs text-gray-500 mb-2">ऐप की सभी सुविधाओं का विस्तृत मार्गदर्शन</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>2.5 MB</span>
                    <span>•</span>
                    <span>हिंदी/English</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-xl p-3">
                  <FileText className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">दवा प्रबंधन गाइड</h5>
                  <p className="text-sm text-gray-600 mb-1">Medication Management Guide</p>
                  <p className="text-xs text-gray-500 mb-2">दवा रिमाइंडर और ट्रैकिंग की पूरी जानकारी</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>1.5 MB</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-xl p-3">
                  <Info className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">सरकारी योजना आवेदन गाइड</h5>
                  <p className="text-sm text-gray-600 mb-1">Government Scheme Application Guide</p>
                  <p className="text-xs text-gray-500 mb-2">योजनाओं के लिए आवेदन करने की चरणबद्ध प्रक्रिया</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>3.2 MB</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-orange-100 rounded-xl p-3">
                  <MessageCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य AI सहायक उपयोग गाइड</h5>
                  <p className="text-sm text-gray-600 mb-1">Health AI Assistant Usage Guide</p>
                  <p className="text-xs text-gray-500 mb-2">AI चैटबॉट से प्रभावी तरीके से कैसे पूछें</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>1.0 MB</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-red-100 rounded-xl p-3">
                  <Shield className="w-5 h-5 text-red-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">गोपनीयता और सुरक्षा नीति</h5>
                  <p className="text-sm text-gray-600 mb-1">Privacy & Security Policy</p>
                  <p className="text-xs text-gray-500 mb-2">आपका डेटा कैसे सुरक्षित और एन्क्रिप्टेड है</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>1.8 MB</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="bg-indigo-100 rounded-xl p-3">
                  <FileText className="w-5 h-5 text-indigo-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">आयुष्मान भारत लाभ गाइड</h5>
                  <p className="text-sm text-gray-600 mb-1">Ayushman Bharat Benefits Guide</p>
                  <p className="text-xs text-gray-500 mb-2">आयुष्मान भारत के तहत मिलने वाले लाभों की जानकारी</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>📄 PDF</span>
                    <span>•</span>
                    <span>2.8 MB</span>
                  </div>
                </div>
                <button className="bg-cyan-100 rounded-full p-2 hover:bg-cyan-200 transition-colors">
                  <Download className="w-4 h-4 text-cyan-600" />
                </button>
              </div>
            </div>
          </div>

          {/* Video Tutorials */}
          <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <Video className="w-4 h-4" />
            वीडियो ट्यूटोरियल / Video Tutorials
          </h4>
          <div className="space-y-3 mb-6">
            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य साथी ऐप शुरू करें</h5>
                  <p className="text-sm text-gray-600 mb-1">Getting Started with Health Companion</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 6:15</span>
                    <span>•</span>
                    <span>👁️ 25,000+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">दवा रिमाइंडर और ट्रैकिंग</h5>
                  <p className="text-sm text-gray-600 mb-1">Medication Reminders & Tracking</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 4:30</span>
                    <span>•</span>
                    <span>👁️ 18,500+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">सरकारी योजनाओं के लिए आवेदन</h5>
                  <p className="text-sm text-gray-600 mb-1">Apply for Government Health Schemes</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 8:45</span>
                    <span>•</span>
                    <span>👁️ 32,000+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">�����वास्थ्य AI सहायक का उपयोग</h5>
                  <p className="text-sm text-gray-600 mb-1">Using Health AI Assistant</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 5:20</span>
                    <span>•</span>
                    <span>👁️ 15,200+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">पात्रता जांच और योजना चयन</h5>
                  <p className="text-sm text-gray-600 mb-1">Eligibility Check & Scheme Selection</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 6:50</span>
                    <span>•</span>
                    <span>👁️ 21,800+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-500 rounded-xl p-3">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">सूचनाएं और रिमाइंडर प्रबंधन</h5>
                  <p className="text-sm text-gray-600 mb-1">Notifications & Reminder Management</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>⏱️ 3:30</span>
                    <span>•</span>
                    <span>👁️ 9,400+ views</span>
                    <span>•</span>
                    <span>हिंदी</span>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>
          </div>

          {/* Quick Tips Section */}
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-cyan-600" />
            त्वरित टिप्स / Quick Tips
          </h3>
          <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-3xl p-6 mb-6 border-2 border-cyan-100">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">1</div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">दवा रिमाइंडर हमेशा चालू रखें</p>
                  <p className="text-sm text-gray-600">Keep medication reminders always on</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">2</div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">आपातकालीन नंबर 108 को याद रखें</p>
                  <p className="text-sm text-gray-600">Remember emergency number 108</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">3</div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">नियमित रूप से स्वास्थ्य लेख पढ़ें</p>
                  <p className="text-sm text-gray-600">Read health articles regularly</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">4</div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">डॉक्टर विजिट से पहले तैयारी करें</p>
                  <p className="text-sm text-gray-600">Prepare before doctor visits</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 text-sm font-bold">5</div>
                <div>
                  <p className="font-medium text-gray-900 mb-1">AI सहायक से स्वास्थ्य प्रश्न पूछें</p>
                  <p className="text-sm text-gray-600">Ask health questions to AI assistant</p>
                </div>
              </div>
            </div>
          </div>

          {/* Troubleshooting Section */}
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-cyan-600" />
            समस्या निवारण / Troubleshooting
          </h3>
          <div className="space-y-3 mb-6">
            <div className="bg-white rounded-2xl p-4 shadow-sm border-l-4 border-orange-400">
              <div className="flex items-start gap-3">
                <Bell className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-medium mb-1">रिमाइंडर नहीं आ रहे?</h5>
                  <p className="text-sm text-gray-600 mb-1">Reminders not working?</p>
                  <p className="text-xs text-gray-500">सेटिंग्स में जाकर नोटिफिकेशन परमिशन चेक करें</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm border-l-4 border-blue-400">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-medium mb-1">अस्पताल नहीं दिख रहे?</h5>
                  <p className="text-sm text-gray-600 mb-1">Hospitals not showing?</p>
                  <p className="text-xs text-gray-500">लोकेशन परमिशन को इनेबल करें</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm border-l-4 border-green-400">
              <div className="flex items-start gap-3">
                <MessageCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-medium mb-1">AI चैट काम नहीं कर रहा?</h5>
                  <p className="text-sm text-gray-600 mb-1">AI chat not responding?</p>
                  <p className="text-xs text-gray-500">इंटरनेट कनेक्शन चेक करें और ऐप रीस्टार्ट करें</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm border-l-4 border-purple-400">
              <div className="flex items-start gap-3">
                <Globe className="w-5 h-5 text-purple-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-medium mb-1">भाषा नहीं बदल रही?</h5>
                  <p className="text-sm text-gray-600 mb-1">Language not changing?</p>
                  <p className="text-xs text-gray-500">सेटिंग्स में जाएं और ऐप रीस्टार्ट करें</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-4 shadow-sm border-l-4 border-red-400">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h5 className="font-medium mb-1">लॉगिन समस्या?</h5>
                  <p className="text-sm text-gray-600 mb-1">Login issues?</p>
                  <p className="text-xs text-gray-500">मोबाइल नंबर दोबारा चेक करें या OTP फिर से भेजें</p>
                </div>
              </div>
            </div>
          </div>

          {/* App Features Overview */}
          <h3 className="font-medium mb-4 flex items-center gap-2">
            <Info className="w-5 h-5 text-cyan-600" />
            ऐप की मुख्य सुविधाएं / Main App Features
          </h3>
          <div className="bg-white rounded-3xl p-6 mb-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-cyan-100 rounded-xl p-2">
                  <MessageCircle className="w-5 h-5 text-cyan-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य प्रश्न पूछें</h5>
                  <p className="text-sm text-gray-600">AI-powered health assistant for instant answers</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-green-100 rounded-xl p-2">
                  <Pill className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">दवा रिमाइंडर</h5>
                  <p className="text-sm text-gray-600">Never miss a dose with smart reminders</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-blue-100 rounded-xl p-2">
                  <ClipboardCheck className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">डॉक्टर विजिट तैयारी</h5>
                  <p className="text-sm text-gray-600">Prepare documents and symptoms checklist</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-red-100 rounded-xl p-2">
                  <Building2 className="w-5 h-5 text-red-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">पास के अस्पताल</h5>
                  <p className="text-sm text-gray-600">Find hospitals and medical facilities nearby</p>
                </div>
              </div>

              <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                <div className="bg-purple-100 rounded-xl p-2">
                  <BookOpen className="w-5 h-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य लेख</h5>
                  <p className="text-sm text-gray-600">22 articles across 7 health topics</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-orange-100 rounded-xl p-2">
                  <Gift className="w-5 h-5 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">सरकारी योजनाएं</h5>
                  <p className="text-sm text-gray-600">Access health benefits and government schemes</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
            <ExternalLink className="w-4 h-4" />
            त्वरित लिंक / Quick Links
          </h4>
          <div className="space-y-3 mb-6">
            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">आयुष्मान भारत - प्रधानमंत्री जन आरोग्य योजना</h5>
                  <p className="text-sm text-gray-600 mb-1">Ayushman Bharat - PM-JAY</p>
                  <p className="text-xs text-cyan-600">pmjay.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-green-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">स्वास्थ्य और परिवार कल्याण मंत्रालय</h5>
                  <p className="text-sm text-gray-600 mb-1">Ministry of Health & Family Welfare</p>
                  <p className="text-xs text-cyan-600">mohfw.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-purple-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">राष्ट्रीय स्वास्थ्य पोर्टल</h5>
                  <p className="text-sm text-gray-600 mb-1">National Health Portal</p>
                  <p className="text-xs text-cyan-600">nhp.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-orange-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">eSanjeevani - ऑनलाइन OPD</h5>
                  <p className="text-sm text-gray-600 mb-1">eSanjeevani - Online OPD</p>
                  <p className="text-xs text-cyan-600">esanjeevani.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-red-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-red-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">आरोग्य सेतु</h5>
                  <p className="text-sm text-gray-600 mb-1">Aarogya Setu</p>
                  <p className="text-xs text-cyan-600">aarogyasetu.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-indigo-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-indigo-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">CoWIN - टीकाकरण</h5>
                  <p className="text-sm text-gray-600 mb-1">CoWIN - Vaccination</p>
                  <p className="text-xs text-cyan-600">cowin.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="flex items-center gap-3">
                <div className="bg-teal-100 rounded-xl p-3">
                  <ExternalLink className="w-4 h-4 text-teal-600" />
                </div>
                <div className="flex-1">
                  <h5 className="font-medium mb-1">ABDM - आयुष्मान भारत डिजिटल मिशन</h5>
                  <p className="text-sm text-gray-600 mb-1">Ayushman Bharat Digital Mission</p>
                  <p className="text-xs text-cyan-600">abdm.gov.in</p>
                </div>
                <ExternalLink className="w-4 h-4 text-gray-400" />
              </div>
            </button>
          </div>

          {/* Resource Info */}
          <div className="bg-cyan-50 border-2 border-cyan-400 rounded-2xl p-5 mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-5 h-5 text-cyan-600" />
              <h3 className="font-medium">संसाधन जानकारी / Resource Info</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>सभी दस्तावेज मुफ्त डाउनलोड के लिए उपलब्ध हैं</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>All documents are available for free download</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>वीडियो ट्यूटोरियल हिंदी और अंग्रेजी में उपलब्ध हैं</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600">•</span>
                <span>Video tutorials available in Hindi and English</span>
              </li>
            </ul>
          </div>

          {/* Contact Us Button */}
          <button
            onClick={() => setCurrentView('contact-us')}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white py-4 rounded-2xl hover:from-cyan-600 hover:to-blue-700 transition-colors flex items-center justify-center gap-2 mb-4"
          >
            <MessageCircle className="w-5 h-5" />
            <span>हमसे संपर्क करें / Contact Us</span>
          </button>

          {/* Emergency Help */}
          <div className="bg-red-50 border-2 border-red-400 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <h3 className="font-medium text-red-900">आपातकालीन सहायता / Emergency Help</h3>
            </div>
            <p className="text-sm text-red-800 mb-3">
              आपातकालीन स्थिति में, तुरंत 108 पर कॉल करें
            </p>
            <p className="text-sm text-red-700 mb-4">
              In case of emergency, immediately call 108
            </p>
            <button className="w-full bg-red-600 text-white py-3 rounded-xl hover:bg-red-700 transition-colors flex items-center justify-center gap-2 mb-3">
              <Phone className="w-5 h-5" />
              <span>108 पर कॉल करें / Call 108</span>
            </button>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-red-100 rounded-xl p-3 text-center">
                <p className="text-xs text-red-700 mb-1">राष्ट्रीय आपातकाल</p>
                <p className="font-medium text-red-900">112</p>
              </div>
              <div className="bg-red-100 rounded-xl p-3 text-center">
                <p className="text-xs text-red-700 mb-1">महिला हेल्पलाइन</p>
                <p className="font-medium text-red-900">1091</p>
              </div>
            </div>
          </div>

          {/* App Version & Info */}
          <div className="bg-gray-100 rounded-2xl p-5 text-center mt-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Info className="w-4 h-4 text-gray-600" />
              <p className="text-sm font-medium text-gray-700">स्वास्थ्य साथी / Health Companion</p>
            </div>
            <p className="text-xs text-gray-600 mb-1">संस्करण / Version: 1.2.0</p>
            <p className="text-xs text-gray-500">भारत सरकार द्वारा संचालित / Powered by Govt. of India</p>
          </div>
        </div>
      </div>
    );
  }

  // Contact Us View
  if (currentView === 'contact-us') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('help')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">हमसे संपर्क करें</h1>
          <p className="text-sm text-cyan-100">Contact Us</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6 pb-24">
          {/* Contact Us Section */}
          <div className="space-y-3 mb-6">
            {/* Phone Number */}
            <div className="bg-white rounded-2xl p-5 flex items-start gap-4 shadow-sm">
              <div className="bg-green-100 rounded-2xl p-3 flex-shrink-0">
                <Phone className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium mb-1 text-gray-800">फोन नंबर / Phone Number</h4>
                <p className="text-cyan-600 font-medium mb-1">1800-XXX-XXXX</p>
                <p className="text-sm text-gray-600">टोल फ्री / Toll Free</p>
              </div>
            </div>

            {/* Email */}
            <div className="bg-white rounded-2xl p-5 flex items-start gap-4 shadow-sm">
              <div className="bg-blue-100 rounded-2xl p-3 flex-shrink-0">
                <Mail className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium mb-1 text-gray-800">ईमेल / Email</h4>
                <p className="text-cyan-600 font-medium mb-1">support@healthapp.in</p>
                <p className="text-sm text-gray-600">24 घंटे के भीतर जवाब / Reply within 24 hours</p>
              </div>
            </div>

            {/* Address */}
            <div className="bg-white rounded-2xl p-5 flex items-start gap-4 shadow-sm">
              <div className="bg-purple-100 rounded-2xl p-3 flex-shrink-0">
                <MapPin className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium mb-1 text-gray-800">पता / Address</h4>
                <p className="text-cyan-600 font-medium mb-1">Health Department, Government of India</p>
                <p className="text-sm text-gray-600">New Delhi - 110001</p>
              </div>
            </div>

            {/* Working Hours */}
            <div className="bg-white rounded-2xl p-5 flex items-start gap-4 shadow-sm">
              <div className="bg-orange-100 rounded-2xl p-3 flex-shrink-0">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium mb-1 text-gray-800">कार्य समय / Working Hours</h4>
                <p className="text-cyan-600 font-medium mb-1">सोमवार - शुक्रवार / Mon - Fri</p>
                <p className="text-sm text-gray-600">9:00 AM - 6:00 PM IST</p>
              </div>
            </div>
          </div>

          {/* Start Live Chat Button */}
          <button className="w-full bg-gradient-to-r from-purple-600 to-purple-500 text-white rounded-2xl p-4 flex items-center justify-center gap-2 mb-6 shadow-md hover:shadow-lg transition-shadow">
            <MessageCircle className="w-5 h-5" />
            <span className="font-medium">लाइव चैट शुरू करें / Start Live Chat</span>
          </button>

          {/* Send Message Form */}
          <div className="mb-6">
            <h3 className="font-medium mb-4 text-gray-800">संदेश भेजें / Send Message</h3>
            
            <div className="space-y-4">
              {/* Name Input */}
              <div>
                <label className="flex items-center gap-2 mb-2 text-sm text-gray-700">
                  <User className="w-4 h-4 text-cyan-600" />
                  <span>नाम / Name</span>
                </label>
                <input
                  type="text"
                  placeholder="आपका नाम / Your name"
                  className="w-full px-4 py-3 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Email Input */}
              <div>
                <label className="flex items-center gap-2 mb-2 text-sm text-gray-700">
                  <Mail className="w-4 h-4 text-cyan-600" />
                  <span>ईमेल / Email</span>
                </label>
                <input
                  type="email"
                  placeholder="आपका ईमेल / Your email"
                  className="w-full px-4 py-3 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Message Input */}
              <div>
                <label className="flex items-center gap-2 mb-2 text-sm text-gray-700">
                  <MessageCircle className="w-4 h-4 text-cyan-600" />
                  <span>संदेश / Message</span>
                </label>
                <textarea
                  placeholder="अपना संदेश लिखें / Write your message"
                  rows={5}
                  className="w-full px-4 py-3 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                />
              </div>

              {/* Send Button */}
              <button className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-xl p-3 flex items-center justify-center gap-2 font-medium shadow-md hover:shadow-lg transition-shadow">
                <Send className="w-5 h-5" />
                <span>भेजें / Send</span>
              </button>
            </div>
          </div>

          {/* Response Time Information */}
          <div className="bg-cyan-50 border border-cyan-200 rounded-2xl p-4 mb-6">
            <div className="flex items-start gap-2 mb-3">
              <Clock className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
              <h4 className="font-medium text-gray-800">प्रतिक्रिया समय / Response Time</h4>
            </div>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-cyan-600 flex-shrink-0">•</span>
                <span>फोन: तुरंत (कार्य घंटों के दौरान) / Phone: Immediate (during working hours)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600 flex-shrink-0">•</span>
                <span>ईमेल: 24 घंटे के भीतर / Email: Within 24 hours</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-cyan-600 flex-shrink-0">•</span>
                <span>लाइव चैट: तुरंत / Live Chat: Immediate</span>
              </li>
            </ul>
          </div>

          {/* FAQ Section */}
          <div className="flex items-center gap-2 mb-4">
            <Book className="w-5 h-5 text-cyan-600" />
            <h3 className="font-medium text-gray-800">अक्सर पूछे जाने वाले प्रश्न / FAQ</h3>
          </div>

          <div className="space-y-3 mb-6">
            {/* FAQ 1 - Change Mobile Number */}
            <button 
              onClick={() => setExpandedFaq(expandedFaq === 11 ? null : 11)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Phone className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं अपना मोबाइल नंबर कैसे बदलूं?</p>
                    <p className="text-xs text-gray-600 mb-2">How do I change my mobile number?</p>
                    {expandedFaq === 11 && (
                      <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-700">
                        <p className="mb-2 font-medium text-cyan-600">चरण-दर-चरण प्रक्रिया:</p>
                        <p className="mb-2">1. प्रोफाइल &gt; सेटिंग्स &gt; "मोबाइल नंबर बदलें" पर जाएं</p>
                        <p className="mb-2">2. नया 10 अंकों का मोबाइल नंबर दर्ज करें</p>
                        <p className="mb-2">3. "OTP भेजें" बटन पर क्लिक करें</p>
                        <p className="mb-2">4. नए नंबर पर प्राप्त 6 अंकों का OTP दर्ज करें</p>
                        <p className="mb-2">5. "सत्यापित करें" पर क्लिक करें</p>
                        <p className="text-orange-600 mt-2">नोट: सुनिश्चित करें कि नया नंबर आपके पास है और सक्रिय है।</p>
                      </div>
                    )}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedFaq === 11 ? 'rotate-90' : ''}`} />
              </div>
            </button>

            {/* FAQ 2 - Data Security */}
            <button 
              onClick={() => setExpandedFaq(expandedFaq === 12 ? null : 12)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Shield className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मेरा डेटा कितना सुरक्षित है?</p>
                    <p className="text-xs text-gray-600 mb-2">How secure is my data?</p>
                    {expandedFaq === 12 && (
                      <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-700">
                        <p className="mb-2 font-medium text-cyan-600">आपका डेटा पूरी तरह सुरक्षित है:</p>
                        <p className="mb-2">✓ 256-बिट AES एन्क्रिप्शन का उपयोग</p>
                        <p className="mb-2">✓ सभी संवेदनशील जानकारी एन्क्रिप्टेड है</p>
                        <p className="mb-2">✓ आधार नंबर कभी स्टोर नहीं किया जाता</p>
                        <p className="mb-2">✓ सरकारी सुरक्षित सर्वर पर डेटा संग्रहण</p>
                        <p className="mb-2">✓ कोई तीसरे पक्ष के साथ साझा नहीं</p>
                        <p className="mb-2">✓ HIPAA और GDPR मानकों का अनुपालन</p>
                        <p className="mb-2">✓ नियमित सुरक्षा ऑडिट और अपडेट</p>
                      </div>
                    )}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedFaq === 12 ? 'rotate-90' : ''}`} />
              </div>
            </button>

            {/* FAQ 3 - Set Medication Reminders */}
            <button 
              onClick={() => setExpandedFaq(expandedFaq === 13 ? null : 13)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <Bell className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं दवा का रिमाइंडर कैसे सेट करूं?</p>
                    <p className="text-xs text-gray-600 mb-2">How do I set medication reminders?</p>
                    {expandedFaq === 13 && (
                      <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-700">
                        <p className="mb-2 font-medium text-cyan-600">रिमाइंडर सेट करने के लिए:</p>
                        <p className="mb-2">1. डैशबोर्ड पर "दवा अनुस्मारक" बटन पर टैप करें</p>
                        <p className="mb-2">2. "+ नया रिमाइंडर जोड़ें" पर क्लिक करें</p>
                        <p className="mb-2">3. दवा का नाम दर्ज करें (उदा. "एस्पिरिन 100mg")</p>
                        <p className="mb-2">4. खुराक का प्रकार चुनें (गोली, सिरप, इंजेक्शन आदि)</p>
                        <p className="mb-2">5. समय निर्धारित करें (सुबह 8:00, दोपहर 2:00 आदि)</p>
                        <p className="mb-2">6. आवृत्ति चुनें (दैनिक, साप्ताहिक, मासिक)</p>
                        <p className="mb-2">7. यदि आवश्यक हो तो देखभालकर्ता जोड़ें</p>
                        <p className="mb-2">8. "सहेजें" पर क्लिक करें</p>
                        <p className="text-green-600 mt-2">✓ रिमाइंडर समय पर पुश नोटिफिकेशन भेजेगा</p>
                      </div>
                    )}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedFaq === 13 ? 'rotate-90' : ''}`} />
              </div>
            </button>

            {/* FAQ 4 - Contact Doctor */}
            <button 
              onClick={() => setExpandedFaq(expandedFaq === 14 ? null : 14)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <MessageCircle className="w-4 h-4 text-cyan-600 mt-1" />
                  <div>
                    <p className="font-medium text-sm mb-1">मैं डॉक्टर से कैसे संपर्क करूं?</p>
                    <p className="text-xs text-gray-600 mb-2">How do I contact a doctor?</p>
                    {expandedFaq === 14 && (
                      <div className="mt-3 pt-3 border-t border-gray-100 text-xs text-gray-700">
                        <p className="mb-2 font-medium text-cyan-600">डॉक्टर से संपर्क के विकल्प:</p>
                        <p className="mb-3 font-medium">1. स्वास्थ्य AI सहायक:</p>
                        <p className="mb-2 ml-3">• डैशबोर्ड पर "स्वास्थ्य प्रश्न पूछें" टैप करें</p>
                        <p className="mb-2 ml-3">• अपने लक्षण या प्रश्न टाइप करें</p>
                        <p className="mb-2 ml-3">• तुरंत AI-आधारित सुझाव प्राप्त करें</p>
                        <p className="mb-3 font-medium">2. eSanjeevani Online OPD:</p>
                        <p className="mb-2 ml-3">• हेल्प सेक्शन में "Quick Links" पर जाएं</p>
                        <p className="mb-2 ml-3">• "eSanjeevani" लिंक पर क्लिक करें</p>
                        <p className="mb-2 ml-3">• मुफ्त ऑनलाइन डॉक्टर परामर्श प्राप्त करें</p>
                        <p className="mb-3 font-medium">3. आपातकालीन स्थिति में:</p>
                        <p className="mb-2 ml-3">• तुरंत 108 पर कॉल करें</p>
                        <p className="text-orange-600 mt-2">नोट: गंभीर मामलों में तुरंत अस्पताल जाएं।</p>
                      </div>
                    )}
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 text-gray-400 transition-transform ${expandedFaq === 14 ? 'rotate-90' : ''}`} />
              </div>
            </button>
          </div>

          {/* Resources Section */}
          <div className="mb-6">
            <button
              onClick={() => setExpandedFaq(expandedFaq === 40 ? null : 40)}
              className="w-full bg-white rounded-2xl p-5 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="bg-cyan-100 rounded-full p-3">
                  <Book className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">संसाधन / Resources</h3>
                  <p className="text-xs text-gray-600">उपयोगी गाइड और दस्तावेज़</p>
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${expandedFaq === 40 ? 'rotate-90' : ''}`} />
            </button>

            {expandedFaq === 40 && (
              <div className="mt-3 bg-white rounded-2xl p-4 shadow-sm space-y-3">
                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">ऐप का उपयोग कैसे करें</p>
                    <p className="text-xs text-gray-600 mb-2">How to Use the App</p>
                    <p className="text-xs text-gray-500">स्वास्थ्य साथी ऐप की सभी सुविधाओं के बारे में विस्तृत जानकारी।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">दवा अनुस्मारक गाइड</p>
                    <p className="text-xs text-gray-600 mb-2">Medication Reminder Guide</p>
                    <p className="text-xs text-gray-500">दवा रिमाइंडर सेट करने और प्रबंधित करने का पूर्ण गाइड।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">सरकारी योजना आवेदन गाइड</p>
                    <p className="text-xs text-gray-600 mb-2">Government Scheme Application Guide</p>
                    <p className="text-xs text-gray-500">सरकारी योजनाओं के लिए आवेदन कैसे करें।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">डेटा गोपनीयता और सुरक्षा</p>
                    <p className="text-xs text-gray-600 mb-2">Data Privacy & Security</p>
                    <p className="text-xs text-gray-500">आपके डेटा की सुरक्षा के बारे में जानकारी।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">AI स्वास्थ्य सहायक उपयोग</p>
                    <p className="text-xs text-gray-600 mb-2">Using AI Health Assistant</p>
                    <p className="text-xs text-gray-500">AI चैटबॉट से स्वास्थ्य प्रश्न कैसे पूछें।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3">
                  <FileText className="w-5 h-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">प्रोफाइल और सेटिंग्स प्रबंधन</p>
                    <p className="text-xs text-gray-600 mb-2">Profile & Settings Management</p>
                    <p className="text-xs text-gray-500">अपनी प्रोफाइल और सेटिंग्स को कैसे प्रबंधित करें।</p>
                  </div>
                  <Download className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>
              </div>
            )}
          </div>

          {/* Video Tutorials Section */}
          <div className="mb-6">
            <button
              onClick={() => setExpandedFaq(expandedFaq === 41 ? null : 41)}
              className="w-full bg-white rounded-2xl p-5 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="bg-purple-100 rounded-full p-3">
                  <Video className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">वीडियो ट्यूटोरियल / Video Tutorials</h3>
                  <p className="text-xs text-gray-600">चरण-दर-चरण वीडियो गाइड</p>
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${expandedFaq === 41 ? 'rotate-90' : ''}`} />
            </button>

            {expandedFaq === 41 && (
              <div className="mt-3 bg-white rounded-2xl p-4 shadow-sm space-y-3">
                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">ऐप शुरू करना / Getting Started</p>
                    <p className="text-xs text-gray-500 mb-2">3:45 मिनट</p>
                    <p className="text-xs text-gray-600">ऐप को सेटअप करना और पहली बार उपयोग करना।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">दवा रिमाइंडर सेट करना</p>
                    <p className="text-xs text-gray-500 mb-2">2:30 मिनट</p>
                    <p className="text-xs text-gray-600">दवा अनुस्मारक बनाने का पूरा प्रदर्शन।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">AI स्वास्थ्य सहायक का उपयोग</p>
                    <p className="text-xs text-gray-500 mb-2">4:15 मिनट</p>
                    <p className="text-xs text-gray-600">स्वास्थ्य प्रश्न पूछना और सुझाव प्राप्त करना।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">सरकारी योजनाओं के लिए आवेदन</p>
                    <p className="text-xs text-gray-500 mb-2">5:00 मिनट</p>
                    <p className="text-xs text-gray-600">योजना पात्रता जांच और आवेदन प्रक्रिया।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3 pb-3 border-b border-gray-100">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">प्रोफाइल अपडेट करना</p>
                    <p className="text-xs text-gray-500 mb-2">2:00 मिनट</p>
                    <p className="text-xs text-gray-600">व्यक्तिगत जानकारी संपादित और सहेजना।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>

                <div className="flex items-start gap-3">
                  <div className="bg-red-100 rounded-lg p-2 flex-shrink-0">
                    <Video className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">सुरक्षा और गोपनीयता सेटिंग्स</p>
                    <p className="text-xs text-gray-500 mb-2">3:20 मिनट</p>
                    <p className="text-xs text-gray-600">अपने डेटा को सुरक्षित रखने के टिप्स।</p>
                  </div>
                  <ExternalLink className="w-4 h-4 text-cyan-600 flex-shrink-0" />
                </div>
              </div>
            )}
          </div>

          {/* Quick Links Section */}
          <div className="mb-6">
            <button
              onClick={() => setExpandedFaq(expandedFaq === 42 ? null : 42)}
              className="w-full bg-white rounded-2xl p-5 flex items-center justify-between shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-3">
                <div className="bg-blue-100 rounded-full p-3">
                  <ExternalLink className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-800 mb-1">त्वरित लिंक / Quick Links</h3>
                  <p className="text-xs text-gray-600">उपयोगी स्वास्थ्य वेबसाइट</p>
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${expandedFaq === 42 ? 'rotate-90' : ''}`} />
            </button>

            {expandedFaq === 42 && (
              <div className="mt-3 bg-white rounded-2xl p-4 shadow-sm space-y-3">
                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">Ayushman Bharat</p>
                    <p className="text-xs text-gray-600">राष्ट्रीय स्वास्थ्य सुरक्षा योजना</p>
                    <p className="text-xs text-cyan-600 mt-1">pmjay.gov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">eSanjeevani</p>
                    <p className="text-xs text-gray-600">टेली-परामर्श सेवा</p>
                    <p className="text-xs text-cyan-600 mt-1">esanjeevani.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">CoWIN Portal</p>
                    <p className="text-xs text-gray-600">टीकाकरण पंजीकरण</p>
                    <p className="text-xs text-cyan-600 mt-1">cowin.gov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">National Health Portal</p>
                    <p className="text-xs text-gray-600">स्वास्थ्य जानकारी और संसाधन</p>
                    <p className="text-xs text-cyan-600 mt-1">nhp.gov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">Jan Aushadhi Kendra</p>
                    <p className="text-xs text-gray-600">सस्ती दवाएं खोजें</p>
                    <p className="text-xs text-cyan-600 mt-1">janaushadhi.gov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 pb-3 border-b border-gray-100 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">ABDM - Health Records</p>
                    <p className="text-xs text-gray-600">डिजिटल स्वास्थ्य रिकॉर्ड</p>
                    <p className="text-xs text-cyan-600 mt-1">abdm.gov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>

                <button className="w-full flex items-start gap-3 hover:bg-cyan-50 -mx-4 px-4 transition-colors">
                  <div className="bg-green-100 rounded-lg p-2 flex-shrink-0">
                    <ExternalLink className="w-4 h-4 text-green-600" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-sm mb-1">Swachh Bharat Mission</p>
                    <p className="text-xs text-gray-600">स्वास्थ्य और स्वच्छता</p>
                    <p className="text-xs text-cyan-600 mt-1">swachhbharat.mygov.in</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Resources View
  if (currentView === 'resources') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('settings')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">संसाधन</h1>
          <p className="text-sm text-cyan-100">Resources</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6 pb-24">
          {/* Hero Section */}
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl p-6 mb-6 text-white">
            <div className="flex items-center gap-3">
              <HelpCircle className="w-12 h-12" />
              <div>
                <h2 className="text-xl mb-1">हम यहाँ मदद के लिए हैं</h2>
                <p className="text-sm text-cyan-100">We're here to help you</p>
              </div>
            </div>
          </div>

          {/* Resources List */}
          <div className="space-y-3 mb-6">
            <button className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium mb-1">उपयोगकर्ता गाइड / User Guide</p>
                  <p className="text-sm text-gray-600">ऐप का उपयोग कैसे करें</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium mb-1">गोपनीयता नीति / Privacy Policy</p>
                  <p className="text-sm text-gray-600">आपका डेटा कैसे सुरक्षित है</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>

            <button className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium mb-1">नियम और शर्तें / Terms & Conditions</p>
                  <p className="text-sm text-gray-600">सेवा की शर्तें</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </div>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // FAQ Detail View
  if (currentView === 'faq-detail') {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-4 text-white">
          <button onClick={() => setCurrentView('help')} className="flex items-center gap-2 mb-4">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl mb-1">अक्सर पूछे जाने वाले प्रश्न</h1>
          <p className="text-sm text-cyan-100">Frequently Asked Questions (FAQ)</p>
        </header>

        {/* Main Content */}
        <div className="px-4 py-6 pb-24">
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <input
                type="text"
                placeholder="प्रश्न खोजें / Search questions..."
                className="w-full px-4 py-3 pl-10 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors"
              />
              <Search className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* Account Section */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-purple-100 rounded-full p-2">
                <User className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="font-medium text-gray-800">खाता / Account</h3>
            </div>

            <div className="space-y-3">
              {/* Change Mobile Number */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 21 ? null : 21)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं अपना मोबाइल नंबर कैसे बदलूं?</p>
                    <p className="text-xs text-gray-600">How do I change my mobile number?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 21 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 21 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">सेटिंग &gt; मोबाइल नंबर बदलें में जाएं। नया नंबर दर्ज करें और OTP से सत्यापित करें।</p>
                    <p className="text-sm text-gray-700">Go to Settings &gt; Change Mobile Number. Enter the new number and verify with OTP.</p>
                  </div>
                )}
              </button>

              {/* Update Profile */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 22 ? null : 22)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं अपनी प्रोफाइल कैसे अपडेट करूं?</p>
                    <p className="text-xs text-gray-600">How do I update my profile?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 22 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 22 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">डैशबोर्ड से प्रोफाइल पर क्लिक करें। अपनी जानकारी संपादित करें और सहेजें बटन दबाएं।</p>
                    <p className="text-sm text-gray-700">Click Profile from Dashboard. Edit your information and press Save button.</p>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Security Section */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-green-100 rounded-full p-2">
                <Shield className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-medium text-gray-800">सुरक्षा / Security</h3>
            </div>

            <div className="space-y-3">
              {/* Data Security */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 23 ? null : 23)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मेरा डेटा कितना सुरक्षित है?</p>
                    <p className="text-xs text-gray-600">How secure is my data?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 23 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 23 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">आपका सभी डेटा एन्क्रिप्टेड है और सुरक्षित सर्वर पर संग्रहित है। हम आपका आधार नंबर संग्रहित नहीं करते हैं।</p>
                    <p className="text-sm text-gray-700">All your data is encrypted and stored on secure servers. We do not store your Aadhaar number.</p>
                  </div>
                )}
              </button>

              {/* Who Can See Health Info */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 24 ? null : 24)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मेरी स्वास्थ्य जानकारी कौन देख सकता है?</p>
                    <p className="text-xs text-gray-600">Who can see my health information?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 24 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 24 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">केवल आप और आपके द्वारा अधिकृत स्वास्थ्य सेवा प्रदाता ही आपकी स्वास्थ्य जानकारी देख सकते हैं।</p>
                    <p className="text-sm text-gray-700">Only you and healthcare providers authorized by you can see your health information.</p>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Features Section */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-blue-100 rounded-full p-2">
                <MessageCircle className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="font-medium text-gray-800">सुविधाएं / Features</h3>
            </div>

            <div className="space-y-3">
              {/* Medication Reminders */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 25 ? null : 25)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं दवा का रिमाइंडर कैसे सेट करूं?</p>
                    <p className="text-xs text-gray-600">How do I set medication reminders?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 25 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 25 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">डैशबोर्ड से "दवा अनुस्मारक" पर क्लिक करें। दवा का नाम, समय और आवृत्ति दर्ज करें।</p>
                    <p className="text-sm text-gray-700">Click "Medication Reminders" from Dashboard. Enter medicine name, time and frequency.</p>
                  </div>
                )}
              </button>

              {/* Contact Doctor */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 26 ? null : 26)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं डॉक्टर से कैसे संपर्क करूं?</p>
                    <p className="text-xs text-gray-600">How do I contact a doctor?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 26 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 26 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">"स्वास्थ्य प्रश्न पूछें" सुविधा का उपयोग करें या अपॉइंटमेंट बुक करें।</p>
                    <p className="text-sm text-gray-700">Use the "Ask Health Question" feature or book an appointment.</p>
                  </div>
                )}
              </button>

              {/* Government Schemes */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 27 ? null : 27)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">सरकारी योजनाओं के बारे में कैसे जानें?</p>
                    <p className="text-xs text-gray-600">How to learn about government schemes?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 27 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 27 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">डैशबोर्ड पर "सरकारी योजनाएं" बटन पर क्लिक करें। सभी उपलब्ध योजनाओं की जानकारी मिलेगी।</p>
                    <p className="text-sm text-gray-700">Click "Government Schemes" button on Dashboard. Information on all available schemes will be available.</p>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Notifications Section */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-orange-100 rounded-full p-2">
                <Bell className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="font-medium text-gray-800">सूचनाएं / Notifications</h3>
            </div>

            <div className="space-y-3">
              {/* Turn Off Notifications */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 28 ? null : 28)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं सूचनाएं कैसे बंद करूं?</p>
                    <p className="text-xs text-gray-600">How do I turn off notifications?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 28 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 28 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">सेटिंग &gt; सूचनाएं में जाएं और अपनी पसंद के अनुसार सूचनाओं को टॉगल करें।</p>
                    <p className="text-sm text-gray-700">Go to Settings &gt; Notifications and toggle notifications as per your preference.</p>
                  </div>
                )}
              </button>

              {/* Not Receiving Notifications */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 29 ? null : 29)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मुझे सूचनाएं क्यों नहीं मिल रही हैं?</p>
                    <p className="text-xs text-gray-600">Why am I not receiving notifications?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 29 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 29 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">अपने फोन की सेटिंग में ऐप के लिए सूचनाएं सक्षम करें। ऐप सेटिंग में भी जांचें।</p>
                    <p className="text-sm text-gray-700">Enable notifications for the app in your phone's settings. Also check in app settings.</p>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Technical Section */}
          <div className="mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-red-100 rounded-full p-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <h3 className="font-medium text-gray-800">तकनीकी / Technical</h3>
            </div>

            <div className="space-y-3">
              {/* App Not Loading */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 30 ? null : 30)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">ऐप लोड नहीं हो रहा है, क्या करूं?</p>
                    <p className="text-xs text-gray-600">App is not loading, what should I do?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 30 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 30 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">अपना इंटरनेट कनेक्शन जांचें। ऐप को बंद करके फिर से खोलें। यदि समस्या बनी रहे, तो हमसे संपर्क करें।</p>
                    <p className="text-sm text-gray-700">Check your internet connection. Close and reopen the app. If problem persists, contact us.</p>
                  </div>
                )}
              </button>

              {/* Update App */}
              <button 
                onClick={() => setExpandedFaq(expandedFaq === 31 ? null : 31)}
                className="w-full bg-white rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">मैं ऐप को कैसे अपडेट करूं?</p>
                    <p className="text-xs text-gray-600">How do I update the app?</p>
                  </div>
                  <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform flex-shrink-0 ml-2 ${expandedFaq === 31 ? 'rotate-90' : ''}`} />
                </div>
                {expandedFaq === 31 && (
                  <div className="mt-3 pt-3 border-t border-gray-100 bg-cyan-50 -mx-4 -mb-4 px-4 py-3 rounded-b-2xl">
                    <p className="text-sm text-gray-700 mb-2">Play Store या App Store पर जाएं और "स्वास्थ्य साथी" खोजें। अपडेट बटन पर क्लिक करें।</p>
                    <p className="text-sm text-gray-700">Go to Play Store or App Store and search for "Swasthya Saathi". Click update button.</p>
                  </div>
                )}
              </button>
            </div>
          </div>

          {/* Still Need Help Section */}
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl p-6 text-white">
            <h3 className="text-lg mb-2">अभी भी मदद चाहिए?</h3>
            <p className="text-sm text-cyan-100 mb-4">Still need help?</p>
            <button 
              onClick={() => setCurrentView('contact-us')}
              className="bg-white text-cyan-600 px-6 py-3 rounded-xl font-medium shadow-md hover:shadow-lg transition-shadow"
            >
              हमसे संपर्क करें / Contact Us
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}