import { Heart, Smartphone } from 'lucide-react';
import { useState } from 'react';

interface LoginScreenProps {
  onContinue: (mobile: string) => void;
}

export function LoginScreen({ onContinue }: LoginScreenProps) {
  const [mobile, setMobile] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobile.length === 10) {
      onContinue(mobile);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-md">
        {/* Logo and title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-cyan-500 rounded-full mb-6">
            <Heart className="w-12 h-12 text-white fill-white" />
          </div>
          <h1 className="text-3xl mb-2">स्वास्थ्य सहायक</h1>
          <p className="text-cyan-600 mb-1">आपका विश्वसनीय स्वास्थ्य सलाहकार</p>
          <p className="text-cyan-600">Your Trusted Health Companion</p>
        </div>

        {/* Login form */}
        <div className="bg-white rounded-3xl shadow-lg p-8 mb-6">
          <h2 className="text-2xl mb-6">लॉगिन करें</h2>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label className="block mb-3">
                <span className="text-cyan-600 text-sm">मोबाइल नंबर दर्ज करें / Enter mobile number</span>
              </label>
              
              <div className="mb-3 flex items-center gap-2 text-gray-700">
                <Smartphone className="w-4 h-4" />
                <span className="text-sm">मोबाइल नंबर / Mobile Number</span>
              </div>

              <input
                type="tel"
                placeholder="10 अंकों का नंबर / 10-digit number"
                className="w-full px-4 py-4 bg-cyan-50 border-2 border-cyan-200 rounded-xl focus:outline-none focus:border-cyan-400 transition-colors"
                maxLength={10}
                value={mobile}
                onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
              />
            </div>

            <button
              type="submit"
              className={`w-full py-4 rounded-xl transition-colors mb-4 font-medium ${
                mobile.length === 10
                  ? 'bg-cyan-500 hover:bg-cyan-600 text-white cursor-pointer'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
              disabled={mobile.length !== 10}
            >
              आगे बढ़ें / Continue
            </button>

            <p className="text-center text-sm text-cyan-600">
              आगे बढ़कर, आप हमारी सेवा की शर्तों और गोपनीयता नीति से सहमत हैं
            </p>
          </form>
        </div>

        {/* Security badges */}
        <div className="flex justify-center gap-6 text-sm">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-gray-700">सुरक्षित / Secure</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-gray-700">निजी / Private</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-gray-700">विश्वसनीय / Trusted</span>
          </div>
        </div>
      </div>
    </div>
  );
}