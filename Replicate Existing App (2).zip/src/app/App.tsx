import { useState, useEffect } from 'react';
import { SplashScreen } from '@/app/components/SplashScreen';
import { LoginScreen } from '@/app/components/LoginScreen';
import { ConsentScreen } from '@/app/components/ConsentScreen';
import { OTPScreen } from '@/app/components/OTPScreen';
import { LanguageScreen } from '@/app/components/LanguageScreen';
import { ProfileSetupScreen } from '@/app/components/ProfileSetupScreen';
import { DashboardScreen } from '@/app/components/DashboardScreen';
import { HealthAssistantScreen } from '@/app/components/HealthAssistantScreen';
import { NotificationsScreen } from '@/app/components/NotificationsScreen';
import { MedicationReminderScreen } from '@/app/components/MedicationReminderScreen';
import { GovernmentSchemesScreen } from '@/app/components/GovernmentSchemesScreen';
import { ProfileScreen } from '@/app/components/ProfileScreen';
import { MedicalMapsScreen } from '@/app/components/MedicalMapsScreen';
import { HealthInformationScreen } from '@/app/components/HealthInformationScreen';
import { SettingsScreen } from '@/app/components/SettingsScreen';
import { PreVisitPreparationScreen } from '@/app/components/PreVisitPreparationScreen';
import { HelpSupportScreen } from '@/app/components/HelpSupportScreen';

type Step = 'splash' | 'login' | 'consent' | 'otp' | 'language' | 'profile' | 'dashboard' | 'health-assistant' | 'notifications' | 'medication-reminder' | 'government-schemes' | 'profile-settings' | 'medical-maps' | 'health-information' | 'settings' | 'pre-visit' | 'help-support';

function App() {
  const [currentStep, setCurrentStep] = useState<Step>('splash');
  const [userMobile, setUserMobile] = useState('');
  const [userName, setUserName] = useState('');
  const [userLanguage, setUserLanguage] = useState('');
  const [userAgeRange, setUserAgeRange] = useState('');

  // Auto-advance from splash screen after 3 seconds
  useEffect(() => {
    if (currentStep === 'splash') {
      const timer = setTimeout(() => {
        setCurrentStep('login');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [currentStep]);

  const handleSplashContinue = () => {
    setCurrentStep('login');
  };

  const handleLoginContinue = (mobile: string) => {
    setUserMobile(mobile);
    setCurrentStep('otp');
  };

  const handleOTPContinue = () => {
    setCurrentStep('language');
  };

  const handleOTPGoBack = () => {
    setCurrentStep('login');
  };

  const handleLanguageContinue = (language: string) => {
    setUserLanguage(language);
    setCurrentStep('consent');
  };

  const handleConsentContinue = () => {
    setCurrentStep('profile');
  };

  const handleProfileContinue = (name: string, ageRange: string) => {
    setUserName(name);
    setUserAgeRange(ageRange);
    setCurrentStep('dashboard');
  };

  const handleNavigateToHealthAssistant = () => {
    setCurrentStep('health-assistant');
  };

  const handleNavigateToNotifications = () => {
    setCurrentStep('notifications');
  };

  const handleBackToDashboard = () => {
    setCurrentStep('dashboard');
  };

  const handleNavigateToMedicationReminder = () => {
    setCurrentStep('medication-reminder');
  };

  const handleNavigateToGovernmentSchemes = () => {
    setCurrentStep('government-schemes');
  };

  const handleNavigateToProfileSettings = () => {
    setCurrentStep('profile-settings');
  };

  const handleNavigateToMedicalMaps = () => {
    setCurrentStep('medical-maps');
  };

  const handleNavigateToHealthInformation = () => {
    setCurrentStep('health-information');
  };

  const handleNavigateToSettings = () => {
    setCurrentStep('settings');
  };

  const handleNavigateToPreVisit = () => {
    setCurrentStep('pre-visit');
  };

  const handleNavigateToHelpSupport = () => {
    setCurrentStep('help-support');
  };

  return (
    <>
      {currentStep === 'splash' && (
        <SplashScreen onContinue={handleSplashContinue} />
      )}
      
      {currentStep === 'login' && (
        <LoginScreen onContinue={handleLoginContinue} />
      )}
      
      {currentStep === 'consent' && (
        <ConsentScreen onContinue={handleConsentContinue} />
      )}
      
      {currentStep === 'otp' && (
        <OTPScreen
          mobile={userMobile}
          onContinue={handleOTPContinue}
          onGoBack={handleOTPGoBack}
        />
      )}
      
      {currentStep === 'language' && (
        <LanguageScreen onContinue={handleLanguageContinue} />
      )}
      
      {currentStep === 'profile' && (
        <ProfileSetupScreen onContinue={handleProfileContinue} />
      )}
      
      {currentStep === 'dashboard' && (
        <DashboardScreen
          userName={userName}
          language={userLanguage}
          onNavigateToHealthAssistant={handleNavigateToHealthAssistant}
          onNavigateToNotifications={handleNavigateToNotifications}
          onNavigateToMedicationReminder={handleNavigateToMedicationReminder}
          onNavigateToGovernmentSchemes={handleNavigateToGovernmentSchemes}
          onNavigateToProfile={handleNavigateToProfileSettings}
          onNavigateToMedicalMaps={handleNavigateToMedicalMaps}
          onNavigateToHealthInformation={handleNavigateToHealthInformation}
          onNavigateToSettings={handleNavigateToSettings}
          onNavigateToPreVisit={handleNavigateToPreVisit}
          onNavigateToHelpSupport={handleNavigateToHelpSupport}
        />
      )}
      
      {currentStep === 'health-assistant' && (
        <HealthAssistantScreen 
          language={userLanguage}
          onBack={handleBackToDashboard}
          onNavigateToNotifications={() => setCurrentStep('notifications')}
        />
      )}
      
      {currentStep === 'notifications' && (
        <NotificationsScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'medication-reminder' && (
        <MedicationReminderScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'government-schemes' && (
        <GovernmentSchemesScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'profile-settings' && (
        <ProfileScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'medical-maps' && (
        <MedicalMapsScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'health-information' && (
        <HealthInformationScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'settings' && (
        <SettingsScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'pre-visit' && (
        <PreVisitPreparationScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
      
      {currentStep === 'help-support' && (
        <HelpSupportScreen language={userLanguage} onBack={handleBackToDashboard} />
      )}
    </>
  );
}

export default App;