import { ArrowLeft, Settings, ShoppingBag, Phone, Info, Mic, Send, HelpCircle, X, Volume2, MessageSquare, Trash2, Bell } from 'lucide-react';
import { useState } from 'react';

interface HealthAssistantScreenProps {
  onBack: () => void;
  onNavigateToNotifications?: () => void;
}

interface Message {
  id: string;
  text: string;
  timestamp: string;
  sender: 'user' | 'assistant';
}

export function HealthAssistantScreen({ onBack, onNavigateToNotifications }: HealthAssistantScreenProps) {
  const [showSettings, setShowSettings] = useState(false);
  const [voiceInputEnabled, setVoiceInputEnabled] = useState(true);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'नमस्ते! मैं आपकी स्वास्थ्य सहायक हूँ। मैं आपको स्वास्थ्य जानकारी और मार्गदर्शन में मदद कर सकती हूं।',
      timestamp: '07:53:34 PM',
      sender: 'assistant'
    }
  ]);
  const [inputText, setInputText] = useState('');

  const handleSendMessage = () => {
    if (inputText.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputText,
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        sender: 'user'
      };
      setMessages([...messages, newMessage]);
      setInputText('');

      // Simulate AI response with intelligent answers
      setTimeout(() => {
        const question = inputText.toLowerCase();
        let responseText = '';

        // Health-related responses in Hindi/English
        if (question.includes('fever') || question.includes('बुखार')) {
          responseText = '🌡️ बुखार के लिए सुझाव:\n\n1. पर्याप्त आराम करें\n2. खूब पानी पिएं (8-10 गिलास)\n3. हल्का भोजन करें\n4. यदि बुखार 101°F से अधिक है या 3 दिन से अधिक रहता है, तो डॉक्टर से संपर्क करें\n5. पैरासिटामोल ले सकते हैं (डॉक्टर की सलाह से)\n\nFor Fever:\n• Rest adequately\n• Drink plenty of fluids\n• Consult doctor if fever persists >3 days or >101°F';
        } else if (question.includes('headache') || question.includes('सिरदर्द')) {
          responseText = '🤕 सिरदर्द के लिए:\n\n1. आंखों को आराम दें\n2. पानी पिएं - डिहाइड्रेशन से सिरदर्द हो सकता है\n3. अंधेरे कमरे में आराम करें\n4. गर्दन और कंधों की हल्की मालिश करें\n5. कैफीन का सेवन कम करें\n\nHeadache Relief:\n• Rest in dark room\n• Stay hydrated\n• Gentle neck massage\n• If severe or persistent, consult doctor';
        } else if (question.includes('cold') || question.includes('cough') || question.includes('खांसी') || question.includes('जुकाम')) {
          responseText = '🤧 सर्दी-खांसी के लिए:\n\n1. गर्म पानी पिएं\n2. भाप लें (steam inhalation)\n3. शहद और अदरक की चाय पिएं\n4. नमक के गुनगुने पानी से गरारे करें\n5. पर्याप्त नींद लें\n6. विटामिन C युक्त खाद्य पदार्थ खाएं\n\nCold & Cough:\n• Warm fluids\n• Steam inhalation\n• Honey-ginger tea\n• Saltwater gargling\n• Rest well';
        } else if (question.includes('stomach') || question.includes('पेट') || question.includes('acidity') || question.includes('एसिडिटी')) {
          responseText = '🤰 पेट की समस्या के लिए:\n\n1. हल्का और सुपाच्य भोजन करें\n2. तले-भुने और मसालेदार भोजन से बचें\n3. छोटे-छोटे भोजन कई बार करें\n4. खाने के बाद तुरंत न लेटें\n5. तनाव कम करें\n6. पुदीना या अदरक की चाय पिएं\n\nStomach Issues:\n• Light, digestible food\n• Avoid spicy/fried foods\n• Eat small frequent meals\n• Mint or ginger tea';
        } else if (question.includes('diabetes') || question.includes('मधुमेह') || question.includes('sugar')) {
          responseText = '🩺 मधुमेह प्रबंधन:\n\n1. नियमित रूप से ब्लड शुगर चेक करें\n2. संतुलित आहार लें - फाइबर युक्त भोजन\n3. नियमित व्यायाम करें (30 मिनट रोज)\n4. मीठा और प्रोसेस्ड फूड से बचें\n5. दवा समय पर लें\n6. तनाव प्रबंधन करें\n\nDiabetes Management:\n• Regular blood sugar monitoring\n• Balanced diet with fiber\n• Daily exercise\n• Take medication on time';
        } else if (question.includes('bp') || question.includes('blood pressure') || question.includes('रक्तचाप')) {
          responseText = '💓 रक्तचाप प्रबंधन:\n\n1. नमक का सेवन कम करें\n2. नियमित व्यायाम करें\n3. स्वस्थ वजन बनाए रखें\n4. तनाव कम करें - योग और ध्यान करें\n5. शराब और धूम्रपान से बचें\n6. नियमित जांच करवाएं\n\nBlood Pressure:\n• Reduce salt intake\n• Regular exercise\n• Maintain healthy weight\n• Stress management';
        } else if (question.includes('sleep') || question.includes('नींद') || question.includes('insomnia')) {
          responseText = '😴 बेहतर नींद के लिए:\n\n1. नियमित समय पर सोएं और जागें\n2. सोने से पहले स्क्रीन का उपयोग बंद करें\n3. कमरे को अंधेरा और शांत रखें\n4. कैफीन और भारी भोजन से बचें\n5. हल्का योग या ध्यान करें\n6. गर्म दूध पिएं\n\nBetter Sleep:\n• Regular sleep schedule\n• Avoid screens before bed\n• Dark, quiet room\n• Light yoga/meditation';
        } else if (question.includes('weight') || question.includes('वजन') || question.includes('obesity')) {
          responseText = '⚖️ वजन प्रबंधन:\n\n1. संतुलित आहार लें\n2. रोज 30-45 मिनट व्यायाम करें\n3. पानी खूब पिएं\n4. प्रोसेस्ड फूड से बचें\n5. फल और सब्जियां अधिक खाएं\n6. पर्याप्त नींद लें (7-8 घंटे)\n\nWeight Management:\n• Balanced diet\n• Regular exercise (30-45 min)\n• Plenty of water\n• More fruits & vegetables';
        } else if (question.includes('stress') || question.includes('tension') || question.includes('तनाव')) {
          responseText = '🧘 तनाव प्रबंधन:\n\n1. योग और ध्यान करें\n2. गहरी सांस लेने का अभ्यास करें\n3. नियमित व्यायाम करें\n4. परिवार और दोस्तों से बात करें\n5. पर्याप्त नींद लें\n6. शौक और मनोरंजन का समय निकालें\n\nStress Management:\n• Yoga & meditation\n• Deep breathing\n• Regular exercise\n• Talk to loved ones';
        } else if (question.includes('vitamin') || question.includes('विटामिन') || question.includes('nutrition')) {
          responseText = '🥗 पोषण सुझाव:\n\n1. विटामिन D: धूप में 15-20 मिनट रहें\n2. विटामिन C: नींबू, आंवला, संतरा\n3. आयरन: पालक, चुकंदर, गुड़\n4. कैल्शियम: दूध, दही, रागी\n5. प्रोटीन: दाल, अंडा, सोयाबीन\n6. संतुलित आहार लें\n\nNutrition:\n• Balanced diet with all nutrients\n• Vitamin D: sunlight exposure\n• Fresh fruits & vegetables';
        } else if (question.includes('exercise') || question.includes('व्यायाम') || question.includes('workout')) {
          responseText = '🏃 व्यायाम सुझाव:\n\n1. रोज 30 मिनट चलें या जॉगिंग करें\n2. योग और स्ट्रेचिंग करें\n3. सीढ़ियों का उपयोग करें\n4. धीरे-धीरे शुरुआत करें\n5. नियमितता बनाए रखें\n6. पानी पर्याप्त पिएं\n\nExercise Tips:\n• 30 min daily walking/jogging\n• Yoga & stretching\n• Start slowly, be consistent';
        } else {
          responseText = 'मैं आपके स्वास्थ्य प्रश्न को समझ रहा हूं। कृपया अधिक विशिष्ट जानकारी दें जैसे:\n\n• बुखार (Fever)\n• सिरदर्द (Headache)\n• सर्दी-खांसी (Cold/Cough)\n• पेट की समस्या (Stomach issues)\n• मधुमेह (Diabetes)\n• रक्तचाप (Blood Pressure)\n• नींद की समस्या (Sleep issues)\n• वजन प्रबंधन (Weight management)\n• तनाव (Stress)\n• व्यायाम (Exercise)\n• पोषण (Nutrition)\n\nI can help with common health questions. Please specify your concern for better guidance.';
        }

        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: responseText,
          timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          sender: 'assistant'
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: '1',
        text: 'नमस्ते! मैं आपकी स्वास्थ्य सहायक हूँ। मैं आपको स्वास्थ्य जानकारी और मार्गदर्शन में मदद कर सकती हूं।',
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        sender: 'assistant'
      }
    ]);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col relative">
      {/* Header - Sticky */}
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-2 text-gray-700 hover:text-gray-900">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <div className="flex items-center gap-2">
            <button 
              onClick={onNavigateToNotifications} 
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <Bell className="w-5 h-5 text-gray-700" />
            </button>
            <button onClick={() => setShowSettings(true)} className="p-2 hover:bg-gray-100 rounded-lg">
              <Settings className="w-5 h-5 text-gray-700" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-blue-100 p-3 rounded-2xl">
            <ShoppingBag className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl">स्वास्थ्य सहायक</h1>
            <p className="text-sm text-gray-600">अपने स्वास्थ्य प्रश्न पूछें</p>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto px-4 py-4 pb-24">
        {/* AI Limitations */}
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-4 flex gap-3">
          <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="mb-1">AI Limitations</p>
            <p className="text-sm text-gray-700">
              यह स्वास्थ्य सहायकी और मार्गदर्शन में मदद कर सकती है। यह चिकित्सा विदान या दवा सलाह नहीं दे सकती। यदि आपको स्वास्थ्य गंभीर लगता है, कृपया नजदीकी अस्पताल जाएं।
            </p>
          </div>
        </div>

        {/* Health Assistant Section */}
        <div className="bg-white border border-gray-200 rounded-2xl p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-xl">
                <ShoppingBag className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium">Health Assistant</p>
                <p className="text-sm text-gray-600">AI-powered guidance</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-sm text-green-600">Online</span>
            </div>
          </div>

          {/* Messages */}
          <div className="space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {message.sender === 'assistant' && (
                  <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0 h-fit">
                    <ShoppingBag className="w-4 h-4 text-blue-600" />
                  </div>
                )}
                <div className={`flex-1 ${message.sender === 'user' ? 'flex flex-col items-end' : ''}`}>
                  <div
                    className={`p-3 rounded-xl ${
                      message.sender === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-blue-50'
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{message.timestamp}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Help Button */}
      <button className="fixed bottom-24 right-6 bg-gray-900 text-white p-4 rounded-full shadow-lg hover:bg-gray-800 transition-colors">
        <HelpCircle className="w-6 h-6" />
      </button>

      {/* Input Section */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <div className="flex items-center gap-2">
          <button className="p-3 hover:bg-gray-100 rounded-lg">
            <Mic className="w-5 h-5 text-gray-700" />
          </button>
          <input
            type="text"
            placeholder="प्रश्न पूछें"
            className="flex-1 px-4 py-3 bg-gray-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
          />
          <button
            onClick={handleSendMessage}
            className="p-3 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors"
          >
            <Send className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-4">
          <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden">
            {/* Modal Header */}
            <div className="bg-blue-600 text-white px-6 py-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-white/20 p-2 rounded-xl">
                  <Settings className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl">AI Assistant Settings</h2>
                  <p className="text-sm text-blue-100">सहायक सेटिंग</p>
                </div>
              </div>
              <button onClick={() => setShowSettings(false)} className="p-1 hover:bg-white/20 rounded-lg">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* Voice Input */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <Volume2 className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium">Voice Input</h3>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between">
                  <div>
                    <p className="mb-1">वॉइस इनपुट सक्षम करें</p>
                    <p className="text-sm text-gray-600">Enable voice input</p>
                  </div>
                  <button
                    onClick={() => setVoiceInputEnabled(!voiceInputEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      voiceInputEnabled ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        voiceInputEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>
              </div>

              {/* Chat History */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-4">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium">Chat History</h3>
                </div>
                <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between mb-3">
                  <div>
                    <p className="mb-1">स्वतः सहेजें</p>
                    <p className="text-sm text-gray-600">Auto-save conversations</p>
                  </div>
                  <button
                    onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
                    className={`relative w-12 h-7 rounded-full transition-colors ${
                      autoSaveEnabled ? 'bg-blue-600' : 'bg-gray-300'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        autoSaveEnabled ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    ></div>
                  </button>
                </div>

                <button
                  onClick={handleClearChat}
                  className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2 mb-2"
                >
                  <Trash2 className="w-5 h-5" />
                  Clear Chat History
                </button>
                <p className="text-center text-sm text-gray-600">
                  चैट इतिहास साफ करें / Delete all messages
                </p>
              </div>

              {/* About AI Assistant */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                <div className="flex items-start gap-2 mb-3">
                  <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <h3 className="font-medium text-blue-900">About AI Assistant</h3>
                </div>
                <p className="text-sm text-blue-900 mb-3">
                  This AI health assistant provides general health information and guidance. It cannot replace professional medical advice.
                </p>
                <p className="text-sm text-blue-900">
                  यह AI स्वास्थ्य सहायक सामान्य स्वास्थ्य जानकारी प्रदान करता है। यह पेशेवर चिकित्सा सलाह का विकल्प नहीं है।
                </p>
              </div>

              {/* Done Button */}
              <button
                onClick={() => setShowSettings(false)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl transition-colors"
              >
                Done / पूर्ण
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}