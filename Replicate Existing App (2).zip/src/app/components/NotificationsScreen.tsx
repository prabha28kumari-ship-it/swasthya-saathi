import { ArrowLeft, Bell, Calendar, Heart, Pill, FileText, Clock, Check } from 'lucide-react';

interface NotificationsScreenProps {
  onBack: () => void;
}

interface Notification {
  id: string;
  type: 'reminder' | 'health-tip' | 'appointment' | 'system';
  title: string;
  titleHindi: string;
  message: string;
  messageHindi: string;
  time: string;
  isRead: boolean;
}

export function NotificationsScreen({ onBack }: NotificationsScreenProps) {
  const notifications: Notification[] = [
    {
      id: '1',
      type: 'reminder',
      title: 'Medication Reminder',
      titleHindi: 'दवा अनुस्मारक',
      message: 'Time to take your evening medication',
      messageHindi: 'अपनी शाम की दवा लेने का समय',
      time: '30 minutes ago',
      isRead: false
    },
    {
      id: '2',
      type: 'health-tip',
      title: 'Daily Health Tip',
      titleHindi: 'दैनिक स्वास्थ्य टिप',
      message: 'Drink plenty of water to stay hydrated',
      messageHindi: 'हाइड्रेटेड रहने के लिए खूब पानी पिएं',
      time: '2 hours ago',
      isRead: false
    },
    {
      id: '3',
      type: 'appointment',
      title: 'Upcoming Appointment',
      titleHindi: 'आगामी अपॉइंटमेंट',
      message: 'Doctor consultation scheduled for tomorrow',
      messageHindi: 'कल डॉक्टर परामर्श निर्धारित है',
      time: '5 hours ago',
      isRead: true
    },
    {
      id: '4',
      type: 'system',
      title: 'New Feature Available',
      titleHindi: 'नई सुविधा उपलब्ध',
      message: 'Check out our new health tracking feature',
      messageHindi: 'हमारी नई स्वास्थ्य ट्रैकिंग सुविधा देखें',
      time: '1 day ago',
      isRead: true
    }
  ];

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'reminder':
        return <Pill className="w-6 h-6 text-green-600" />;
      case 'health-tip':
        return <Heart className="w-6 h-6 text-red-500 fill-red-500" />;
      case 'appointment':
        return <Calendar className="w-6 h-6 text-blue-600" />;
      case 'system':
        return <FileText className="w-6 h-6 text-cyan-600" />;
      default:
        return <Bell className="w-6 h-6 text-gray-600" />;
    }
  };

  const getNotificationBgColor = (type: string) => {
    switch (type) {
      case 'reminder':
        return 'bg-green-100';
      case 'health-tip':
        return 'bg-red-100';
      case 'appointment':
        return 'bg-blue-100';
      case 'system':
        return 'bg-cyan-100';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-2 hover:bg-white/20 rounded-lg p-2 -ml-2">
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
          <button className="hover:bg-white/20 rounded-lg p-2">
            <Check className="w-5 h-5" />
          </button>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white/20 p-3 rounded-2xl">
            <Bell className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-2xl mb-1">सूचनाएं</h1>
            <p className="text-sm text-cyan-100">Notifications</p>
          </div>
        </div>
      </header>

      {/* Notifications List */}
      <main className="px-4 py-4">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            {notifications.filter(n => !n.isRead).length} unread notifications
          </p>
          <button className="text-sm text-cyan-600 hover:underline">
            Mark all as read
          </button>
        </div>

        <div className="space-y-3">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`bg-white rounded-2xl p-4 border-2 transition-all ${
                notification.isRead ? 'border-gray-100' : 'border-cyan-200 shadow-sm'
              }`}
            >
              <div className="flex gap-3">
                <div className={`${getNotificationBgColor(notification.type)} p-3 rounded-xl flex-shrink-0 h-fit`}>
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex-1">
                      <h3 className="mb-1">{notification.titleHindi}</h3>
                      <p className="text-sm text-cyan-600">{notification.title}</p>
                    </div>
                    {!notification.isRead && (
                      <div className="w-2 h-2 bg-cyan-500 rounded-full flex-shrink-0 mt-1"></div>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 mb-1">{notification.messageHindi}</p>
                  <p className="text-sm text-gray-500 mb-3">{notification.message}</p>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{notification.time}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty state for older notifications */}
        <div className="mt-8 text-center py-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-200 rounded-full mb-4">
            <Bell className="w-8 h-8 text-gray-400" />
          </div>
          <p className="text-gray-500 mb-1">You're all caught up!</p>
          <p className="text-sm text-gray-400">आप सभी सूचनाएं देख चुके हैं</p>
        </div>
      </main>
    </div>
  );
}
