import { 
  ArrowLeft, 
  MessageCircle, 
  Phone, 
  Mail, 
  Book, 
  HelpCircle,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Video,
  FileText,
  Send,
  Star,
  Clock
} from 'lucide-react';
import { useState } from 'react';

interface HelpSupportScreenProps {
  language?: string;
  onBack: () => void;
}

export function HelpSupportScreen({ language, onBack }: HelpSupportScreenProps) {
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [showFeedbackSuccess, setShowFeedbackSuccess] = useState(false);

  const isHindi = language?.toLowerCase() === 'hindi' || language?.toLowerCase() === 'हिंदी';

  const faqs = [
    {
      question: isHindi ? 'ऐप का उपयोग कैसे करें?' : 'How to use the app?',
      answer: isHindi 
        ? 'स्वास्थ्य साथी ऐप आपको स्वास्थ्य सेवाओं तक आसान पहुंच प्रदान करता है। डैशबोर्ड से आप AI स्वास्थ्य सहायक से प्रश्न पूछ सकते हैं, दवा अनुस्मारक सेट कर सकते हैं, और निकटतम अस्पताल खोज सकते हैं।'
        : 'Health Companion app provides easy access to health services. From the dashboard, you can ask AI health assistant questions, set medication reminders, and find nearby hospitals.'
    },
    {
      question: isHindi ? 'दवा अनुस्मारक कैसे सेट करें?' : 'How to set medication reminders?',
      answer: isHindi
        ? 'डैशबोर्ड से "दवा अनुस्मारक" पर क्लिक करें। फिर "नई दवा जोड़ें" पर क्लिक करें और दवा का नाम, खुराक और समय दर्ज करें। ऐप आपको समय पर रिमाइंडर भेजेगा।'
        : 'Click "Medication Reminders" from dashboard. Then click "Add New Medicine" and enter medicine name, dosage, and time. The app will send you timely reminders.'
    },
    {
      question: isHindi ? 'निकटतम अस्पताल कैसे खोजें?' : 'How to find nearby hospitals?',
      answer: isHindi
        ? '"निकटतम अस्पताल" फीचर पर क्लिक करें। ऐप आपकी लोकेशन के आधार पर पास के अस्पतालों की सूची दिखाएगा। आप फिल्टर का उपयोग करके विशेष प्रकार के अस्पताल खोज सकते हैं।'
        : 'Click on "Nearby Hospitals" feature. The app will show a list of hospitals near your location. You can use filters to find specific types of hospitals.'
    },
    {
      question: isHindi ? 'AI स्वास्थ्य सहायक कैसे काम करता है?' : 'How does AI Health Assistant work?',
      answer: isHindi
        ? 'AI स्वास्थ्य सहायक आपके स्वास्थ्य प्रश्नों का उत्तर देता है। आप लक्षण, दवा, या सामान्य स्वास्थ्य के बारे में पूछ सकते हैं। यह केवल सामान्य जानकारी प्रदान करता है, आपातकालीन स्थिति में डॉक्टर से संपर्क करें।'
        : 'AI Health Assistant answers your health questions. You can ask about symptoms, medicines, or general health. It provides general information only - consult a doctor in emergencies.'
    },
    {
      question: isHindi ? 'सरकारी योजनाओं के बारे में कैसे जानें?' : 'How to learn about government schemes?',
      answer: isHindi
        ? '"सरकारी योजनाएं" सेक्शन में आयुष्मान भारत, जननी सुरक्षा योजना और अन्य स्वास्थ्य योजनाओं की जानकारी उपलब्ध है। प्रत्येक योजना के लिए पात्रता और आवेदन प्रक्रिया बताई गई है।'
        : 'The "Government Schemes" section provides information about Ayushman Bharat, Janani Suraksha Yojana, and other health schemes. Eligibility and application process is explained for each scheme.'
    },
    {
      question: isHindi ? 'मेरा डेटा सुरक्षित है?' : 'Is my data secure?',
      answer: isHindi
        ? 'हां, आपका डेटा पूरी तरह सुरक्षित है। हम उद्योग-मानक एन्क्रिप्शन का उपयोग करते हैं और आपकी जानकारी किसी तीसरे पक्ष के साथ साझा नहीं करते हैं।'
        : 'Yes, your data is completely secure. We use industry-standard encryption and never share your information with third parties.'
    },
    {
      question: isHindi ? 'भाषा कैसे बदलें?' : 'How to change language?',
      answer: isHindi
        ? 'सेटिंग्स में जाकर आप ऐप की भाषा बदल सकते हैं। वर्तमान में हिंदी और अंग्रेजी समर्थित हैं।'
        : 'You can change the app language by going to Settings. Currently Hindi and English are supported.'
    },
    {
      question: isHindi ? 'ऐप मुफ्त है?' : 'Is the app free?',
      answer: isHindi
        ? 'हां, स्वास्थ्य साथी ऐप पूरी तरह से मुफ्त है। सभी सुविधाएं बिना किसी शुल्क के उपलब्ध हैं।'
        : 'Yes, Health Companion app is completely free. All features are available without any charges.'
    }
  ];

  const handleSubmitFeedback = () => {
    if (feedbackText.trim()) {
      setShowFeedbackSuccess(true);
      setFeedbackText('');
      setTimeout(() => setShowFeedbackSuccess(false), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-cyan-500 to-cyan-600 text-white px-6 py-4 sticky top-0 z-10 shadow-lg">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-white/20 rounded-lg transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">
              {isHindi ? 'सहायता और समर्थन' : 'Help & Support'}
            </h1>
            <p className="text-sm text-cyan-100">
              {isHindi ? 'हम यहाँ आपकी मदद के लिए हैं' : 'We\'re here to help you'}
            </p>
          </div>
        </div>
      </header>

      <main className="px-6 py-6 pb-24">
        {/* Quick Help Cards */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">
            {isHindi ? 'त्वरित सहायता' : 'Quick Help'}
          </h2>
          <div className="grid grid-cols-1 gap-4">
            {/* Chat Support */}
            <a 
              href="https://wa.me/911234567890" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-green-500 text-white rounded-2xl p-5 flex items-center gap-4 hover:bg-green-600 transition-colors"
            >
              <div className="bg-white/20 p-3 rounded-xl">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">
                  {isHindi ? 'व्हाट्सएप पर चैट करें' : 'Chat on WhatsApp'}
                </h3>
                <p className="text-sm text-green-100">
                  {isHindi ? 'तुरंत उत्तर पाएं' : 'Get instant replies'}
                </p>
              </div>
              <ExternalLink className="w-5 h-5" />
            </a>

            {/* Call Support */}
            <a 
              href="tel:18001234567"
              className="bg-blue-500 text-white rounded-2xl p-5 flex items-center gap-4 hover:bg-blue-600 transition-colors"
            >
              <div className="bg-white/20 p-3 rounded-xl">
                <Phone className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">
                  {isHindi ? 'हेल्पलाइन पर कॉल करें' : 'Call Helpline'}
                </h3>
                <p className="text-sm text-blue-100">1800-123-4567 (Toll Free)</p>
              </div>
              <Phone className="w-5 h-5" />
            </a>

            {/* Email Support */}
            <a 
              href="mailto:support@healthcompanion.in"
              className="bg-purple-500 text-white rounded-2xl p-5 flex items-center gap-4 hover:bg-purple-600 transition-colors"
            >
              <div className="bg-white/20 p-3 rounded-xl">
                <Mail className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">
                  {isHindi ? 'ईमेल भेजें' : 'Send Email'}
                </h3>
                <p className="text-sm text-purple-100">support@healthcompanion.in</p>
              </div>
              <ExternalLink className="w-5 h-5" />
            </a>
          </div>
        </section>

        {/* Tutorial Videos */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">
            {isHindi ? 'ट्यूटोरियल वीडियो' : 'Tutorial Videos'}
          </h2>
          <div className="grid grid-cols-1 gap-3">
            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow">
              <div className="bg-red-100 p-3 rounded-xl">
                <Video className="w-6 h-6 text-red-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'ऐप का परिचय' : 'App Introduction'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? '5 मिनट' : '5 minutes'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow">
              <div className="bg-green-100 p-3 rounded-xl">
                <Video className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'दवा अनुस्मारक सेट करें' : 'Set Medication Reminders'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? '3 मिनट' : '3 minutes'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow">
              <div className="bg-blue-100 p-3 rounded-xl">
                <Video className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'AI सहायक का उपयोग' : 'Using AI Assistant'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? '4 मिनट' : '4 minutes'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">
            {isHindi ? 'अक्सर पूछे जाने वाले प्रश्न' : 'Frequently Asked Questions'}
          </h2>
          <div className="space-y-3">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-sm">
                <button
                  onClick={() => setExpandedFAQ(expandedFAQ === index ? null : index)}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3 flex-1 text-left">
                    <HelpCircle className="w-5 h-5 text-cyan-600 flex-shrink-0" />
                    <span className="font-medium text-gray-900">{faq.question}</span>
                  </div>
                  {expandedFAQ === index ? (
                    <ChevronUp className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                {expandedFAQ === index && (
                  <div className="px-4 pb-4 pt-0">
                    <div className="bg-cyan-50 rounded-xl p-4 border-l-4 border-cyan-500">
                      <p className="text-gray-700 text-sm leading-relaxed">{faq.answer}</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* User Guides */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">
            {isHindi ? 'उपयोगकर्ता गाइड' : 'User Guides'}
          </h2>
          <div className="space-y-3">
            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow w-full">
              <div className="bg-cyan-100 p-3 rounded-xl">
                <FileText className="w-6 h-6 text-cyan-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'शुरुआती गाइड' : 'Getting Started Guide'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? 'नए उपयोगकर्ताओं के लिए' : 'For new users'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow w-full">
              <div className="bg-blue-100 p-3 rounded-xl">
                <Book className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'सुविधा गाइड' : 'Features Guide'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? 'सभी सुविधाओं का विवरण' : 'Details of all features'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            <button className="bg-white rounded-2xl p-4 flex items-center gap-4 hover:shadow-lg transition-shadow w-full">
              <div className="bg-purple-100 p-3 rounded-xl">
                <AlertCircle className="w-6 h-6 text-purple-600" />
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-medium text-gray-900">
                  {isHindi ? 'समस्या निवारण' : 'Troubleshooting'}
                </h3>
                <p className="text-sm text-gray-500">
                  {isHindi ? 'सामान्य समस्याओं का समाधान' : 'Solutions to common issues'}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </section>

        {/* Feedback Section */}
        <section className="mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-orange-100 p-3 rounded-xl">
                <Star className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold">
                  {isHindi ? 'फीडबैक दें' : 'Send Feedback'}
                </h2>
                <p className="text-sm text-gray-500">
                  {isHindi ? 'हमें बेहतर बनाने में मदद करें' : 'Help us improve'}
                </p>
              </div>
            </div>

            {showFeedbackSuccess && (
              <div className="mb-4 bg-green-50 border-2 border-green-200 rounded-xl p-4 flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-green-900">
                    {isHindi ? 'धन्यवाद!' : 'Thank you!'}
                  </p>
                  <p className="text-sm text-green-700">
                    {isHindi 
                      ? 'आपकी प्रतिक्रिया सफलतापूर्वक जमा की गई।' 
                      : 'Your feedback has been submitted successfully.'}
                  </p>
                </div>
              </div>
            )}

            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              placeholder={isHindi 
                ? 'अपनी राय, सुझाव या समस्या यहाँ लिखें...' 
                : 'Write your feedback, suggestions or issues here...'}
              className="w-full border-2 border-gray-200 rounded-xl p-4 mb-4 min-h-32 focus:outline-none focus:border-cyan-500 transition-colors resize-none"
            />

            <button
              onClick={handleSubmitFeedback}
              disabled={!feedbackText.trim()}
              className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 text-white py-3 rounded-xl font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              {isHindi ? 'फीडबैक भेजें' : 'Send Feedback'}
            </button>
          </div>
        </section>

        {/* Working Hours */}
        <section className="mb-8">
          <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-5">
            <div className="flex items-start gap-3">
              <Clock className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-bold text-gray-900 mb-2">
                  {isHindi ? 'सहायता समय' : 'Support Hours'}
                </h3>
                <p className="text-sm text-gray-700 mb-2">
                  {isHindi 
                    ? '📞 फोन सहायता: सोमवार - शुक्रवार, सुबह 9 बजे - शाम 6 बजे'
                    : '📞 Phone Support: Monday - Friday, 9 AM - 6 PM'}
                </p>
                <p className="text-sm text-gray-700 mb-2">
                  {isHindi 
                    ? '💬 चैट सहायता: 24/7 उपलब्ध'
                    : '💬 Chat Support: Available 24/7'}
                </p>
                <p className="text-sm text-gray-700">
                  {isHindi 
                    ? '📧 ईमेल: 24-48 घंटों में उत्तर'
                    : '📧 Email: Response within 24-48 hours'}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* App Info */}
        <section>
          <div className="bg-white rounded-2xl p-6 text-center shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 mb-2">
              {isHindi ? 'स्वास्थ्य साथी' : 'Health Companion'}
            </h3>
            <p className="text-sm text-gray-500 mb-1">
              {isHindi ? 'संस्करण' : 'Version'} 1.0.0
            </p>
            <p className="text-xs text-gray-400">
              © 2024 Health Companion. {isHindi ? 'सर्वाधिकार सुरक्षित' : 'All rights reserved'}.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
}
